let mute_farm_collection_sfx_opt = document.getElementById("mute-farm-collect-sfx-preference");
let mute_reel_spin_sfx_opt = document.getElementById("mute-reel-spin-sfx-preference");
let osc_sfx_active = true;

const audio_ctx = new AudioContext(); // AUDIO CONTEXT

let oscillator;
let gain_node;
oscClickAudio();

function oscClickAudio() {

    if (osc_sfx_active) { 
        oscillator = audio_ctx.createOscillator(); 

        oscillator.type = "sawtooth"; // OSCILLATOR TYPE
        oscillator.frequency.value = 2000; // OSCILLATOR FREQUENCY
        gain_node = audio_ctx.createGain(); // GAIN NODE

        oscillator.start();
        oscillator.connect(gain_node);
        gain_node.connect(audio_ctx.destination);
        gain_node.gain.value = 10;
        gain_node.gain.exponentialRampToValueAtTime(0.001, audio_ctx.currentTime + 0.1);
        gain_node.gain.exponentialRampToValueAtTime(0.001, audio_ctx.currentTime + 0.002);
        oscillator.stop(audio_ctx.currentTime + 0.02);
    } else {
        oscillator.stop();
        oscillator.disconnect();
    } // OSCILLATOR }

    return oscillator; 
    return gain_node;
}

function upgradePurchasedAudio() { let audio = document.getElementById("upgrades-purchase-sfx"); audio.play(); }
function upgradePurchaseFailedAudio() { let audio = document.getElementById("upgrades-purchase-failed-sfx"); audio.play(); }
function passiveIncomePoolGrantedAudio() { let audio = document.getElementById("cash-collect-sfx"); audio.play(); }
function spinningReelsAudio() { let audio = document.getElementById("spinning-sfx"); audio.play(); }
function lvlUpAudio() { let audio = document.getElementById("level-up-sfx"); audio.play(); }
function smallDingAudio() { let audio = document.getElementById("small-ding-sfx"); audio.play(); }
function keyboardClickAudio() { let audio = document.getElementById("keyboard-click-sfx"); audio.play(); }
function collectFarmAudio() { let audio = document.getElementById("collect-farm-sfx"); audio.play(); }
function bonusWinAudio() { let audio = document.getElementById("bonus-win-sfx"); audio.play(); }
function collectTaskAwardAudio() { let audio = document.getElementById("task-collection-sfx"); audio.play(); }
function correctAnswerAudio() { let audio = document.getElementById("correct-answer-sfx"); audio.play(); }
function wrongAnswerAudio() { let audio = document.getElementById("wrong-answer-sfx"); audio.play(); }
function mysteryWinAudio() { let audio = document.getElementById("mystery-win-sfx"); audio.play(); }
function buttonPressAudio() { let audio = document.getElementById("button-press-sfx"); audio.play(); }
function createBoardAudio() { let audio = document.getElementById("creating-board-sfx"); audio.play(); }
function resetBoardAudio() { let audio = document.getElementById("reseting-board-sfx"); audio.play(); }
function boardCompletedAudio() { let audio = document.getElementById("board-completed-sfx"); audio.play(); }
function taskCompletedAudio() { let audio = document.getElementById("task-completed-sfx"); audio.play(); }
function insufficientFundsAudio() { let audio = document.getElementById("insufficient-funds-sfx"); audio.play(); }
function insufficientCoinsAudio() { let audio = document.getElementById("insufficient-coins-sfx"); audio.play(); }
function insufficientDiamondsAudio() { let audio = document.getElementById("insufficient-diamonds-sfx"); audio.play(); }
function autoSpinsCompletedAudio() { let audio = document.getElementById("auto-spins-completed-sfx"); audio.play(); }
function loanApplicationRejectedAudio() { let audio = document.getElementById("loan-application-rejected-sfx"); audio.play(); }
function loanApprovedAudio() { let audio = document.getElementById("loan-approved-sfx"); audio.play(); }
function triviaGameOverAudio() { let audio = document.getElementById("trivia-game-over-sfx"); audio.play(); }
function tokenUnavailableAudio() { let audio = document.getElementById("token-unavailable-sfx"); audio.play(); }
function boosterUnavailableAudio() { let audio = document.getElementById("booster-unavailable-sfx"); audio.play(); }

function clockTickAudio() {
    let audio = document.getElementById("clock-tick-sfx");
    audio.currentTime = 0;
    audio.volume = 0.8;
    audio.play();
}