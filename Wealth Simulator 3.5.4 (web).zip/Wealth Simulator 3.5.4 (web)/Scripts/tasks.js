let challenge_hub_ui = document.getElementById("challenge-hub-ui");
let challenge_hub_menu_opt = document.getElementById("personl-challenges-menu-opt");
let close_challenge_hub_ui_opt = document.getElementById("close-challenge-hub-ui-btn");

let task_award_grant_dialog_overlay = document.getElementById("task-award-grant-dialog-overlay");
let close_task_award_grant_dialog_btn = document.getElementById("close-task-award-grant-dialog-overlay-btn");
let tasks = document.getElementsByClassName("task-slot");
let total_tasks_completed = 0;
let current_tasks_pool = tasks.length;

let task_award_grant_output_1 = document.getElementById("task-award-output-1");
let task_award_grant_output_2 = document.getElementById("task-award-output-2");
let task_award_grant_output_3 = document.getElementById("task-award-output-3");
let task_award_grant_output_4 = document.getElementById("task-award-output-4");

// TASKS PROGRESS VALUES

let task_1_progress = 0;
let task_2_progress = 0;
let task_3_progress = 0;
let task_4_progress = 0;
let task_5_progress = 0;
let task_6_progress = 0;
let task_7_progress = 0;

let task_1_active = true;
let task_2_active = true;
let task_3_active = true;
let task_4_active = true;
let task_5_active = true;
let task_6_active = true;
let task_7_active = true;

let task_1_completion_status = false;
let task_2_completion_status = false;
let task_3_completion_status = false;
let task_4_completion_status = false;
let task_5_completion_status = false;
let task_6_completion_status = false;
let task_7_completion_status = false;

let task_1_progress_bar = document.getElementById("task-1-progress-bar");
let task_2_progress_bar = document.getElementById("task-2-progress-bar");
let task_3_progress_bar = document.getElementById("task-3-progress-bar");
let task_4_progress_bar = document.getElementById("task-4-progress-bar");
let task_5_progress_bar = document.getElementById("task-5-progress-bar");
let task_6_progress_bar = document.getElementById("task-6-progress-bar");
let task_7_progress_bar = document.getElementById("task-7-progress-bar");

let task_1_slot = document.getElementById("task-slot-1");
let task_2_slot = document.getElementById("task-slot-2");
let task_3_slot = document.getElementById("task-slot-3");
let task_4_slot = document.getElementById("task-slot-4");
let task_5_slot = document.getElementById("task-slot-5");
let task_6_slot = document.getElementById("task-slot-6");
let task_7_slot = document.getElementById("task-slot-7");

let task_1_claim_award_opt = document.getElementById("claim-task-1-award");
let task_2_claim_award_opt = document.getElementById("claim-task-2-award");
let task_3_claim_award_opt = document.getElementById("claim-task-3-award");
let task_4_claim_award_opt = document.getElementById("claim-task-4-award");
let task_5_claim_award_opt = document.getElementById("claim-task-5-award");
let task_6_claim_award_opt = document.getElementById("claim-task-6-award");
let task_7_claim_award_opt = document.getElementById("claim-task-7-award");

let task_claim_award_opts_storage = [task_1_claim_award_opt, task_2_claim_award_opt, task_3_claim_award_opt, task_4_claim_award_opt, task_5_claim_award_opt, task_6_claim_award_opt, task_7_claim_award_opt];

let task_1_claim_status = false;
let task_2_claim_status = false;
let task_3_claim_status = false;
let task_4_claim_status = false;
let task_5_claim_status = false;
let task_6_claim_status = false;
let task_7_claim_status = false;

let task_1_percent_output = document.getElementById("task-1-percent-progress-output");
let task_2_percent_output = document.getElementById("task-2-percent-progress-output");
let task_3_percent_output = document.getElementById("task-3-percent-progress-output");
let task_4_percent_output = document.getElementById("task-4-percent-progress-output");
let task_5_percent_output = document.getElementById("task-5-percent-progress-output");
let task_6_percent_output = document.getElementById("task-6-percent-progress-output");
let task_7_percent_output = document.getElementById("task-7-percent-progress-output");


function setTaskClaimButtonState(button, isCompleted, isClaimed) {
    if (!button) {
        return;
    }

    const isDisabled = !isCompleted || isClaimed;
    button.disabled = isDisabled;
    button.style.cursor = isDisabled ? "not-allowed" : "pointer";
    button.style.opacity = isDisabled ? "0.5" : "1";
    button.innerHTML = isClaimed ? "CLAIMED" : "CLAIM AWARD";
}
function syncTaskClaimButtons() {
    setTaskClaimButtonState(task_1_claim_award_opt, task_1_completion_status, task_1_claim_status);
    setTaskClaimButtonState(task_2_claim_award_opt, task_2_completion_status, task_2_claim_status);
    setTaskClaimButtonState(task_3_claim_award_opt, task_3_completion_status, task_3_claim_status);
    setTaskClaimButtonState(task_4_claim_award_opt, task_4_completion_status, task_4_claim_status);
    setTaskClaimButtonState(task_5_claim_award_opt, task_5_completion_status, task_5_claim_status);
    setTaskClaimButtonState(task_6_claim_award_opt, task_6_completion_status, task_6_claim_status);
    setTaskClaimButtonState(task_7_claim_award_opt, task_7_completion_status, task_7_claim_status);
}

function hideAwardOverlay() {
    document.getElementById("task-award-grant-dialog-overlay").style.display = "none";
}

challenge_hub_menu_opt.onclick = function() { setTimeout(() => { challenge_hub_ui.style.display = "flex"; }, 250); UiClosure(); }

close_challenge_hub_ui_opt.onclick = function() {
    challenge_hub_ui.style.display = "none";
}

close_task_award_grant_dialog_btn.onclick = function() { 
    task_award_grant_dialog_overlay.style.display = "none"; 
}

function taskAwardsGrantNotification(task_award_1, task_award_2, task_award_3) {
    let double_farm_income = 10;
    let double_farm_speed = 15;
    let triple_farm_income = 20;
    let instant_lvl_xp = 25;
    let double_lvl_xp = 30;
    let random_booster_award = Math.floor(Math.random() * 50);
    addPlayerLvlXp(task_award_3);
    console.log(random_booster_award);
    task_award_grant_dialog_overlay.style.display = "flex";

    if (random_booster_award === 10) { inventory_slot_1_player_owned_amount++; task_award_grant_output_4.innerHTML = "[<span style='color: orange'>BOOSTER</span>] > DOUBLE (X2) FARM INCOME" }
    if (random_booster_award === 15) { inventory_slot_3_player_owned_amount++; task_award_grant_output_4.innerHTML = "[<span style='color: orange'>BOOSTER</span>] > DOUBLE (X2) FARM SPEED" }
    if (random_booster_award === 20) { inventory_slot_2_player_owned_amount++; task_award_grant_output_4.innerHTML = "[<span style='color: orange'>BOOSTER</span>] > TRIPLE (X3) FARM INCOME" }
    if (random_booster_award === 25) { inventory_slot_6_player_owned_amount++; task_award_grant_output_4.innerHTML = "[<span style='color: orange'>BOOSTER</span>] > INSTANT LEVEL UP" }
    if (random_booster_award === 30) { inventory_slot_7_player_owned_amount++; task_award_grant_output_4.innerHTML = "[<span style='color: orange'>BOOSTER</span>] > DOUBLE (X2) LEVEL UP"}

    task_award_grant_output_1.innerHTML = "<h4 style='color: springgreen;'> CASH > $" + formatMoneyValue(task_award_1) + "</h4>";
    task_award_grant_output_2.innerHTML = "<h4 style='color: yellow;'> COINS > " + task_award_2 + "</h4>";
    task_award_grant_output_3.innerHTML = "<h4 style='color: springgreen;'>" + task_award_3 + "<span style='color: greenyellow;'>XP" + "</span></h4>";
}

for (let i = 0; i < task_claim_award_opts_storage.length; i++) {
    task_claim_award_opts_storage[i].addEventListener("click", function() {
        setTimeout(() => { hideAwardOverlay(); }, 5000);
        task_award_grant_output_4.innerHTML = "";
    });
}

task_1_claim_award_opt.onclick = function() {
    task_1_claim_status = true;
    taskAwardsGrantNotification(50, 15, 200);
    collectTaskAwardAudio();
    syncTaskClaimButtons();
    notificationDialog("AWARDS CREDITED!", 2500);
}

task_2_claim_award_opt.onclick = function() {
    task_2_claim_status = true;
    taskAwardsGrantNotification(25, 25, 200);
    player_cash_balance += 25;
    player_coins_balance += 25;
    collectTaskAwardAudio();
    syncTaskClaimButtons();
    notificationDialog("AWARDS CREDITED!", 2500);
}

task_3_claim_award_opt.onclick = function() {
    task_3_claim_status = true;
    taskAwardsGrantNotification(100, 50, 500);
    player_cash_balance += 65;
    player_coins_balance += 20;
    collectTaskAwardAudio();
    syncTaskClaimButtons();
    notificationDialog("AWARDS CREDITED!", 2500);
}

task_4_claim_award_opt.onclick = function() {
    task_4_claim_status = true;
    taskAwardsGrantNotification(20, 10, 150);
    player_cash_balance += 20;
    player_coins_balance += 10;
    collectTaskAwardAudio();
    syncTaskClaimButtons();
    notificationDialog("AWARDS CREDITED!", 2500);
}

task_5_claim_award_opt.onclick = function() {
    task_5_claim_status = true;
    taskAwardsGrantNotification(50, 25, 100);
    player_cash_balance += 50;
    player_coins_balance += 25;
    collectTaskAwardAudio();
    syncTaskClaimButtons();
    notificationDialog("AWARDS CREDITED!", 2500);
}

task_6_claim_award_opt.onclick = function() {
    task_6_claim_status = true;
    taskAwardsGrantNotification(25, 25, 120);
    player_cash_balance += 25;
    player_coins_balance += 25;
    collectTaskAwardAudio();
    syncTaskClaimButtons();
    notificationDialog("AWARDS CREDITED!", 2500);
}

task_7_claim_award_opt.onclick = function() {
    task_7_claim_status = true;
    taskAwardsGrantNotification(50, 25, 150);
    player_cash_balance += 50;
    player_coins_balance += 25;
    collectTaskAwardAudio();
    syncTaskClaimButtons();
    notificationDialog("AWARDS CREDITED!", 2500);
}