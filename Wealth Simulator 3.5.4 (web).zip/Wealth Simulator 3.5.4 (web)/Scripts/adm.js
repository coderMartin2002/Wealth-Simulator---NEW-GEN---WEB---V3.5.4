let buildVersion = "3.5.4";

let mods_opt = document.getElementById("mod-opt");
let mods_ui = document.getElementById("mods-ui");
let close_mods_ui_btn = document.getElementById("close-mods-ui-btn");

let mods_access_dialog_overlay = document.getElementById("mods-access-dialog-overlay");
let close_mods_access_dialog_overlay_btn = document.getElementById("close-mods-access-dialog-overlay-btn");
let mods_access_inp = document.getElementById("mods-access-inp");
let mods_access_btn = document.getElementById("submit-key-btn");

let mod_installation_dialog_overlay = document.getElementById("mod-installation-dialog-overlay");
let mod_installation_progress_bar = document.getElementById("mod-installation-progress");
let mod_type_installation_output = document.getElementById("mod-type-installation-output");
let mod_installation_progress_percent_output = document.getElementById("mod-installation-progress-percent-output");
let mod_installation_prefix = "INSTALLING ";

let install_mod_1_opt = document.getElementById("install-mod-1-opt");
let install_mod_2_opt = document.getElementById("install-mod-2-opt");
let install_mod_3_opt = document.getElementById("install-mod-3-opt");
let install_mod_4_opt = document.getElementById("install-mod-4-opt");

let mod_1_installed = false;
let mod_2_installed = false;
let mod_3_installed = false;
let mod_4_installed = false;

close_mods_access_dialog_overlay_btn.onclick = function() { mods_access_dialog_overlay.style.display = "none" }

mods_access_btn.onclick = function() {
    if (parseInt(mods_access_inp.value) === 1975) {
        document.getElementById("inventory-ui").style.display = "none";
        document.getElementById("store-ui").style.display = "none";
        document.getElementById("fund-farms-ui").style.display = "none";
        document.getElementById("guessing-game-ui").style.display = "none";
        document.getElementById("upgrades-hub-ui").style.display = "none";
        document.getElementById("gambling-hub-ui").style.display = "none";
        document.getElementById("settings-ui").style.display = "none";
        document.getElementById("gambling-hub-ui-2").style.display = "none";
        document.getElementById("slot-selection-dialog-overlay").style.display = "none";
        document.getElementById("timed-dif-timer-mod-dialog-overlay").style.display = "none";
        document.getElementById("dif-info-panel").style.display = "none";
        mods_access_inp.value = "";
        mods_access_dialog_overlay.style.display = "none";
        mods_ui.style.display = "flex";
        trivia_hub_ui.style.display = "none";
        bank_ui.style.display = "none";
        updates_hub_ui.style.display = "none";
        challenge_hub_ui.style.display = "none";
        console_ui.style.display = "none";
        perks_station_ui.style.display = "none";
    } else {
        notificationDialog("INCORRECT ADMIN KEY!", 3000);
        upgradePurchaseFailedAudio();
    }
}

mods_opt.onclick = function() { 
    mods_access_dialog_overlay.style.display = "flex";
}

close_mods_ui_btn.onclick = function() { mods_ui.style.display = "none"; }

install_mod_1_opt.onclick = function() { installMod("mod-1"); keyboardClickAudio(); }
install_mod_2_opt.onclick = function() { installMod("mod-2"); keyboardClickAudio(); }
install_mod_3_opt.onclick = function() { installMod("mod-3"); keyboardClickAudio(); }
install_mod_4_opt.onclick = function() { installMod("mod-4"); keyboardClickAudio(); }

function modInstallationSetup(mod_type) {
    setTimeout(() => {
        let mod_installation_int = setInterval(() => {
            mod_installation_progress_bar.value += Math.floor(Math.random() * 10) + 10;
            mod_installation_progress_percent_output.innerHTML = "<span style='color: springgreen;'>" + mod_installation_progress_bar.value + "</span>" + "%";
            mod_type_installation_output.innerHTML = "<span style='color: springgreen;'>" + mod_installation_prefix + "</span>" + mod_type;

            if (mod_installation_progress_bar.value === 100) {
                clearInterval(mod_installation_int);
                mod_installation_progress_bar.value = 0;
                bonusWinAudio();
                mod_type_installation_output.innerHTML = "<span style='color: yellow';>" + "INSTALLATION COMPLETE!" + "</span>";
                setTimeout(() => { mod_installation_dialog_overlay.style.display = "none"; }, 2000)
            }
        }, 500)
    }, 1000)
}

function loadDomViewer(onLoad, onError) {
    const dom_viewer_script = document.getElementById("dom-viewer-script");
    if (!dom_viewer_script) {
        console.error("Cannot load DOM viewer: script element is missing.");
        onError();
        return;
    }

    if (dom_viewer_script.dataset.loaded === "true") {
        onLoad();
        return;
    }

    dom_viewer_script.addEventListener("load", function() {
        dom_viewer_script.dataset.loaded = "true";
        onLoad();
    }, { once: true });
    dom_viewer_script.addEventListener("error", function() {
        console.error("Failed to load DOM viewer script.", dom_viewer_script.src);
        onError();
    }, { once: true });
    dom_viewer_script.src = "Scripts/dom-viewer.js";
}

function installMod(mod_id) {
    switch (mod_id) {
        case "mod-1": // CURRENCY MOD
            setTimeout(() => { mod_installation_dialog_overlay.style.display = "flex"; }, 1000)
            modInstallationSetup("DOM || HTML INSPECTOR (MOD)");
            install_mod_1_opt.disabled = true;
            install_mod_1_opt.style.cursor = "not-allowed";
            install_mod_1_opt.style.opacity = "0.5";
            setTimeout(() => {
                loadDomViewer(function() {
                    mod_1_installed = true;
                    autoSave();
                    install_mod_1_opt.innerHTML = "<span style='color: lime;'>INSTALLED</span>";
                    install_mod_1_opt.style.opacity = "1";
                }, function() {
                    mod_1_installed = false;
                    install_mod_1_opt.disabled = false;
                    install_mod_1_opt.style.cursor = "pointer";
                    install_mod_1_opt.style.opacity = "1";
                    notificationDialog("DOM inspector installation failed. Please try again.", 4000);
                });
            }, 2000)
            break;
        case "mod-2":
            setTimeout(() => { mod_installation_dialog_overlay.style.display = "flex"; }, 1000)
            modInstallationSetup("TRIVIA MOD");
            mod_2_installed = true;
            setTimeout(() => {
                setInterval(() => {
                    trivia_reward_multiplier = 999;
                    install_mod_2_opt.innerHTML = "<span style='color: lime;'>INSTALLED</span>";
                    install_mod_2_opt.disabled = true; install_mod_2_opt.style.cursor = "not-allowed";
                }, 100)
            }, 5000)
            break;
        case "mod-3":
            setTimeout(() => { mod_installation_dialog_overlay.style.display = "flex"; }, 1000)
            modInstallationSetup("UNLIMITED BONUSES MOD");
            mod_3_installed = true;
            setTimeout(() => {
                inventory_slot_5_player_owned_amount += 999;
                inventory_slot_10_player_owned_amount += 999;
                install_mod_3_opt.innerHTML = "<span style='color: lime;'>INSTALLED</span>";
                install_mod_3_opt.disabled = true; install_mod_3_opt.style.cursor = "not-allowed";
            }, 5000)
            break;
        case "mod-4":
            setTimeout(() => { mod_installation_dialog_overlay.style.display = "flex"; }, 1000)
            modInstallationSetup("Well there goes your grind lol!");
            mod_4_installed = true;
            setTimeout(() => {
                player_tycoon_score += 999999999;
                player_booster_tokens += 50;
                current_loan_debt_limit = 1000000000000000000000;
                custom_loan_max = 999999999999999999999999;
                inventory_slot_1_player_owned_amount += 99999;
                inventory_slot_2_player_owned_amount += 99999;
                inventory_slot_3_player_owned_amount += 99999;
                inventory_slot_4_player_owned_amount += 99999;
                inventory_slot_5_player_owned_amount += 99999;
                inventory_slot_6_player_owned_amount += 99999;
                inventory_slot_7_player_owned_amount += 99999;
                inventory_slot_8_player_owned_amount += 99999;
                inventory_slot_9_player_owned_amount += 99999;
                inventory_slot_10_player_owned_amount += 99999;
                inventory_slot_11_player_owned_amount += 99999;
                inventory_slot_12_player_owned_amount += 99999;
                inventory_slot_13_player_owned_amount += 99999;

                player_cash_balance += 999999999;
                player_coins_balance += 999999999;
                player_diamond_balance += 999999999;
                player_tycoon_score += 999999999;
                player_booster_tokens += 999999999;

                cash_2_probability = 2;
                coin_2_probability = 2;
                diamond_2_probability = 2;

                jack_2_probability = 2;
                queen_2_probability = 2;
                king_2_probability = 2;

                triple_coins_probability = 2;
                star_probability = 2;

                user_set_cash_award = 999;
                user_set_max_attempts = 999;
                user_set_score_award = 999;
                user_set_trivia_dif = 999;
                user_set_trivia_dif_txt = "ADMIN";
                user_trivia_attempts = 999;
                trivia_reward_multiplier = 999;

                upgradePurchasedAudio();
            }, 5000)
            break;
    }
}

function xNkLY78C() {
    document.getElementById("admin-panel-dialog-overlay").style.display = "flex";
}

function readAdminNumber(id) {
    const input = document.getElementById(id);
    const value = input ? parseInt(input.value, 10) : NaN;
    return Number.isNaN(value) ? 0 : value;
}

function apply() {
    player_cash_balance += readAdminNumber("admin-cash-inp");
    player_coins_balance += readAdminNumber("admin-coin-inp");
    player_diamond_balance += readAdminNumber("admin-diamond-inp");
    player_lvl += readAdminNumber("admin-lvl-inp");
}

const adminPanelCloseButtons = document.querySelectorAll("#close-admin-panel-dialog-overlay-btn");
adminPanelCloseButtons.forEach(function(button) {
    button.onclick = function() {
        document.getElementById("admin-panel-dialog-overlay").style.display = "none";
    }
});

document.getElementById("admin-update-stats-btn").onclick = function() {
    apply();
    bonusWinAudio();
    notificationDialog("Stats updated!", 3500);
};
