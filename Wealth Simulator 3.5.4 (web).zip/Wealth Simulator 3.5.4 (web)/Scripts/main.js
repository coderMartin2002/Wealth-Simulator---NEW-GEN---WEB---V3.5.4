let all_btns = document.querySelectorAll("button");

// CONSOLE PIN STATUS SESSION CHECKER

function console_pin_used_status_checker(input) {
    if (input === c_p_1.toString() && c_p_1_used === true) {
        upgradePurchaseFailedAudio();
        notificationDialog("You already used this pin!", 3500);
        return true;
    } else if (input === c_p_2.toString() && c_p_2_used === true) {
        upgradePurchaseFailedAudio();
        notificationDialog("You already used this pin!", 3500);
        return true;
    } else if (input === c_p_3.toString() && c_p_3_used === true) {
        upgradePurchaseFailedAudio();
        notificationDialog("You already used this pin!", 3500);
        return true;
    }
    return false;
}

// UNIVERSAL HELPER FOR MULTI-PURCHASE INVESTMENT OPTIONS

function purchaseMultiUpgrade(upgrade_price, multi_purchase_multiplier, board_grant_amount, board_xp_grant_amount, purchase_dialog_overlay_id, currency_type = "cash") {
    const multi_purchase_price = upgrade_price * multi_purchase_multiplier;
    const multi_purchase_grant_amount = board_grant_amount * multi_purchase_multiplier;
    const usingCoins = currency_type === "coins";
    const currentBalance = usingCoins ? player_coins_balance : player_cash_balance;

    if (currentBalance >= multi_purchase_price) {
        if (usingCoins) {
            player_coins_balance = Math.round((player_coins_balance - multi_purchase_price) * 100) / 100;
        } else {
            player_cash_balance = Math.round((player_cash_balance - multi_purchase_price) * 100) / 100;
        }
        total_passive_income_pool += multi_purchase_grant_amount;
        addPlayerLvlXp(board_xp_grant_amount);
        notificationDialog("Credited $" + formatMoneyValue(board_grant_amount * multi_purchase_multiplier) + " to passive income pool!", 3000);
        setTimeout(() => { notificationDialog("[TOTAL] > $" + formatMoneyValue(multi_purchase_price) + " DEDUCTED FROM YOUR BALANCE!", 3500) }, 3000)
        setTimeout(() => { 
            purchase_dialog_overlay_id.style.display = "none"; 
            for (let i = 0; i < upgrade_purchase_btns_storage.length; i++) {
                setTimeout(() => {
                    upgrade_purchase_btns_storage[i].disabled = false;
                    upgrade_purchase_btns_storage[i].style.cursor = "pointer";
                    upgrade_purchase_btns_storage[i].style.opacity = "1";
                }, 1000)
            }
        }, 1000);
        upgradePurchasedAudio();
    } else {
        notificationDialog("Insufficient Funds! Total > $" + formatMoneyValue(multi_purchase_price) + " required!", 3000);
        insufficientFundsAudio();
    }
}

// UNIVERSAL DIALOG OVERLAY CREATOR

function notificationDialog(msg, msg_int) {
    const notify = document.createElement("div");
    notify.innerHTML = msg;
    notify.style.width = "fit-content";
    notify.style.height = "70px";
    notify.style.padding = "10px";
    notify.style.fontSize = "20px";
    notify.style.fontFamily = "'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva";
    notify.style.backgroundImage = "linear-gradient(rgba(6, 3, 21, 0.9), rgba(40, 3, 29, 0.9))";
    notify.style.display = "flex";
    notify.style.justifyContent = "center";
    notify.style.alignItems = "center";
    
    Object.assign(notify.style, {
        position: "fixed", top: "30px", left: "50%", transform: "translateX(-50%)",
        backgroundColor: "#111", color: "white", padding: "12px 24px", borderRadius: "8px",
        border: "2px solid yellow", fontWeight: "bold", zIndex: "9999",
        transition: "all 1s ease", pointerEvents: "none", boxShadow: "0 0 15px rgb(255, 1, 196)"
    });

    document.body.appendChild(notify);

    setTimeout(() => {
        notify.style.opacity = "0";
        notify.style.top = "10px";
    }, msg_int);
    
    setTimeout(() => notify.remove(), msg_int + 1000);
}

// DISPLAY NUMBER FORMATTER (INSERTED BY COPILOT)

function formatDisplayNumber(value, minimumFractionDigits = 0, maximumFractionDigits = 0) {
    const numericValue = Number(value);
    if (!Number.isFinite(numericValue)) {
        return "0";
    }
    return numericValue.toLocaleString("en-US", {
        minimumFractionDigits,
        maximumFractionDigits
    });
}

// CURRENCY FORMATTER (ADDED BY COPILOT)

function formatMoneyValue(value) {
    return formatDisplayNumber(value, 2, 2);
}

// UNIVERSAL UPGRADE HELPER

function purchaseUpgrade(upgrade_price, board_grant_amount, board_xp_grant_amount, purchase_dialog_overlay_id, currency_type = "cash") {
    const usingCoins = currency_type === "coins";
    const currentBalance = usingCoins ? player_coins_balance : player_cash_balance;

    if (currentBalance >= upgrade_price) {
        if (usingCoins) {
            player_coins_balance = Math.round((player_coins_balance - upgrade_price) * 100) / 100;
        } else {
            player_cash_balance = Math.round((player_cash_balance - upgrade_price) * 100) / 100;
        }
        total_passive_income_pool += board_grant_amount;
        player_tycoon_score += 5;
        addPlayerLvlXp(board_xp_grant_amount);
        notificationDialog("Credited $" + formatMoneyValue(board_grant_amount) + " to passive income pool!", 3000);
        setTimeout(() => { 
            purchase_dialog_overlay_id.style.display = "none"; 
            for (let i = 0; i < upgrade_purchase_btns_storage.length; i++) {
                setTimeout(() => {
                    upgrade_purchase_btns_storage[i].disabled = false;
                    upgrade_purchase_btns_storage[i].style.cursor = "pointer";
                    upgrade_purchase_btns_storage[i].style.opacity = "1";
                }, 1000)
            }
        }, 1000);
        upgradePurchasedAudio();
    } else {
        notificationDialog("Insufficient Funds!", 3000);
        upgradePurchaseFailedAudio();
    }
}

function disableFarmCollectOpt(farm_collect_opt) {
    farm_collect_opt.disabled = true;
    farm_collect_opt.style.opacity = "0.5";
    farm_collect_opt.style.cursor = "not-allowed";
    farm_collect_opt.style.fontWeight = "normal";
}

function enableFarmCollectOpt(farm_collect_opt) {
    farm_collect_opt.disabled = false;
    farm_collect_opt.style.opacity = "1";
    farm_collect_opt.style.cursor = "pointer";
    farm_collect_opt.style.fontWeight = "bold";
}

function increaseProgressBar(progressBar, amount = 1) {
    if (!progressBar) return false;
    const maxValue = Number(progressBar.max) || 100;
    const nextValue = Math.min(Number(progressBar.value) + amount, maxValue);
    progressBar.value = nextValue;
    return nextValue >= maxValue;
}

function increaseProgressValue(progressValue, progressBar, amount = 1) {
    const maxValue = Number(progressBar?.max) || 100;
    const incrementAmount = typeof amount === "number" ? amount : 1;
    return Math.min(progressValue + incrementAmount, maxValue);
}

// UNIVERSAL HELPER FOR COLLECTING FUND FARMS

function collectFundFarm(farm_cash_amount, farm_collect_int, farm_collect_opt, farm_progress_bar, farm_progress_int, inc_total_cash_earned) {
    player_cash_balance = Math.round((player_cash_balance + farm_cash_amount) * 100) / 100;
    total_fund_farm_clicks++;
    total_fund_farm_cash_earned += farm_cash_amount;
    inc_total_cash_earned += farm_cash_amount;
    farm_progress_bar.value = 0;
    clearInterval(farm_progress_int);
    oscClickAudio();
    setTimeout(() => { collectFarmAudio(); }, 50)
    disableFarmCollectOpt(farm_collect_opt);

    const targetValue = Number(farm_progress_bar.max) || 100;
    const progressInterval = setInterval(function() {
        farm_progress_bar.value += 1;
        fundFarmsStatusChecker(farm_progress_bar, farm_collect_opt, progressInterval, targetValue);
    }, farm_collect_int);

    return progressInterval;
}

function collectFundFarm2(tier_3_farm_cash_amount, tier_3_farm_collect_int, tier_3_farm_collect_opt, tier_3_farm_progress_bar, tier_3_farm_progress_int, tier_3_inc_total_cash_earned) {
    player_coins_balance = Math.round((player_coins_balance + tier_3_farm_cash_amount) * 100) / 100;
    total_fund_farm_clicks++;
    total_fund_farm_cash_earned += tier_3_farm_cash_amount;
    tier_3_inc_total_cash_earned += tier_3_farm_cash_amount;
    tier_3_farm_progress_bar.value = 0;
    clearInterval(tier_3_farm_progress_int);
    oscClickAudio();
    setTimeout(() => { collectFarmAudio(); }, 50)
    disableFarmCollectOpt(tier_3_farm_collect_opt);

    const targetValue = Number(tier_3_farm_progress_bar.max) || 100;
    const progressInterval = setInterval(function() {
        tier_3_farm_progress_bar.value += 1;
        fundFarmsStatusChecker(tier_3_farm_progress_bar, tier_3_farm_collect_opt, progressInterval, targetValue);
    }, tier_3_farm_collect_int);

    return progressInterval;
}

// FUND FARMS COLLECTION STATUS CHECKER

function fundFarmsStatusChecker(progressBar, collectOpt, progressInterval, targetValue) {
    if (progressBar.value < targetValue) {
        disableFarmCollectOpt(collectOpt);
    } else {
        progressBar.value = targetValue; // Cap at max
        enableFarmCollectOpt(collectOpt);
        clearInterval(progressInterval);
        //console.log("test");
    } 
}

// UNIVERSAL HELPER FOR USING X2 + X3 FARM INCOME BOOSTERS IN INVENTORY

function useInventoryBooster(inventory_slot_id, inventory_slot_use_btn, farm_cash_increase_amount, inventory_slot_booster_duration_int, booster_notification_msg, booster_duration_end_msg) {
    let ownedAmount;

    if (inventory_slot_id === 1) {
        ownedAmount = inventory_slot_1_player_owned_amount;
    } else if (inventory_slot_id === 2) {
        ownedAmount = inventory_slot_2_player_owned_amount;
    }

    if (ownedAmount > 0) {
        if (inventory_slot_id === 1) {
            inventory_slot_1_player_owned_amount--;
        } else if (inventory_slot_id === 2) {
            inventory_slot_2_player_owned_amount--;
        }

        farm_1_cash_amount *= farm_cash_increase_amount;
        farm_2_cash_amount *= farm_cash_increase_amount;
        farm_3_cash_amount *= farm_cash_increase_amount;
        farm_4_cash_amount *= farm_cash_increase_amount;
        farm_5_cash_amount *= farm_cash_increase_amount;
        farm_6_cash_amount *= farm_cash_increase_amount;

        if (tier_2_farm_unlocked) {
            tier_2_farm_1_cash_amount *= farm_cash_increase_amount;
            tier_2_farm_2_cash_amount *= farm_cash_increase_amount;
            tier_2_farm_3_cash_amount *= farm_cash_increase_amount;
            tier_2_farm_4_cash_amount *= farm_cash_increase_amount;
            tier_2_farm_5_cash_amount *= farm_cash_increase_amount;
            tier_2_farm_6_cash_amount *= farm_cash_increase_amount;
        }

        inventory_slot_use_btn.disabled = true;
        inventory_slot_use_btn.style.cursor = "not-allowed";
        inventory_slot_use_btn.style.opacity = "0.5";

        setTimeout(() => {
            farm_1_cash_amount = 0.05; farm_2_cash_amount = 0.10; farm_3_cash_amount = 0.20;
            farm_4_cash_amount = 0.40; farm_5_cash_amount = 0.60; farm_6_cash_amount = 1.20;

            tier_2_farm_1_cash_amount = 0.15; tier_2_farm_2_cash_amount = 0.30; tier_2_farm_3_cash_amount = 0.60;
            tier_2_farm_4_cash_amount = 1.20; tier_2_farm_5_cash_amount = 1.80; tier_2_farm_6_cash_amount = 3.00;

            inventory_slot_use_btn.disabled = false;
            inventory_slot_use_btn.style.cursor = "pointer";
            inventory_slot_use_btn.style.opacity = "1";

            notificationDialog(booster_duration_end_msg, 4000);
        }, inventory_slot_booster_duration_int)

        notificationDialog(booster_notification_msg, 3000);
    } else {
        upgradePurchaseFailedAudio();
        setTimeout(() => { boosterUnavailableAudio(); }, 500);
        notificationDialog("NO BOOSTER AVAILABLE!", 3000);
        setTimeout(() => { notificationDialog("Purchaseable in the store!" , 3000); }, 3000)
    }
}


// UNIVERSAL HELPER FOR PURCHASING FUND FARMS AUTO-COLLECT

function purchaseFarmAutoCollect(farm_auto_opt, farm_auto_collect_overlay, farm_row_ref_text, farm_auto_purchase_btn, farm_auto_price_value, farm_auto_state_key, farm_collect_opt) {
    // Open overlay and populate values for the specific farm
    farm_auto_collect_overlay.style.display = "flex";

    // Find the row/price outputs inside the overlay (use querySelector scoped to overlay)
    let rowOutput = farm_auto_collect_overlay.querySelector('#farm-auto-row-output');
    let priceOutput = farm_auto_collect_overlay.querySelector('#farm-auto-perk-price-output');

    if (rowOutput) rowOutput.innerHTML = farm_row_ref_text;
    if (priceOutput) priceOutput.innerHTML = "<span style='color: yellow'>PRICE >> <span style='color: lime'>$" + formatMoneyValue(farm_auto_price_value) + "</span></span>";

    // Wire the purchase button for this overlay
    farm_auto_purchase_btn.onclick = function() {
        if (player_cash_balance >= farm_auto_price_value) {
            player_cash_balance -= farm_auto_price_value;
            // set the actual `farm_n_auto_state` variable by name so persistence works
            if (typeof farm_auto_state_key === 'string') {
                switch (farm_auto_state_key) {
                    case 'farm_1_auto_state': farm_1_auto_state = true; break;
                    case 'farm_2_auto_state': farm_2_auto_state = true; break;
                    case 'farm_3_auto_state': farm_3_auto_state = true; break;
                    case 'farm_4_auto_state': farm_4_auto_state = true; break;
                    case 'farm_5_auto_state': farm_5_auto_state = true; break;
                    case 'farm_6_auto_state': farm_6_auto_state = true; break;

                    case 'tier_2_farm_1_auto_state': tier_2_farm_1_auto_state = true; break;
                    case 'tier_2_farm_2_auto_state': tier_2_farm_2_auto_state = true; break;
                    case 'tier_2_farm_3_auto_state': tier_2_farm_3_auto_state = true; break;
                    case 'tier_2_farm_4_auto_state': tier_2_farm_4_auto_state = true; break;
                    case 'tier_2_farm_5_auto_state': tier_2_farm_5_auto_state = true; break;
                    case 'tier_2_farm_6_auto_state': tier_2_farm_6_auto_state = true; break;

                    case 'tier_3_farm_1_auto_state': tier_3_farm_1_auto_state = true; break;
                    case 'tier_3_farm_2_auto_state': tier_3_farm_2_auto_state = true; break;
                    case 'tier_3_farm_3_auto_state': tier_3_farm_3_auto_state = true; break;
                    case 'tier_3_farm_4_auto_state': tier_3_farm_4_auto_state = true; break;
                    case 'tier_3_farm_5_auto_state': tier_3_farm_5_auto_state = true; break;
                    case 'tier_3_farm_6_auto_state': tier_3_farm_6_auto_state = true; break;
                    default: break;
                }
            }
            upgradePurchasedAudio();

            farm_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
            farm_auto_opt.disabled = true;
            farm_auto_opt.style.cursor = "not-allowed";
            farm_auto_collect_overlay.style.display = "none";

            let tempAutoInt = setInterval(() => {
                farm_collect_opt.click();
            }, 500);

            // store the auto-click interval in the matching global variable
            if (typeof farm_auto_state_key === 'string') {
                switch (farm_auto_state_key) {
                    case 'farm_1_auto_state': farm_1_auto_int = tempAutoInt; break;
                    case 'farm_2_auto_state': farm_2_auto_int = tempAutoInt; break;
                    case 'farm_3_auto_state': farm_3_auto_int = tempAutoInt; break;
                    case 'farm_4_auto_state': farm_4_auto_int = tempAutoInt; break;
                    case 'farm_5_auto_state': farm_5_auto_int = tempAutoInt; break;
                    case 'farm_6_auto_state': farm_6_auto_int = tempAutoInt; break;

                    case 'tier_2_farm_1_auto_state': tier_2_farm_1_auto_int = tempAutoInt; break;
                    case 'tier_2_farm_2_auto_state': tier_2_farm_2_auto_int = tempAutoInt; break;
                    case 'tier_2_farm_3_auto_state': tier_2_farm_3_auto_int = tempAutoInt; break;
                    case 'tier_2_farm_4_auto_state': tier_2_farm_4_auto_int = tempAutoInt; break;
                    case 'tier_2_farm_5_auto_state': tier_2_farm_5_auto_int = tempAutoInt; break;
                    case 'tier_2_farm_6_auto_state': tier_2_farm_6_auto_int = tempAutoInt; break;

                    case 'tier_3_farm_1_auto_state': tier_3_farm_1_auto_state = true; break;
                    case 'tier_3_farm_2_auto_state': tier_3_farm_2_auto_state = true; break;
                    case 'tier_3_farm_3_auto_state': tier_3_farm_3_auto_state = true; break;
                    case 'tier_3_farm_4_auto_state': tier_3_farm_4_auto_state = true; break;
                    case 'tier_3_farm_5_auto_state': tier_3_farm_5_auto_state = true; break;
                    case 'tier_3_farm_6_auto_state': tier_3_farm_6_auto_state = true; break;
                    default: break;
                }
            }

            // ensure we save immediately so state is persisted
            if (typeof autoSave === 'function') autoSave();

            notificationDialog("AUTO-COLLECT ACTIVATED!", 3000);
        } else {
            notificationDialog("Insufficient Funds!", 3000);
            upgradePurchaseFailedAudio();
        }
    }
}