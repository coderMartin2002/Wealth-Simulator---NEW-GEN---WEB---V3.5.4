const dom_hover_inspector_preference = document.getElementById("dom-hover-inspector-preference");
const DOM_HOVER_INSPECTOR_ADMIN_PIN = "113120";
let dom_hover_inspector_info = null;
let dom_hover_dimensions_info = null;
let dom_hover_inspected_element = null;

function inspectDomElement(event) {
    const element = event.target;
    if (!(element instanceof Element) || !dom_hover_inspector_info) {
        return;
    }

    if (dom_hover_inspected_element && dom_hover_inspected_element !== element) {
        dom_hover_inspected_element.classList.remove("dom-hover-inspected");
    }
    dom_hover_inspected_element = element;
    dom_hover_inspected_element.classList.add("dom-hover-inspected");
    dom_hover_inspector_info.textContent = element.outerHTML;
    dom_hover_inspector_info.style.display = "block";
    updateDomHoverDimensions(event);
}

function updateDomHoverDimensions(event) {
    if (!dom_hover_dimensions_info || !dom_hover_inspected_element) {
        return;
    }

    const bounds = dom_hover_inspected_element.getBoundingClientRect();
    dom_hover_dimensions_info.textContent =
        Math.round(bounds.width) + "px x " + Math.round(bounds.height) + "px";
    dom_hover_dimensions_info.style.display = "block";

    const margin = 12;
    const info_bounds = dom_hover_dimensions_info.getBoundingClientRect();
    let left = event.clientX + margin;
    let top = event.clientY + margin;
    if (left + info_bounds.width > window.innerWidth) {
        left = Math.max(margin, event.clientX - info_bounds.width - margin);
    }
    if (top + info_bounds.height > window.innerHeight) {
        top = Math.max(margin, event.clientY - info_bounds.height - margin);
    }
    dom_hover_dimensions_info.style.left = left + "px";
    dom_hover_dimensions_info.style.top = top + "px";
}

function hideDomHoverInfo(event) {
    if (event.relatedTarget === null && dom_hover_inspector_info) {
        dom_hover_inspector_info.style.display = "none";
        dom_hover_dimensions_info.style.display = "none";
        if (dom_hover_inspected_element) {
            dom_hover_inspected_element.classList.remove("dom-hover-inspected");
            dom_hover_inspected_element = null;
        }
    }
}

function setDomHoverInspectorEnabled(enabled) {
    if (enabled) {
        if (!dom_hover_inspector_info) {
            dom_hover_inspector_info = document.createElement("div");
            dom_hover_inspector_info.id = "dom-hover-inspector-info";
            document.body.appendChild(dom_hover_inspector_info);
        }
        if (!dom_hover_dimensions_info) {
            dom_hover_dimensions_info = document.createElement("div");
            dom_hover_dimensions_info.id = "dom-hover-dimensions-info";
            document.body.appendChild(dom_hover_dimensions_info);
        }
        document.addEventListener("pointerover", inspectDomElement, true);
        document.addEventListener("pointermove", updateDomHoverDimensions, true);
        document.addEventListener("pointerout", hideDomHoverInfo, true);
    } else {
        document.removeEventListener("pointerover", inspectDomElement, true);
        document.removeEventListener("pointermove", updateDomHoverDimensions, true);
        document.removeEventListener("pointerout", hideDomHoverInfo, true);
        if (dom_hover_inspected_element) {
            dom_hover_inspected_element.classList.remove("dom-hover-inspected");
            dom_hover_inspected_element = null;
        }
        if (dom_hover_inspector_info) {
            dom_hover_inspector_info.style.display = "none";
        }
        if (dom_hover_dimensions_info) {
            dom_hover_dimensions_info.style.display = "none";
        }
    }
}

dom_hover_inspector_preference.checked = localStorage.getItem("dom-hover-inspector-enabled") === "true";
dom_hover_inspector_preference.addEventListener("change", function() {
    const admin_pin = window.prompt("Enter the admin PIN to change the DOM hover inspector setting:");
    if (admin_pin !== DOM_HOVER_INSPECTOR_ADMIN_PIN) {
        dom_hover_inspector_preference.checked = !dom_hover_inspector_preference.checked;
        notificationDialog("Incorrect or cancelled admin PIN. Setting unchanged.", 3000);
        return;
    }

    localStorage.setItem("dom-hover-inspector-enabled", String(dom_hover_inspector_preference.checked));
    setDomHoverInspectorEnabled(dom_hover_inspector_preference.checked);
});
setDomHoverInspectorEnabled(dom_hover_inspector_preference.checked);