let wealthFarmsTutorialActive = false;

function tutorialFarmValueNullifier() {
    farm_1_cash_amount = 0;
    farm_2_cash_amount = 0;
    farm_3_cash_amount = 0;
    farm_4_cash_amount = 0;
    farm_5_cash_amount = 0;
    farm_6_cash_amount = 0;
}

function tutorialFarmValueRestorer() {
    farm_1_cash_amount = 0.05;
    farm_2_cash_amount = 0.10;
    farm_3_cash_amount = 0.20;
    farm_4_cash_amount = 0.40;
    farm_5_cash_amount = 0.60;
    farm_6_cash_amount = 1.20;
}

function tutorialFarmLevelProgressFiller() {
    farm_1_progress_bar.value = 100;
    farm_2_progress_bar.value = 100;
    farm_3_progress_bar.value = 100;
    farm_4_progress_bar.value = 100;
    farm_5_progress_bar.value = 100;
    farm_6_progress_bar.value = 100;
}

function wealthFarmsTutorial() {
    wealthFarmsTutorialActive = true;
    tutorialFarmValueNullifier();
    tutorialFarmLevelProgressFiller();
    farm_3_progress_bar.value = 100;
    farm_4_progress_bar.value = 100;
    farm_5_progress_bar.value = 100;
    farm_6_progress_bar.value = 100;

    notificationDialog("WELCOME TO THE WEALTH FARMS TUTORIAL!", 3000);
    setTimeout(() => { 
        notificationDialog("I'll guide you through the basics of farming currencies!", 3000);
        setTimeout(() => { fund_farms_opt_btn.click(); }, 2000);
        setTimeout(() => {
            notificationDialog("This is the Wealth Farms UI, where you can earn currencies and unlock higher tier farms!", 7000);
            setTimeout(() => {
                notificationDialog("Clicking on each farm will collect the available values!", 7000);
                tutorialFarmLevelProgressFiller();
                setTimeout(() => { farm_1_collect_opt.click(); }, 500);
                setTimeout(() => { farm_2_collect_opt.click(); }, 1000);
                setTimeout(() => { farm_3_collect_opt.click(); }, 1500);
                setTimeout(() => { farm_4_collect_opt.click(); }, 2000);
                setTimeout(() => { farm_5_collect_opt.click(); }, 2500);
                setTimeout(() => { farm_6_collect_opt.click(); }, 3000);

                setTimeout(() => {
                    let tier_list_tutorial_confirmation = confirm("Now that you've collected the available values, Check out the wealth farms menu of tiers! (Click OK to continue).");

                    if (tier_list_tutorial_confirmation) {
                        setTimeout(() => { document.getElementById("fund-farm-tiers-opt").click(); }, 1500)
                        setTimeout(() => {
                            notificationDialog("This is the Wealth Farms Tiers UI, where you can unlock higher tier farms and different currencies to farm!", 7000);
                            setTimeout(() => {
                                notificationDialog("Higher tier farms will yield multiplied income!", 7000);
                                setTimeout(() => {
                                    notificationDialog("You can permanently acquire higher tier farms via the Store!", 7000);
                                    setTimeout(() => { 
                                        store_menu_opt_btn.click(); 
                                        setTimeout(() => { document.getElementById("wealth-farms-section-opt").click(); }, 8500);
                                    }, 7500);
                                    setTimeout(() => { notificationDialog("This section lists all available wealth farms and their respective tiers.", 7000); }, 9500);
                                    setTimeout(() => { 
                                        notificationDialog("That's all for the tutorial! Enjoy the grind!", 7000);
                                        setTimeout(() => { 
                                            document.getElementById("close-farm-tiers-ui-opt").click();
                                            wealthFarmsTutorialActive = false;
                                            tutorialFarmValueRestorer();
                                        }, 1000);
                                    }, 16000);
                                }, 7500);
                            }, 5000);
                        }, 3500);
                    }
                }, 5000);
            }, 7500);
        }, 3500);
    }, 3500);
}