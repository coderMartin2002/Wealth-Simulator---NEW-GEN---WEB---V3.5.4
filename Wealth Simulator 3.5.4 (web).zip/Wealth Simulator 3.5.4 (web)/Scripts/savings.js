let savings_hub_opt = document.getElementById("savings-hub-opt");
let savings_hub_ui = document.getElementById("savings-hub-ui");
let close_savings_hub_ui_btn = document.getElementById("close-savings-hub-ui-btn");
let savings_balance_output = document.getElementById("savings-balance-output");

let transfer_amount_inp = document.getElementById("transfer-amount-inp");
let transfer_from_balance_to_savings_btn = document.getElementById("transfer-from-balance-to-savings-btn");

let withdrawal_amount_inp = document.getElementById("withdrawal-amount-inp");
let withdraw_from_savings_btn = document.getElementById("withdrawal-from-savings-to-cash-btn");

savings_hub_opt.addEventListener("click", () => {
    savings_hub_ui.style.display = "flex";
});

close_savings_hub_ui_btn.addEventListener("click", () => {
    savings_hub_ui.style.display = "none";
});

function disableTransferOpt() { transfer_from_balance_to_savings_btn.disabled = true; transfer_from_balance_to_savings_btn.style.opacity = "0.5"; transfer_from_balance_to_savings_btn.style.cursor = "not-allowed"; }
function enableTransferOpt() { transfer_from_balance_to_savings_btn.disabled = false; transfer_from_balance_to_savings_btn.style.opacity = "1"; transfer_from_balance_to_savings_btn.style.cursor = "pointer"; }

function disableWithdrawalOpt() { withdraw_from_savings_btn.disabled = true; withdraw_from_savings_btn.style.opacity = "0.5"; withdraw_from_savings_btn.style.cursor = "not-allowed"; }
function enableWithdrawalOpt() { withdraw_from_savings_btn.disabled = false; withdraw_from_savings_btn.style.opacity = "1"; withdraw_from_savings_btn.style.cursor = "pointer"; }

withdraw_from_savings_btn.addEventListener("click", () => {
    disableTransferOpt();
    disableWithdrawalOpt();
    notificationDialog("Processing withdrawal...", 2000);
    let withdrawalAmount = parseFloat(withdrawal_amount_inp.value);

     setTimeout(() => {
        if (isNaN(withdrawalAmount) || withdrawalAmount <= 0) {
            notificationDialog("Please enter a valid withdrawal amount.", 3500);
            upgradePurchaseFailedAudio();
            setTimeout(() => { enableTransferOpt(); }, 3000);
            return;
        }
     }, 3000);

    setTimeout(() => {
        if (player_savings_balance >= withdrawalAmount && withdrawalAmount > 0) {
            setTimeout(() => {
                notificationDialog("[Success] > $" + formatMoneyValue(withdrawalAmount) + " withdrawn from savings.", 3000);
                collectTaskAwardAudio();
                player_savings_balance -= withdrawalAmount;
                player_cash_balance += withdrawalAmount;
            }, 1000);
        } else {
            notificationDialog("Insufficient balance in savings.", 3500);
            upgradePurchaseFailedAudio();
        }
    }, 2000);
    setTimeout(() => { enableTransferOpt(); enableWithdrawalOpt(); }, 3000);
});

transfer_from_balance_to_savings_btn.addEventListener("click", () => {
    disableTransferOpt();
    disableWithdrawalOpt();
    notificationDialog("Processing transfer...", 2000);
    let transferAmount = parseFloat(transfer_amount_inp.value);

     setTimeout(() => {
        if (isNaN(transferAmount) || transferAmount <= 0) {
            notificationDialog("Please enter a valid transfer amount.", 3500);
            upgradePurchaseFailedAudio();
            setTimeout(() => { enableTransferOpt(); }, 3000);
            return;
        }
     }, 3000);

    setTimeout(() => {
        if (player_cash_balance >= transferAmount && transferAmount > 0) {
            setTimeout(() => {
                notificationDialog("[Success] > $" + formatMoneyValue(transferAmount) + " transferred to savings.", 3000);
                collectTaskAwardAudio();
                player_cash_balance -= transferAmount;
                player_savings_balance += transferAmount;
            }, 1000);
        } else {
            notificationDialog("Insufficient balance for transfer.", 3500);
            upgradePurchaseFailedAudio();
        }
    }, 2000);
    setTimeout(() => { enableTransferOpt(); enableWithdrawalOpt(); }, 3000);
});