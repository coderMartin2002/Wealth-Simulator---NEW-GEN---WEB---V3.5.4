let submit_code_opt = document.getElementById("submit-console-pin-opt");
let console_pin_inp = document.getElementById("consolePinInp");
let console_info_dialog_overlay = document.getElementById("console-info-dialog-overlay");
let close_console_info_dialog_overlay_btn = document.getElementById("close-console-info-dialog-overlay-btn");
let help_centre_opt = document.getElementById("help-centre-opt");
let pin_num_keys = document.getElementsByClassName("pin-num-key");

let c_p_1 = 1131;
let c_p_2 = 7730;
let c_p_3 = 8181;
let c_p_4 = 1921;
let c_p_5 = 3355;
let c_p_6 = 9090;
let c_p_7 = 1975;
let c_p_8 = 9972;
let c_p_10 = 7667;
let c_p_11 = 3466;
let c_p_12 = 11;
let c_p_13 = 22;
let c_p_14 = 33;
let c_p_15 = 3511;
let c_p_16 = 3513;
let c_p_17 = 3611;
let c_p_18 = 9999;
let c_p_19 = 11223344;
let c_p_20 = 3366;
let c_p_21 = 33001;
let c_p_22 = 2542;

let c_p_23 = 78235;
let c_p_24 = 42311;
let c_p_25 = 97934;

let c_p_26 = 9741;

let c_p_1_used = false;
let c_p_2_used = false;
let c_p_3_used = false;
let c_p_11_used = false;

help_centre_opt.onclick = function() { console_info_dialog_overlay.style.display = "flex"; }
close_console_info_dialog_overlay_btn.onclick = function() { console_info_dialog_overlay.style.display = "none"; }

for (let i = 0; i < pin_num_keys.length; i++) {
    pin_num_keys[i].addEventListener("click", () => {
        oscClickAudio();
    });
}

submit_code_opt.onclick = function() {
    const input = console_pin_inp.value;

    if (console_pin_used_status_checker(input)) {
        return;
    }

    if (input === "") {
        notificationDialog("Field is empty!", 2000);
        upgradePurchaseFailedAudio();
    }

    if (input === c_p_1.toString()) {
        total_passive_income_pool += 2.50;
        c_p_1_used = true;
        collectTaskAwardAudio();
        notificationDialog("$2.50 Added to your passive income pool!", 4000);
    } else if (input === c_p_2.toString()) {
        player_cash_balance += 100;
        c_p_2_used = true;
        collectTaskAwardAudio();
        notificationDialog("$100.00 Added to your balance!", 4000);
    } else if (input === c_p_3.toString()) {
        inventory_slot_1_player_owned_amount++;
        inventory_slot_2_player_owned_amount++;
        inventory_slot_3_player_owned_amount++;
        c_p_3_used = true;
        collectTaskAwardAudio();
        notificationDialog("X1 of each booster types added to your inventory", 4000);
    } else if (input === c_p_4.toString()) {
        /*
        
        inventory_slot_1_player_owned_amount += 999;
        inventory_slot_2_player_owned_amount += 999;
        inventory_slot_3_player_owned_amount += 999;
        inventory_slot_4_player_owned_amount += 999;
        inventory_slot_5_player_owned_amount += 999;
        inventory_slot_6_player_owned_amount += 999;
        inventory_slot_7_player_owned_amount += 999;
        inventory_slot_8_player_owned_amount += 999;
        inventory_slot_9_player_owned_amount += 999;
        inventory_slot_10_player_owned_amount += 999;
        inventory_slot_11_player_owned_amount += 999;
        inventory_slot_12_player_owned_amount += 999;

        player_cash_balance += 100000;
        player_coins_balance += 100000;
        player_diamond_balance += 100000;
        player_tycoon_score += 100000;
        player_booster_tokens += 100000;
        total_passive_income_pool += 100000;

        */

        wealthFarmsTutorial();

        collectTaskAwardAudio();
        //notificationDialog("Admin pin applied successfully!", 4000);
    } else if (input === c_p_5.toString()) {
        inventory_slot_10_player_owned_amount++;
        inventory_slot_10_use_booster_opt.click();
        setTimeout(() => { document.getElementById("console-ui").style.display = "none"; }, 800)
    } else if (input === c_p_6.toString()) {
        document.getElementById("15-reel-slot-opt").click();
        document.getElementById("console-ui").style.display = "none"
        setTimeout(() => { 
            for (let i = 0; i < 100; i++) {
                initiateMultiSpin();
                initiateSpin();
            }
        }, 500)
    } else if (input === c_p_7.toString()) {
        jackpot_win_probability = 2;
    } else if (input === c_p_8.toString()) {
        player_coins_balance += store_slot_3_tier_2_farm_price;
        player_diamond_balance += 10;
        document.getElementById("store-slot-3-upgrade-btn").click(); document.getElementById("store-slot-5-upgrade-btn").click();
    } else if (input === c_p_10.toString()) {
        clear_local_storage_dialog.style.display = "flex";
        notificationDialog("Admin pin applied successfully!", 4000);
    } else if (input === c_p_11.toString()) {
        inventory_slot_9_player_owned_amount += 10;
        c_p_11_used = true;
        collectTaskAwardAudio()
        notificationDialog("X10 MYSTERY TOKENS added to your inventory!", 4000);
    } else if (input === c_p_12.toString()) {
        user_trivia_attempts = 0; 
        user_set_trivia_dif_txt = "ADMIN"; 
        trivia_reward_multiplier = 999;
        game_total = 99999;
        user_trivia_score = 99999;
        user_trivia_match_cash_won_total = 99999; 
        user_set_score_award = 999; 
        user_set_max_attempts = 999; 
        user_set_cash_award = 999;
        collectTaskAwardAudio()
        notificationDialog("Admin pin applied successfully!", 4000);
    } else if (input === c_p_13.toString()) {
        document.getElementById("dif-info-panel").style.display = "flex";
    } else if (input === c_p_14.toString()) {
        //clear_local_storage_confirmation_opt.click();
        permanent_buffs_storage[0].buff_active = true;
    } else if (input === c_p_15.toString()) {
        attachBuffToggleHandlers();
    } else if (input === c_p_16.toString()) {
        player_tycoon_score += 1000000;
    } else if (input === c_p_17.toString()) {
        triviaTimed();
        match_active = true;
        timed_dif_active = true;
        document.getElementById("timed-dif-timer-output").style.display = "block";
    } else if (input === c_p_18.toString()) {
        player_diamond_balance += 5;
        document.getElementById("store-slot-9-upgrade-btn").click();
    } else if (input === c_p_19.toString()) {
        xNkLY78C();
    } else if (input === c_p_20.toString()) {
        inventory_slot_5_player_owned_amount++;
        inventory_slot_5_use_booster_opt.click();
        setTimeout(() => { document.getElementById("console-ui").style.display = "none"; }, 800)
    } else if (input === c_p_21.toString()) {
        task_1_progress = task_1_progress_bar.max;
        task_2_progress = task_2_progress_bar.max;
        task_3_progress = task_3_progress_bar.max;
        task_4_progress = task_4_progress_bar.max;
        task_5_progress = task_5_progress_bar.max;
        task_6_progress = task_6_progress_bar.max;
        task_7_progress = task_7_progress_bar.max;
        collectTaskAwardAudio()
    } else if (input === c_p_22.toString()) {
        player_tycoon_score += 5000;
        collectTaskAwardAudio()
    } else if (input === c_p_23.toString()) {
        document.getElementById("balances-styles").href = "Legacy Styles/balance-tab-styles (v3.2.1).css";
    } else if (input === c_p_24.toString()) {
        document.getElementById("balances-styles").href = "Legacy Styles/balance-tab-styles (v3.2.2).css";
    } else if (input === c_p_25.toString()) {
        document.getElementById("balances-styles").href = "Legacy Styles/main-menu-opts-styles (v3.2.1).css";
    } else if (input === c_p_26.toString()) {
        match_boards_opt.click();
        setTimeout(() => { create_board(); }, 1000);
    } else if (input === "--install --mod 1 dom / html inspector") { // WRITTEN COMMANDS
        install_mod_1_opt.click();
        collectTaskAwardAudio();
    } else if (input === "--15reel/baseSymbols.remove") {
        cash_2_probability = null; // DEF 10
        coin_2_probability = null; // DEF 15
        diamond_2_probability = null; // DEF 50
        seven_probability = 10;
        cherry_probability = 10;
        triple_coins_probability = null;

        jack_2_probability = null;
        queen_2_probability = null;
        king_2_probability = null;
        star_probability = 10;
        free_spins_bonus_probability = 10

        collectTaskAwardAudio()
        notificationDialog("Admin pin applied successfully!", 4000);
    } else if (input === "--install --mod 2 trivia") {
        install_mod_2_opt.click();
        collectTaskAwardAudio();
    } else if (input === "--install --mod 3 bonuses") {
        install_mod_3_opt.click();
        collectTaskAwardAudio();
    } else if (input === "--install --mod 4 broken economy") {
        install_mod_4_opt.click();
    } else if (input === "--reload --doc") {
        notificationDialog("REFRESHING PAGE..", 2000);
        setTimeout(() => { location.reload(); }, 1500)
        collectTaskAwardAudio();
    } else if (input === "--install --mods @a") {
        document.getElementById("main-cont-ui").style.display = "none";
        install_mod_1_opt.click();
        install_mod_2_opt.click();
        install_mod_3_opt.click();
        install_mod_4_opt.click();
        setTimeout(() => { document.getElementById("main-cont-ui").style.display = "flex"; }, 7000)
        collectTaskAwardAudio();
    } else if (input === "--init @admin 1921") {
        xNkLY78C();
        keyboardClickAudio();
    } else if (input === "--buildVersion") {
        notificationDialog("[current version] > " + buildVersion + " [NEXT-GEN]", 5000);
    } else if (input === "--localStorage.clear") {
        confirm_clearance_pin_inp.value = 11;
        clear_local_storage_confirmation_opt.click();
    } else if (input === "--run /tokenGen") {
        let temp_anchor = document.createElement("a");
        temp_anchor.href = "node_modules/randomTokenGen.html";
        temp_anchor.target = "_blank";
        setTimeout(() => { temp_anchor.click(); }, 500)
    } else {
        notificationDialog("Invalid pin!", 2000);
        upgradePurchaseFailedAudio();
    }
}

document.getElementById("clear-console-pin-inp").onclick = function() { console_pin_inp.value = ""; }