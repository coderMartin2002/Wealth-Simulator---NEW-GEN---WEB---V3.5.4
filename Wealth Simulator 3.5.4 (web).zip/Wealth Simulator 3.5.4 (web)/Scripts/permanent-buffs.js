let perks_station_opt = document.getElementById("perks-station-ui-btn");
let perks_station_ui = document.getElementById("perks-station-ui");
let close_perks_station_ui_opt = document.getElementById("close-perks-station-ui-btn");

let buff_3_spin_counter = 0;

let extra_farm_progress_int = null;
let common_buff_cash_grant_int = null;
let rare_buff_cash_grant_int = null;
let legendary_buff_coin_grant_int = null;

let permanent_buffs_storage = [
    { // [i] > 0
        buff_name: "Decreased collection times of all unlocked farms by 10%!",
        buff_rarity: "COMMON",
        buff_active: false,
        buff_status_output: document.getElementById("buff-1-ownership-output"),
        buff_id: 1
    },
    { // [i] > 1
        buff_name: "Receive 5% extra xp with each grant!",
        buff_rarity: "COMMON",
        buff_active: false,
        buff_status_output: document.getElementById("buff-2-ownership-output"),
        buff_id: 2
    },
    { // [i] > 2
        buff_name: "Grants $0.01 every second!",
        buff_rarity: "COMMON",
        buff_active: false,
        buff_status_output: document.getElementById("buff-3-ownership-output"),
        buff_id: 3
    },
    { // [i] > 3
        buff_name: "Receive X1 mystery token for every 15 spins in 3 or 15 reel slots!",
        buff_rarity: "UNCOMMON",
        buff_active: false,
        buff_status_output: document.getElementById("buff-4-ownership-output"),
        buff_id: 4
    },
    { // [i] > 4
        buff_name: "Reduced prices for X2 & X3 Farm Income Boosters in store by 10%",
        buff_rarity: "UNCOMMON",
        buff_active: false,
        buff_status_output: document.getElementById("buff-5-ownership-output"),
        buff_id: 5
    },
    { // [i] > 5
        buff_name: "Increased odds of winning jackpot 7's by 5%",
        buff_rarity: "RARE",
        buff_active: false,
        buff_status_output: document.getElementById("buff-6-ownership-output"),
        buff_id: 6
    },
    { // [i] > 6
        buff_name: "Receive $0.05 every second!",
        buff_rarity: "RARE",
        buff_active: false,
        buff_status_output: document.getElementById("buff-7-ownership-output"),
        buff_id: 7
    },
    { // [i] > 7
        buff_name: "Grants X1 extra attempt in any trivia difficulty!",
        buff_rarity: "EPIC",
        buff_active: false,
        buff_status_output: document.getElementById("buff-8-ownership-output"),
        buff_id: 8
    },
    { // [i] > 8 
        buff_name: "Increased duration for all timed boosters by 15% (9 seconds)!",
        buff_rarity: "EPIC",
        buff_active: false,
        buff_status_output: document.getElementById("buff-9-ownership-output"),
        buff_id: 9
    },
    { // [i] > 9 
        buff_name: "Increased default reward multiplier for the hard difficulty in Trivia from X1.5 to X2!",
        buff_rarity: "LEGENDARY",
        buff_active: false,
        buff_status_output: document.getElementById("buff-10-ownership-output"),
        buff_id: 10
    },
    { // [i] > 10
        buff_name: "Grants X2 coins every 30 seconds!",
        buff_rarity: "LEGENDARY",
        buff_active: false,
        buff_status_output: document.getElementById("buff-11-ownership-output"),
        buff_id: 11
    },
    { // [i] > 11
        buff_name: "Quick Collect for wealth farms",
        buff_rarity: "LEGENDARY",
        buff_active: false,
        buff_status_output: document.getElementById("buff-12-ownership-output"),
        buff_id: 12
    }
];

function attachBuffToggleHandlers() {
    permanent_buffs_storage.forEach((buff, index) => {
        if (!buff.buff_status_output) { return; }
        buff.buff_status_output.onclick = function() {
            togglePermanentBuff(index);
        };
    });
}

updateBuffStatusUI();

perks_station_opt.onclick = function() {
    perks_station_ui.style.display = "flex";
    document.getElementById("inventory-ui").style.display = "none";
    document.getElementById("store-ui").style.display = "none";
    document.getElementById("fund-farms-ui").style.display = "none";
    document.getElementById("guessing-game-ui").style.display = "none";
    document.getElementById("upgrades-hub-ui").style.display = "none";
    document.getElementById("gambling-hub-ui").style.display = "none";
    document.getElementById("settings-ui").style.display = "none";
    document.getElementById("gambling-hub-ui-2").style.display = "none";
    document.getElementById("slot-selection-dialog-overlay").style.display = "none";
    document.getElementById("timed-dif-timer-mod-dialog-overlay").style.display = "none";
    document.getElementById("dif-info-panel").style.display = "none";
    trivia_hub_ui.style.display = "none";
    bank_ui.style.display = "none";
    updates_hub_ui.style.display = "none";
    challenge_hub_ui.style.display = "none";
    console_ui.style.display = "none";
}

close_perks_station_ui_opt.onclick = function() {
    perks_station_ui.style.display = "none";
}

function updateBuffStatusUI() {
    for (let i = 0; i < permanent_buffs_storage.length; i++) {
        const buff = permanent_buffs_storage[i];
        if (!buff.buff_status_output) { continue; }
        if (buff.buff_active) {
            buff.buff_status_output.innerHTML = "<span style='color: lime'>ACTIVE</span>";
            buff.buff_status_output.style.borderRight = "5px solid lime";
        } else {
            buff.buff_status_output.innerHTML = "<span style='color: red'>INACTIVE</span>";
            buff.buff_status_output.style.borderRight = "5px solid red";
        }
    }
}

function applyPermanentBuffEffects() {
    if (permanent_buffs_storage[0].buff_active) {
        if (extra_farm_progress_int === null) {
            extra_farm_progress_int = setInterval(() => {
                increaseProgressBar(farm_1_progress_bar, 0.5);
                increaseProgressBar(farm_2_progress_bar, 0.5);
                increaseProgressBar(farm_3_progress_bar, 0.5);
                increaseProgressBar(farm_4_progress_bar, 0.5);
                increaseProgressBar(farm_5_progress_bar, 0.5);
                increaseProgressBar(farm_6_progress_bar, 0.5);
            }, 1000);
        }
    } else if (extra_farm_progress_int !== null) {
        clearInterval(extra_farm_progress_int);
        extra_farm_progress_int = null;
    }

    if (permanent_buffs_storage[2].buff_active) {
        if (common_buff_cash_grant_int === null) {
            common_buff_cash_grant_int = setInterval(() => {
                player_cash_balance += 0.01;
            }, 1000);
        }
    } else if (common_buff_cash_grant_int !== null) {
        clearInterval(common_buff_cash_grant_int);
        common_buff_cash_grant_int = null;
    }

    if (permanent_buffs_storage[4].buff_active) {
        store_slot_2_upgrade_price = 27;
        store_slot_4_upgrade_price = 45;
    } else {
        store_slot_2_upgrade_price = 30;
        store_slot_4_upgrade_price = 50;
    }

    if (permanent_buffs_storage[5].buff_active) {
        jackpot_win_probability = 63;
    } else {
        jackpot_win_probability = 70;
    }

    if (permanent_buffs_storage[6].buff_active) {
        if (rare_buff_cash_grant_int === null) {
            rare_buff_cash_grant_int = setInterval(() => {
                player_cash_balance += 0.05;
            }, 1000);
        }
    } else if (rare_buff_cash_grant_int !== null) {
        clearInterval(rare_buff_cash_grant_int);
        rare_buff_cash_grant_int = null;
    }

    if (permanent_buffs_storage[8].buff_active) {
        inventory_slot_1_booster_duration_int = 70000;
        inventory_slot_2_booster_duration_int = 70000;
        inventory_slot_3_booster_duration_int = 70000;
        inventory_slot_4_booster_duration_int = 70000;
        inventory_slot_7_booster_duration_int = 300000;
        inventory_slot_8_booster_duration_int = 70000;
    } else {
        inventory_slot_1_booster_duration_int = 60000;
        inventory_slot_2_booster_duration_int = 60000;
        inventory_slot_3_booster_duration_int = 60000;
        inventory_slot_4_booster_duration_int = 60000;
        inventory_slot_7_booster_duration_int = 300000;
        inventory_slot_8_booster_duration_int = 60000;
    }

    if (permanent_buffs_storage[9].buff_active) {
        def_hard_dif_multiplier = 2;
    } else {
        def_hard_dif_multiplier = 1.5;
    }

    if (permanent_buffs_storage[10].buff_active) {
        if (legendary_buff_coin_grant_int === null) {
            legendary_buff_coin_grant_int = setInterval(() => {
                player_coins_balance += 2;
            }, 30000);
        }
    } else if (legendary_buff_coin_grant_int !== null) {
        clearInterval(legendary_buff_coin_grant_int);
        legendary_buff_coin_grant_int = null;
    }
}

function handleMysteryTokenBuffAfterSpin() {
    if (permanent_buffs_storage[3].buff_active && buff_3_spin_counter >= 15) {
        buff_3_spin_counter = 0;
        inventory_slot_9_player_owned_amount++;
        notificationDialog("X1 Mystery Token added to inventory!", 3000);
        mysteryWinAudio();
    }
}

function togglePermanentBuff(indexOrId) {
    let buff = null;

    if (typeof indexOrId === "number") {
        buff = permanent_buffs_storage[indexOrId];
    } else if (typeof indexOrId === "string") {
        const normalizedId = Number(indexOrId);
        buff = permanent_buffs_storage.find((entry) => {
            return entry.buff_id === normalizedId || entry.buff_status_output?.id === indexOrId;
        });
    } else if (indexOrId && typeof indexOrId === "object") {
        const targetId = indexOrId.id || indexOrId.getAttribute?.("id");
        buff = permanent_buffs_storage.find((entry) => entry.buff_status_output?.id === targetId);
    }

    if (!buff) { return false; }

    buff.buff_active = !buff.buff_active;
    updateBuffStatusUI();
    applyPermanentBuffEffects();
    return buff.buff_active;
}

