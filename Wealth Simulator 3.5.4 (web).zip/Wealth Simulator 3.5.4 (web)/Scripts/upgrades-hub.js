let upgrades_slot_board = document.getElementById("upgrades-slot-board");
let passive_income_details_dialog_overlay = document.getElementById("passive-income-details-dialog-overlay");
let close_passive_income_details_dialog_overlay_close_btn = document.getElementById("close-passive-income-details-dialog-overlay-btn");

// BOARD UPGRADES SLOT REFS

let board_slot_1 = document.getElementById("board-slot-1");
let board_slot_2 = document.getElementById("board-slot-2");
let board_slot_3 = document.getElementById("board-slot-3");
let board_slot_4 = document.getElementById("board-slot-4");
let board_slot_5 = document.getElementById("board-slot-5");
let board_slot_6 = document.getElementById("board-slot-6");

// BOARD PASSIVE INCREASE BUY OPTS

let board_slot_1_income_upgrade_opt = document.getElementById("board-slot-1-income-upgrade-btn");
let board_slot_2_income_upgrade_opt = document.getElementById("board-slot-2-income-upgrade-btn");
let board_slot_3_income_upgrade_opt = document.getElementById("board-slot-3-income-upgrade-btn");
let board_slot_4_income_upgrade_opt = document.getElementById("board-slot-4-income-upgrade-btn");
let board_slot_5_income_upgrade_opt = document.getElementById("board-slot-5-income-upgrade-btn");
let board_slot_6_income_upgrade_opt = document.getElementById("board-slot-6-income-upgrade-btn");

let board_slot_income_upgrade_opts_storage = [board_slot_1_income_upgrade_opt, board_slot_2_income_upgrade_opt, board_slot_3_income_upgrade_opt, board_slot_4_income_upgrade_opt, board_slot_5_income_upgrade_opt, board_slot_6_income_upgrade_opt];

// BOARD PASSIVE UPGRADE SLOTS INTERVAL REDUCTION OPTS

let board_slot_1_interval_reduction_opt = document.getElementById("board-slot-1-interval-reduction-btn");
let board_slot_2_interval_reduction_opt = document.getElementById("board-slot-2-interval-reduction-btn");
let board_slot_3_interval_reduction_opt = document.getElementById("board-slot-3-interval-reduction-btn");

let slot_cash_ref_1 = document.getElementById("slot-cash-ref-1");
let slot_cash_ref_2 = document.getElementById("slot-cash-ref-2");
let slot_cash_ref_3 = document.getElementById("slot-cash-ref-3");
let slot_cash_ref_4 = document.getElementById("slot-cash-ref-4");
let slot_cash_ref_5 = document.getElementById("slot-cash-ref-5");
let slot_cash_ref_6 = document.getElementById("slot-cash-ref-6");

let slot_cash_ref_storage = [slot_cash_ref_1, slot_cash_ref_2, slot_cash_ref_3, slot_cash_ref_4, slot_cash_ref_5, slot_cash_ref_6];

// BOARD PASSIVE UPGRADES SLOT GRANT AMOUNTS

let board_1_grant_amount = 1.00;
let board_2_grant_amount = 2.00;
let board_3_grant_amount = 5.00;
let board_4_grant_amount = 10.00;
let board_5_grant_amount = 20.00;
let board_6_grant_amount = 50.00;

// BOARD PASSIVE UPGRADE SLOT PRICES (INCOME UPGRADE PRICES)

let board_slot_1_passive_income_upgrade_price = 25; 
let board_slot_2_passive_income_upgrade_price = 125;
let board_slot_3_passive_income_upgrade_price = 250;
let board_slot_4_passive_income_upgrade_price = 500;
let board_slot_5_passive_income_upgrade_price = 500;
let board_slot_6_passive_income_upgrade_price = 1000;

// BOARD PASSIVE UPGRADES LVL PROGRESS INC

let board_slot_1_upgrade_lvl_progress_inc = 10;
let board_slot_2_upgrade_lvl_progress_inc = 20;
let board_slot_3_upgrade_lvl_progress_inc = 30;
let board_slot_4_upgrade_lvl_progress_inc = 50;
let board_slot_5_upgrade_lvl_progress_inc = 100;
let board_slot_6_upgrade_lvl_progress_inc = 200;

// BOARD PASSIVE UPGRADES SLOT UPGRADE OPTS

let board_slot_1_upgrade_passive_income_opt = document.getElementById("purchase-slot-1-upgrade-btn");
let board_slot_2_upgrade_passive_income_opt = document.getElementById("purchase-slot-2-upgrade-btn");
let board_slot_3_upgrade_passive_income_opt = document.getElementById("purchase-slot-3-upgrade-btn");
let board_slot_4_upgrade_passive_income_opt = document.getElementById("purchase-slot-4-upgrade-btn");
let board_slot_5_upgrade_passive_income_opt = document.getElementById("purchase-slot-5-upgrade-btn");
let board_slot_6_upgrade_passive_income_opt = document.getElementById("purchase-slot-6-upgrade-btn");

let board_slot_upgrade_passive_income_opts = [board_slot_1_upgrade_passive_income_opt, board_slot_2_upgrade_passive_income_opt, board_slot_3_upgrade_passive_income_opt, board_slot_4_upgrade_passive_income_opt, board_slot_5_upgrade_passive_income_opt, board_slot_6_upgrade_passive_income_opt];

// PASSIVE INCOME STATS & POOLS

let total_passive_income_pool = 0;
let passive_income_grant_int = 60000;
let purchase_dialog_overlays_storage = [document.getElementById("purchase-dialog-overlay-1"), document.getElementById("purchase-dialog-overlay-2"), document.getElementById("purchase-dialog-overlay-3"), document.getElementById("purchase-dialog-overlay-4"), document.getElementById("purchase-dialog-overlay-5"), document.getElementById("purchase-dialog-overlay-6")];
let purchase_dialog_overlays_close_btns = document.getElementsByClassName("close-dialog-overlay-btn");
let upgrade_brief_panels_storage = [document.getElementById("upgrade-slot-1-brief-panel"), document.getElementById("upgrade-slot-2-brief-panel"), document.getElementById("upgrade-slot-3-brief-panel"), document.getElementById("upgrade-slot-4-brief-panel"), document.getElementById("upgrade-slot-5-brief-panel"), document.getElementById("upgrade-slot-6-brief-panel")];
let upgrade_purchase_btns_storage = [document.getElementById("board-slot-1-income-upgrade-btn"), document.getElementById("board-slot-2-income-upgrade-btn"), document.getElementById("board-slot-3-income-upgrade-btn"), document.getElementById("board-slot-4-income-upgrade-btn"), document.getElementById("board-slot-5-income-upgrade-btn"), document.getElementById("board-slot-6-income-upgrade-btn")];
let passive_income_upgrade_brief_txt = "The amount stated will be credited to your total passive income pool.";
let passive_income_grant_int_seconds = passive_income_grant_int / 1000;

// MULTI BUY OPTS

let board_slot_1_multi_purchase_opt_1 = document.getElementById("slot-1-multi-purchase-btn-1");
let board_slot_1_multi_purchase_opt_2 = document.getElementById("slot-1-multi-purchase-btn-2");
let board_slot_1_multi_purchase_opt_3 = document.getElementById("slot-1-multi-purchase-btn-3");

let board_slot_2_multi_purchase_opt_1 = document.getElementById("slot-2-multi-purchase-btn-1");
let board_slot_2_multi_purchase_opt_2 = document.getElementById("slot-2-multi-purchase-btn-2");
let board_slot_2_multi_purchase_opt_3 = document.getElementById("slot-2-multi-purchase-btn-3");

let board_slot_3_multi_purchase_opt_1 = document.getElementById("slot-3-multi-purchase-btn-1");
let board_slot_3_multi_purchase_opt_2 = document.getElementById("slot-3-multi-purchase-btn-2");
let board_slot_3_multi_purchase_opt_3 = document.getElementById("slot-3-multi-purchase-btn-3");

let board_slot_4_multi_purchase_opt_1 = document.getElementById("slot-4-multi-purchase-btn-1");
let board_slot_4_multi_purchase_opt_2 = document.getElementById("slot-4-multi-purchase-btn-2");
let board_slot_4_multi_purchase_opt_3 = document.getElementById("slot-4-multi-purchase-btn-3");

let board_slot_5_multi_purchase_opt_1 = document.getElementById("slot-5-multi-purchase-btn-1");
let board_slot_5_multi_purchase_opt_2 = document.getElementById("slot-5-multi-purchase-btn-2");
let board_slot_5_multi_purchase_opt_3 = document.getElementById("slot-5-multi-purchase-btn-3");

let board_slot_6_multi_purchase_opt_1 = document.getElementById("slot-6-multi-purchase-btn-1");
let board_slot_6_multi_purchase_opt_2 = document.getElementById("slot-6-multi-purchase-btn-2");
let board_slot_6_multi_purchase_opt_3 = document.getElementById("slot-6-multi-purchase-btn-3");

board_slot_1_multi_purchase_opt_1.onclick = function() { player_tycoon_score += 5; purchaseMultiUpgrade(board_slot_1_passive_income_upgrade_price, 5, board_1_grant_amount, board_slot_1_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-1")); }
board_slot_1_multi_purchase_opt_2.onclick = function() { player_tycoon_score += 5; purchaseMultiUpgrade(board_slot_1_passive_income_upgrade_price, 10, board_1_grant_amount, board_slot_1_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-1")); }
board_slot_1_multi_purchase_opt_3.onclick = function() { player_tycoon_score += 5; purchaseMultiUpgrade(board_slot_1_passive_income_upgrade_price, 25, board_1_grant_amount, board_slot_1_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-1")); }

board_slot_2_multi_purchase_opt_1.onclick = function() { player_tycoon_score += 10; purchaseMultiUpgrade(board_slot_2_passive_income_upgrade_price, 5, board_2_grant_amount, board_slot_2_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-2")); }
board_slot_2_multi_purchase_opt_2.onclick = function() { player_tycoon_score += 10; purchaseMultiUpgrade(board_slot_2_passive_income_upgrade_price, 10, board_2_grant_amount, board_slot_2_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-2")); }
board_slot_2_multi_purchase_opt_3.onclick = function() { player_tycoon_score += 10; purchaseMultiUpgrade(board_slot_2_passive_income_upgrade_price, 25, board_2_grant_amount, board_slot_2_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-2")); }

board_slot_3_multi_purchase_opt_1.onclick = function() { player_tycoon_score += 20; purchaseMultiUpgrade(board_slot_3_passive_income_upgrade_price, 5, board_3_grant_amount, board_slot_3_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-3")); }
board_slot_3_multi_purchase_opt_2.onclick = function() { player_tycoon_score += 20; purchaseMultiUpgrade(board_slot_3_passive_income_upgrade_price, 10, board_3_grant_amount, board_slot_3_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-3")); }
board_slot_3_multi_purchase_opt_3.onclick = function() { player_tycoon_score += 20; purchaseMultiUpgrade(board_slot_3_passive_income_upgrade_price, 25, board_3_grant_amount, board_slot_3_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-3")); }

board_slot_4_multi_purchase_opt_1.onclick = function() { player_tycoon_score += 30; purchaseMultiUpgrade(board_slot_4_passive_income_upgrade_price, 5, board_4_grant_amount, board_slot_4_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-4")); }
board_slot_4_multi_purchase_opt_2.onclick = function() { player_tycoon_score += 30; purchaseMultiUpgrade(board_slot_4_passive_income_upgrade_price, 10, board_4_grant_amount, board_slot_4_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-4")); }
board_slot_4_multi_purchase_opt_3.onclick = function() { player_tycoon_score += 30; purchaseMultiUpgrade(board_slot_4_passive_income_upgrade_price, 25, board_4_grant_amount, board_slot_4_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-4")); }

board_slot_5_multi_purchase_opt_1.onclick = function() { player_tycoon_score += 40; purchaseMultiUpgrade(board_slot_5_passive_income_upgrade_price, 5, board_5_grant_amount, board_slot_5_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-5"), "coins"); }
board_slot_5_multi_purchase_opt_2.onclick = function() { player_tycoon_score += 40; purchaseMultiUpgrade(board_slot_5_passive_income_upgrade_price, 10, board_5_grant_amount, board_slot_5_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-5"), "coins"); }
board_slot_5_multi_purchase_opt_3.onclick = function() { player_tycoon_score += 40; purchaseMultiUpgrade(board_slot_5_passive_income_upgrade_price, 25, board_5_grant_amount, board_slot_5_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-5"), "coins"); }

board_slot_6_multi_purchase_opt_1.onclick = function() { player_tycoon_score += 50; purchaseMultiUpgrade(board_slot_6_passive_income_upgrade_price, 5, board_6_grant_amount, board_slot_6_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-6"), "coins"); }
board_slot_6_multi_purchase_opt_2.onclick = function() { player_tycoon_score += 50; purchaseMultiUpgrade(board_slot_6_passive_income_upgrade_price, 10, board_6_grant_amount, board_slot_6_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-6"), "coins"); }
board_slot_6_multi_purchase_opt_3.onclick = function() { player_tycoon_score += 50; purchaseMultiUpgrade(board_slot_6_passive_income_upgrade_price, 25, board_6_grant_amount, board_slot_6_upgrade_lvl_progress_inc, document.getElementById("purchase-dialog-overlay-6"), "coins"); }

document.getElementById("passive-income-pool-block").onclick = function() { passive_income_details_dialog_overlay.style.display = "flex"; }
close_passive_income_details_dialog_overlay_close_btn.onclick = function() { passive_income_details_dialog_overlay.style.display = "none"; }

 for (let i = 0; i < purchase_dialog_overlays_close_btns.length; i++) {
    purchase_dialog_overlays_close_btns[i].onclick = function() {
        for (let x = 0; x < purchase_dialog_overlays_storage.length; x++) {
            if (purchase_dialog_overlays_storage[x]) {
                purchase_dialog_overlays_storage[x].style.display = "none";
            }
        }
        enableUpgradePurchaseBtns();
    }
}

let passive_income_reloader_int = setInterval(function() { // PASSIVE INCOME POOL GRANTING INTERVAL
    if (total_passive_income_pool > 0) {
        totalPassiveIncomePoolGrant();
        passive_income_grant_int_seconds = passive_income_grant_int / 1000;
    }
}, passive_income_grant_int)

let passive_income_countdown_int = setInterval(function() {
    if (total_passive_income_pool > 0 && passive_income_grant_int_seconds > 0) {
        passive_income_grant_int_seconds--;
    }
}, 1000)

function restartPassiveIncomeInterval() {
    clearInterval(passive_income_reloader_int);
    passive_income_reloader_int = setInterval(function() {
        if (total_passive_income_pool > 0) {
            totalPassiveIncomePoolGrant();
            passive_income_grant_int_seconds = passive_income_grant_int / 1000;
        }
    }, passive_income_grant_int);
    passive_income_grant_int_seconds = passive_income_grant_int / 1000;
}

document.getElementById("upgrades-hub-ui-info-btn").onclick = function() {
    document.getElementById("upgrades-hub-ui-info-dialog-overlay").style.display = "flex";
}

document.getElementById("close-upgrades-hub-ui-info-dialog-overlay-btn").onclick = function() {
    document.getElementById("upgrades-hub-ui-info-dialog-overlay").style.display = "none";
}

function totalPassiveIncomePoolGrant() {
    player_cash_balance += total_passive_income_pool;
    passiveIncomePoolGrantedAudio();
    notificationDialog("PASSIVE INCOME GRANTED > <span style='color: lime; margin-left: 6px;'> +$" + total_passive_income_pool.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>", 4000);
}

function disableUpgradePurchaseBtns() {
    for (let i = 0; i < upgrade_purchase_btns_storage.length; i++) {
        let btn = upgrade_purchase_btns_storage[i];
        if (btn) {
            btn.disabled = true;
            btn.style.cursor = "not-allowed";
            btn.style.opacity = "0.5";
        }
    }
}

function enableUpgradePurchaseBtns() {
    for (let i = 0; i < upgrade_purchase_btns_storage.length; i++) {
        let btn = upgrade_purchase_btns_storage[i];
        if (btn) {
            btn.disabled = false;
            btn.style.cursor = "pointer";
            btn.style.opacity = "1";
        }
    }
}

function clearBriefPanels() {
    for (let i = 0; i < upgrade_brief_panels_storage.length; i++) {
        let panel = upgrade_brief_panels_storage[i];
        if (panel) {
            panel.style.display = "none";
        }
    }
}

// BOARD PASSIVE INCOME SLOT UPGRADE INCOME UI OPTS

board_slot_1_income_upgrade_opt.onclick = function() {
    document.getElementById("purchase-dialog-overlay-1").style.display = "flex";
    document.getElementById("upgrade-slot-1-brief-panel").style.display = "flex";
    document.getElementById("upgrade-slot-1-brief-output").innerHTML = passive_income_upgrade_brief_txt;
    document.getElementById("upgrade-slot-1-price-output").innerHTML = "<span style='color: yellow; margin-right: 6px;'>PRICE -> </span><span style='color: lime'> $" + board_slot_1_passive_income_upgrade_price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>" + "<img src='Images/Cash-balance-icon.png' style='margin-left: 5px;' width='25px' height='25px' />";
    keyboardClickAudio();
    disableUpgradePurchaseBtns();
}

board_slot_2_income_upgrade_opt.onclick = function() {
    document.getElementById("purchase-dialog-overlay-2").style.display = "flex";
    document.getElementById("upgrade-slot-2-brief-panel").style.display = "flex";
    document.getElementById("upgrade-slot-2-brief-output").innerHTML = passive_income_upgrade_brief_txt;
    document.getElementById("upgrade-slot-2-price-output").innerHTML = "<span style='color: yellow; margin-right: 6px;'>PRICE -> </span><span style='color: lime'> $" + board_slot_2_passive_income_upgrade_price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>" + "<img src='Images/Cash-balance-icon.png' style='margin-left: 5px;' width='25px' height='25px' />";
    keyboardClickAudio();
    disableUpgradePurchaseBtns();
}

board_slot_3_income_upgrade_opt.onclick = function() {
    document.getElementById("purchase-dialog-overlay-3").style.display = "flex";
    document.getElementById("upgrade-slot-3-brief-panel").style.display = "flex";
    document.getElementById("upgrade-slot-3-brief-output").innerHTML = passive_income_upgrade_brief_txt;
    document.getElementById("upgrade-slot-3-price-output").innerHTML = "<span style='color: yellow; margin-right: 6px;'>PRICE -> </span><span style='color: lime'> $" + board_slot_3_passive_income_upgrade_price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>" + "<img src='Images/Cash-balance-icon.png' style='margin-left: 5px;' width='25px' height='25px' />";
    keyboardClickAudio();
    disableUpgradePurchaseBtns();
}

board_slot_4_income_upgrade_opt.onclick = function() {
    document.getElementById("purchase-dialog-overlay-4").style.display = "flex";
    document.getElementById("upgrade-slot-4-brief-panel").style.display = "flex";
    document.getElementById("upgrade-slot-4-brief-output").innerHTML = passive_income_upgrade_brief_txt;
    document.getElementById("upgrade-slot-4-price-output").innerHTML = "<span style='color: yellow; margin-right: 6px;'>PRICE -> </span><span style='color: lime'> $" + board_slot_4_passive_income_upgrade_price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>" + "<img src='Images/Cash-balance-icon.png' style='margin-left: 5px;' width='25px' height='25px' />";
    keyboardClickAudio();
    disableUpgradePurchaseBtns();
}

board_slot_5_income_upgrade_opt.onclick = function() {
    document.getElementById("purchase-dialog-overlay-5").style.display = "flex";
    document.getElementById("upgrade-slot-5-brief-panel").style.display = "flex";
    document.getElementById("upgrade-slot-5-brief-output").innerHTML = passive_income_upgrade_brief_txt;
    document.getElementById("upgrade-slot-5-price-output").innerHTML = "<span style='color: yellow; margin-right: 6px;'>PRICE -> </span><span style='color: lime'>" + board_slot_5_passive_income_upgrade_price.toLocaleString("en-US") + " COINS</span>" + "<img src='Images/Tycoon-score-balance-icon.png' style='margin-left: 5px;' width='25px' height='25px' />";
    keyboardClickAudio();
    disableUpgradePurchaseBtns();
}

board_slot_6_income_upgrade_opt.onclick = function() {
    document.getElementById("purchase-dialog-overlay-6").style.display = "flex";
    document.getElementById("upgrade-slot-6-brief-panel").style.display = "flex";
    document.getElementById("upgrade-slot-6-brief-output").innerHTML = passive_income_upgrade_brief_txt;
    document.getElementById("upgrade-slot-6-price-output").innerHTML = "<span style='color: yellow; margin-right: 6px;'>PRICE -> </span><span style='color: lime'>" + board_slot_6_passive_income_upgrade_price.toLocaleString("en-US") + " COINS</span>" + "<img src='Images/Tycoon-score-balance-icon.png' style='margin-left: 5px;' width='25px' height='25px' />";
    keyboardClickAudio();
    disableUpgradePurchaseBtns();
}

// BOARD PASSIVE INCOME UPGRADE PURCHASE OPTS (within overlays)

board_slot_1_upgrade_passive_income_opt.onclick = function() {
    board_slot_1_upgrade_passive_income_opt.disabled = true;
    board_slot_1_upgrade_passive_income_opt.style.opacity = "0.5";
    board_slot_1_upgrade_passive_income_opt.style.cursor = "not-allowed";
    setTimeout(() => {
        board_slot_1_upgrade_passive_income_opt.disabled = false;
        board_slot_1_upgrade_passive_income_opt.style.opacity = "1";
        board_slot_1_upgrade_passive_income_opt.style.cursor = "pointer";
    }, 1500)
        if (player_cash_balance >= board_slot_1_passive_income_upgrade_price) {
        if (task_2_active) {
            task_2_progress = increaseProgressValue(task_2_progress, task_2_progress_bar, 5);
            task_2_progress_bar.value = task_2_progress;
        }
        if (task_3_active) {
            task_3_progress = increaseProgressValue(task_3_progress, task_3_progress_bar, 5);
            task_3_progress_bar.value = task_3_progress;
        }
    }
    purchaseUpgrade(board_slot_1_passive_income_upgrade_price, board_1_grant_amount, 10, document.getElementById("purchase-dialog-overlay-1"), "cash");
}

board_slot_2_upgrade_passive_income_opt.onclick = function() {
    board_slot_2_upgrade_passive_income_opt.disabled = true;
    board_slot_2_upgrade_passive_income_opt.style.opacity = "0.5";
    board_slot_2_upgrade_passive_income_opt.style.cursor = "not-allowed";
    setTimeout(() => {
        board_slot_2_upgrade_passive_income_opt.disabled = false;
        board_slot_2_upgrade_passive_income_opt.style.opacity = "1";
        board_slot_2_upgrade_passive_income_opt.style.cursor = "pointer";
    }, 1500)
    if (player_cash_balance >= board_slot_2_passive_income_upgrade_price) {
        if (task_2_active) {
            task_2_progress = increaseProgressValue(task_2_progress, task_2_progress_bar, 10);
            task_2_progress_bar.value = task_2_progress;
        }
        if (task_3_active) {
            task_3_progress = increaseProgressValue(task_3_progress, task_3_progress_bar, 10);
            task_3_progress_bar.value = task_3_progress;
        }
    }
    purchaseUpgrade(board_slot_2_passive_income_upgrade_price, board_2_grant_amount, 20, document.getElementById("purchase-dialog-overlay-2"), "cash");
}

board_slot_3_upgrade_passive_income_opt.onclick = function() {
    board_slot_3_upgrade_passive_income_opt.disabled = true;
    board_slot_3_upgrade_passive_income_opt.style.opacity = "0.5";
    board_slot_3_upgrade_passive_income_opt.style.cursor = "not-allowed";
    setTimeout(() => {
        board_slot_3_upgrade_passive_income_opt.disabled = false;
        board_slot_3_upgrade_passive_income_opt.style.opacity = "1";
        board_slot_3_upgrade_passive_income_opt.style.cursor = "pointer";
    }, 1500)
    if (player_cash_balance >= board_slot_3_passive_income_upgrade_price) {
        if (task_2_active) {
            task_2_progress = increaseProgressValue(task_2_progress, task_2_progress_bar, 25);
            task_2_progress_bar.value = task_2_progress;
        }
        if (task_3_active) {
            task_3_progress = increaseProgressValue(task_3_progress, task_3_progress_bar, 25);
            task_3_progress_bar.value = task_3_progress;
        }
    }
    purchaseUpgrade(board_slot_3_passive_income_upgrade_price, board_3_grant_amount, 30, document.getElementById("purchase-dialog-overlay-3"), "cash");
}

board_slot_4_upgrade_passive_income_opt.onclick = function() {
    board_slot_4_upgrade_passive_income_opt.disabled = true;
    board_slot_4_upgrade_passive_income_opt.style.opacity = "0.5";
    board_slot_4_upgrade_passive_income_opt.style.cursor = "not-allowed";
    setTimeout(() => {
        board_slot_4_upgrade_passive_income_opt.disabled = false;
        board_slot_4_upgrade_passive_income_opt.style.opacity = "1";
        board_slot_4_upgrade_passive_income_opt.style.cursor = "pointer";
    }, 1500)
    if (player_cash_balance >= board_slot_4_passive_income_upgrade_price) {
        if (task_2_active) {
            task_2_progress = increaseProgressValue(task_2_progress, task_2_progress_bar, 50);
            task_2_progress_bar.value = task_2_progress;
        }
        if (task_3_active) {
            task_3_progress = increaseProgressValue(task_3_progress, task_3_progress_bar, 50);
            task_3_progress_bar.value = task_3_progress;
        }
    }
    purchaseUpgrade(board_slot_4_passive_income_upgrade_price, board_4_grant_amount, 50, document.getElementById("purchase-dialog-overlay-4"), "cash");
}

board_slot_5_upgrade_passive_income_opt.onclick = function() {
    board_slot_5_upgrade_passive_income_opt.disabled = true;
    board_slot_5_upgrade_passive_income_opt.style.opacity = "0.5";
    board_slot_5_upgrade_passive_income_opt.style.cursor = "not-allowed";
    setTimeout(() => {
        board_slot_5_upgrade_passive_income_opt.disabled = false;
        board_slot_5_upgrade_passive_income_opt.style.opacity = "1";
        board_slot_5_upgrade_passive_income_opt.style.cursor = "pointer";
    }, 1500)
    if (player_cash_balance >= board_slot_5_passive_income_upgrade_price) {
        if (task_2_active) {
            task_2_progress = increaseProgressValue(task_2_progress, task_2_progress_bar, 100);
            task_2_progress_bar.value = task_2_progress;
        }
        if (task_3_active) {
            task_3_progress = increaseProgressValue(task_3_progress, task_3_progress_bar, 100);
            task_3_progress_bar.value = task_3_progress;
        }
    }
    purchaseUpgrade(board_slot_6_passive_income_upgrade_price, board_6_grant_amount, 200, document.getElementById("purchase-dialog-overlay-6"), "coins");
}

board_slot_6_upgrade_passive_income_opt.onclick = function() {
    board_slot_6_upgrade_passive_income_opt.disabled = true;
    board_slot_6_upgrade_passive_income_opt.style.opacity = "0.5";
    board_slot_6_upgrade_passive_income_opt.style.cursor = "not-allowed";
    setTimeout(() => {
        board_slot_6_upgrade_passive_income_opt.disabled = false;
        board_slot_6_upgrade_passive_income_opt.style.opacity = "1";
        board_slot_6_upgrade_passive_income_opt.style.cursor = "pointer";
    }, 1500)
    if (player_cash_balance >= board_slot_6_passive_income_upgrade_price) {
        if (task_2_active) {
            task_2_progress = increaseProgressValue(task_2_progress, task_2_progress_bar, 250);
            task_2_progress_bar.value = task_2_progress;
        }
        if (task_3_active) {
            task_3_progress = increaseProgressValue(task_3_progress, task_3_progress_bar, 250);
            task_3_progress_bar.value = task_3_progress;
        }
    }
    purchaseUpgrade(board_slot_6_passive_income_upgrade_price, board_6_grant_amount, 200, document.getElementById("purchase-dialog-overlay-6"), player_coins_balance);
}