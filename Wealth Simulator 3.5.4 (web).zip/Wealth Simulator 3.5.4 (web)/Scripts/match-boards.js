let match_boards_ui = document.getElementById("main-body-wrapper");
let match_boards_title = document.getElementById("match-boards-title");
let match_boards_info_list = document.getElementById("match-boards-info-list");
let match_boards_opt = document.getElementById("match-boards-opt");
let close_paytable_btn = document.getElementById("close-paytable-btn");
let boardSlotsStorage = document.getElementsByClassName('board-square-slot');
let slot_radius_inp_slider = document.getElementById("slot-radius-inp-slider");
let slot_border_color_inp_slider = document.getElementById("slot-border-color-inp-slider");
let slot_margin_inp_slider = document.getElementById("slot-margin-inp-slider");
let start_game_btn = document.getElementById("start-btn");
let tools_btn = document.getElementById("tools-btn");
let reset_game_btn = document.getElementById("reset-btn");
let main_game_board = document.getElementById("main-game-board-wrapper");
let stats_tab = document.getElementById("stats-tab-wrapper");
let controls_tab = document.getElementById("controls-tab");
let board_square_slot = document.getElementsByClassName("board-square-slot");
let board_creation_opts_dialog_overlay = document.getElementById("board-creation-opts-dialog-overlay");

let alpha_rng_arr = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "$", "♤", "♡", "◇", "♧", "●", "□", "■", "☆", "¥"];
let gambleResponseArr = ["Bad luck?", "You won.. NOTHING!", "Good luck next time ;)", "Well you must be unlucky hehe", "You have a problem bro!"];
let slot_color_options = ["red", "orange", "brown", "yellow", "green", "turquoise", "blue", "pink", "white", "#FE6F5E", "FF0800", "#C51E3A", "#FF004F", "#BF00FF"]

let jackpot_win_odds = 1500; // def: 1500
let jackpot_reward_amount = 10000;
let diamond_win_odds = 900; // def: 900
let cash_win_odds = 150; // def: 150
let pts_win_odds = 36; // def: 36
let pts_cluster_win_odds = 25; // def: 250
let troll_win_odds = 500; // def: 1000
let free_slots_win_odds = 10 // def: 1750

let xp_booster_win_odds = 3; // def: 100
let mystery_token_win_odds = 3; // def: 100
let x2_farm_income_win_odds = 3; // def: 125
let x3_farm_income_win_odds = 3; // def: 140
let x5_farm_speed_win_odds = 130; // def: 130
let last_life_win_odds = 90; // def: 90

let total_boards_completed = 0;
let total_slots_revealed = 0;

const total_square_slots = 36;
const slot_int_max = boardSlotsStorage.length;
let slot_rng_value = Math.floor(Math.random() * slot_int_max);
let slot_inc_req = 0;
let price = 5;
let slot_func;
let slots_revealed_total = 0;
let earned_cash_balance = 0;

let winning_rng_value;
let winning_rng_value_2;
let winning_rng_value_3;

let board_slot_color_rng_range = 16777215;
let auto_reveal_int = null;
let auto_reveal_rng_cycle = null;
let randomly_picked_slot = null;

function GenerateWinningNumbers() {
    winning_rng_value = Math.floor(Math.random() * slot_int_max);
    winning_rng_value_2 = Math.floor(Math.random() * slot_int_max);
    winning_rng_value_3 = Math.floor(Math.random() * slot_int_max);

    document.getElementById("rng_value_output").innerHTML = "WINNING NUMBERS : " + "<span style='color: violet'>" + winning_rng_value + "</span>" + ", " + "<span style='color: orange'>" + winning_rng_value_2 + "</span>" + ", " + "<span style='color: aqua'>" + winning_rng_value_3 + "</span>";
}

match_boards_opt.addEventListener("click", function () { UiClosure();  match_boards_ui.style.display = "flex"; document.getElementById("slot-selection-dialog-overlay").style.display = "none"; });

close_paytable_btn.addEventListener("click", function () {
    document.getElementById("pay-table").style.display = "none";
    document.getElementById("tools-btn").style.display = "block";
    document.getElementById("paytable-btn").style.display = "block";
    document.getElementById("collapse-btn").style.display = "none";
});

document.getElementById("slot-radius-inp-slider").oninput = function () {
    let value = slot_radius_inp_slider.value;
    for (let s = 0; board_square_slot.length; s++) { board_square_slot[s].style.borderRadius = value + "px"; }
}

document.getElementById("slot-margin-inp-slider").oninput = function () {
    let value = slot_margin_inp_slider.value;
    for (let m = 0; board_square_slot.length; m++) { board_square_slot[m].style.margin = value + "px"; }
}

document.getElementById("tools-btn").onclick = function () {
    document.getElementById("tools-btn").style.display = "none";
    document.getElementById("paytable-btn").style.display = "none";
    document.getElementById("collapse-btn").style.display = "block";
    document.getElementById("board-tools-panel").style.display = "flex";
}

document.getElementById("paytable-btn").onclick = function () {
    document.getElementById("pay-table").style.display = "flex";
    document.getElementById("paytable-btn").style.display = "none";
    document.getElementById("collapse-btn").style.display = "block";
    document.getElementById("tools-btn").style.display = "none";
}

document.getElementById("collapse-btn").onclick = function () {
    document.getElementById("pay-table").style.display = "none";
    document.getElementById("tools-btn").style.display = "block";
    document.getElementById("paytable-btn").style.display = "block";
    document.getElementById("collapse-btn").style.display = "none";
    document.getElementById("board-tools-panel").style.display = "none";
}

setInterval(function () {
    document.getElementById("total-slot-output").innerHTML = "<span style='color: orange'>PROGRESS</span> : " + slot_inc_req + " / " + boardSlotsStorage.length + " <span style='color: #FF00FF'> </span> " + '<img src="Images/Unknown.png" width="25px" height="25px" />';
    document.getElementById("slider-radius-output").innerHTML = "<span style='color: yellow'>SLOT BORDER RADIUS</span> : " + slot_radius_inp_slider.value + "px";
    document.getElementById("slider-margin-output").innerHTML = "<span style='color: yellow'>SLOT MARGINS</span> : " + slot_margin_inp_slider.value + "px";
    
    if (slot_inc_req == total_square_slots) {
        start_game_btn.disabled = true;
        reset_game_btn.disabled = true;
        stats_tab.style.display = "flex";
        player_coins_balance += 50;
        total_boards_completed += 1;

        setTimeout(() => { document.getElementById("stats-tab-wrapper").style.display = "none"; }, 3000);
        setTimeout(() => { boardCompletedAudio(); document.getElementById("collapse-btn").style.display = "none"; }, 200);
        setTimeout(function () { 
            reset_game_btn.disabled = true; reset_game_btn.style.opacity = "0.5"; reset_game_btn.style.cursor = "not-allowed";
            tools_btn.disabled = true; tools_btn.style.opacity = "0.5"; tools_btn.style.cursor = "not-allowed";
        }, 100);
        setTimeout(() => { enableCreationOpts(); tools_btn.style.display = "none"; reset_game_btn.style.display = "none"; start_game_btn.style.display = "block"; start_game_btn.disabled = false; }, 4000);

        document.getElementById("board-tools-panel").style.display = "none";
        document.getElementById("board-win-output").style.display = "block";
        document.getElementById("board-win-output").innerHTML = "<br><img src='Images/BOARD-COMPLETED.png' width='90%' height='30px' />";

        setTimeout(function () {
            document.getElementById("match-boards-info-list").style.display = "block";
            document.getElementById("match-boards-title").style.display = "flex";
            document.getElementById("board-win-output").style.display = "none";
            document.getElementById("rng_value_output").innerHTML = "";
            document.getElementById("total-slot-output").style.display = "none";
            document.getElementById("board-wrapper").style.display = "none";
            document.getElementById("paytable-btn").style.display = "none";
            document.getElementById("pay-table").style.display = "none";
            document.getElementById("board-logs-panel").style.display = "none";
            document.getElementById("controls-tab").style.display = "none";

            document.getElementById("rng_value_output").style.display = "none";
            start_game_btn.style.display = "block";
        }, 3000)

        for (let bs = 0; bs < board_square_slot.length; bs++) {
            let slot_reset_int = setInterval(function () {
                reset_game_btn.disabled = true;
                board_square_slot[bs].disabled = true;
                board_square_slot[bs].style.color = "yellow";
                board_square_slot[bs].style.border = "3px solid snow";
                board_square_slot[bs].style.backgroundColor = "navy";
                board_square_slot[bs].innerHTML = "<img src='Images/X.png' width='95%' height='30px' />";

                winning_rng_value = Math.floor(Math.random() * slot_int_max);
                winning_rng_value_2 = Math.floor(Math.random() * slot_int_max);
                winning_rng_value_3 = Math.floor(Math.random() * slot_int_max);
            }, 1000)

            setTimeout(function () { slot_inc_req = 0; clearInterval(slot_reset_int); }, 1000)
        }

        setTimeout(function () {
            for (let y = 0; y < board_square_slot.length; y++) {
                board_square_slot[y].style.display = "flex";
                board_square_slot[y].style.backgroundColor = "navy";
                board_square_slot[y].disabled = false;
                board_square_slot[y].innerHTML = "<img src='Images/Unknown.png' width='70%' height='20px' />";
                slot_inc_req = 0
            }
        }, 2500)

        setTimeout(function () {
            reset_game_btn.style.display = "block";
            for (let y = 0; y < board_square_slot.length; y++) {
                board_square_slot[y].style.display = "flex";
                board_square_slot[y].style.backgroundColor = "";
                board_square_slot[y].disabled = false;
                board_square_slot[y].innerHTML = "<img src='Images/Unknown.png' width='70%' height='20px' />";
            }
        }, 2500)

        slots_revealed_total = 0;
        slot_inc_req = 0;
    }

    if (slot_rng_value === slot_rng_value) { slot_rng_value = Math.floor(Math.random() * slot_int_max); }
}, 10)

start_game_btn.onclick = function() { board_creation_opts_dialog_overlay.style.display = "flex"; }

document.getElementById("close-board-creation-opts-dialog-overlay-btn").onclick = function() {
    board_creation_opts_dialog_overlay.style.display = "none";
}

let board_creation_cash_opt = document.getElementById("board-creation-cash-opt");
let board_creation_coins_opt = document.getElementById("board-creation-coin-opt");
let board_creation_diamond_opt = document.getElementById("board-creation-diamond-opt");

board_creation_cash_opt.onclick = function() { board_creation_validation("cash", player_cash_balance, 100); }
board_creation_coins_opt.onclick = function() { board_creation_validation("coins", player_coins_balance, 150); }
board_creation_diamond_opt.onclick = function() { board_creation_validation("diamonds", player_diamond_balance, 2); }

function disableCreationOpts() {
    board_creation_cash_opt.disabled = true; board_creation_cash_opt.style.opacity = "0.5"; board_creation_cash_opt.style.cursor = "not-allowed";
    board_creation_coins_opt.disabled = true; board_creation_coins_opt.style.opacity = "0.5"; board_creation_coins_opt.style.cursor = "not-allowed";
    board_creation_diamond_opt.disabled = true; board_creation_diamond_opt.style.opacity = "0.5"; board_creation_diamond_opt.style.cursor = "not-allowed";
}

function enableCreationOpts() {
    board_creation_cash_opt.disabled = false; board_creation_cash_opt.style.opacity = "1"; board_creation_cash_opt.style.cursor = "pointer";
    board_creation_coins_opt.disabled = false; board_creation_coins_opt.style.opacity = "1"; board_creation_coins_opt.style.cursor = "pointer";
    board_creation_diamond_opt.disabled = false; board_creation_diamond_opt.style.opacity = "1"; board_creation_diamond_opt.style.cursor = "pointer";
}

function initiate_creation() { setTimeout(() => { create_board(); }, 1000); }

function board_creation_validation(creation_payment_balance_type_ref, balance_type, creation_price) {
    if (balance_type >= creation_price) {
        switch (creation_payment_balance_type_ref) {
            case "cash":
                player_cash_balance -= creation_price;
                notificationDialog("[SUCCESS] >> Initiating...", 1000);
                mysteryWinAudio();
                disableCreationOpts();
                initiate_creation();
                break;
            case "coins":
                player_coins_balance -= creation_price;
                notificationDialog("[SUCCESS] >> Initiating...", 1000);
                mysteryWinAudio();
                disableCreationOpts();
                initiate_creation();
                break;
            case "diamonds":
                player_diamond_balance -= creation_price;
                notificationDialog("[SUCCESS] >> Initiating...", 1000);
                mysteryWinAudio();
                disableCreationOpts();
                initiate_creation();
                break;
        }
    } else {
        switch (creation_payment_balance_type_ref) {
            case "cash":
                notificationDialog("Insufficient Funds! (Price >> $100)", 3000);
                insufficientFundsAudio();
                break;
            case "coins":
                notificationDialog("Insufficient Coins! (Price >> X150 Coins)", 3000);
                insufficientCoinsAudio();
                break;
            case "diamonds":
                notificationDialog("Insufficient Diamonds! (Price >> X2 Diamonds)", 3000);
                insufficientDiamondsAudio();
                break;
        }
    }
}

function create_board() { // BOARD GENERATION SEQUENCE
    GenerateWinningNumbers();
    createBoardAudio();
    disableCreationOpts();

    reset_game_btn.disabled = false; reset_game_btn.style.opacity = "0.5"; reset_game_btn.style.cursor = "not-allowed";
    start_game_btn.disabled = true; start_game_btn.style.opacity = "0.5"; start_game_btn.style.cursor = "not-allowed";
    controls_tab.style.display = "flex";
    main_game_board.style.display = "flex";
    reset_game_btn.style.display = "block";
    match_boards_title.style.display = "none";
    match_boards_info_list.style.display = "none";
    reset_game_btn.disabled = true;
    slot_inc_req = 0;
    slots_revealed_total = 0;
    document.getElementById("tools-btn").style.display = "block";
    document.getElementById("start-btn").style.display = "none";
    document.getElementById("controls-tab").style.display = "flex";
    board_creation_opts_dialog_overlay.style.display = "none";

    clearInterval(auto_reveal_int);
    clearInterval(auto_reveal_rng_cycle);

    setTimeout(() => { document.getElementById("stats-tab-wrapper").style.display = "flex"; }, 1500);
    setTimeout(function () {
        reset_game_btn.disabled = false; reset_game_btn.style.opacity = "1"; reset_game_btn.style.cursor = "pointer";
        tools_btn.disabled = false; tools_btn.style.opacity = "1"; tools_btn.style.cursor = "pointer";
        start_game_btn.disabled = false; start_game_btn.style.opacity = "1"; start_game_btn.style.cursor = "pointer";
    }, 5000)

    if (document.getElementById("misc-1-config-state").checked == true) {
        board_slot_color_rng_range = 0;
        let tran_slot_int = setInterval(function () {
            for (let ts = 0; ts < board_square_slot.length; ts++) {
                board_square_slot[ts].style.background = "transparent";
            }
        }, 100)
        oscClickAudio();
        setTimeout(function () { clearInterval(tran_slot_int); }, 5000)
    } else if (document.getElementById("misc-1-config-state").checked == false) {
        board_slot_color_rng_range = 16777215;
        oscClickAudio();
    }

    if (document.getElementById("jackpot-hunter-config-state").checked == true) {
        jackpot_win_odds = 750;
        console.log(jackpot_win_odds);
        price = 15;
        oscClickAudio();
    } else if (document.getElementById("jackpot-hunter-config-state").checked == false) {
        jackpot_win_odds = 1500;
        console.log(jackpot_win_odds);
        oscClickAudio();
    } else {
        console.log(jackpot_win_odds);
    }

    document.getElementById("board-win-output").style.display = "block";
    document.getElementById("board-win-output").innerHTML = "<span style='color: yellow'>[INFO]</span>: <span style='color: aqua'>PREPARING BOARD...</span>";

    setTimeout(function () {
        document.getElementById("board-win-output").style.display = "none";
        //document.getElementById("rng_value_output").innerHTML = "";
        slots_revealed_total = 0;
    }, 5000)

    let rgb_rng_int = setInterval(function () {
        function rbg_rng() {
            let randomColor = Math.floor(Math.random() * board_slot_color_rng_range).toString(16);
            let randomColor_2 = Math.floor(Math.random() * board_slot_color_rng_range).toString(16);

            let rgbValue = "#" + randomColor;
            let rgbValue_2 = "#" + randomColor_2;

            for (let slot_rgb = 0; slot_rgb < board_square_slot.length; slot_rgb++) {
                board_square_slot[slot_rgb].style.backgroundImage = "linear-gradient(" + rgbValue + "," +  rgbValue_2 + ")";
                //board_square_slot[slot_rgb].style.border = "3px solid " + rgbValue_2;
                board_square_slot[slot_rgb].innerHTML = Math.floor(Math.random() * 36);
                let i = Math.floor(Math.random() * alpha_rng_arr.length);
                let ra = alpha_rng_arr[i];
                board_square_slot[i].innerHTML = ra;
                board_square_slot[slot_rgb].disabled = true;
            }
        }
        rbg_rng();
    }, 600)

    setTimeout(function () {
        clearInterval(rgb_rng_int);
        document.getElementById("board-win-output").style.display = "block";
        document.getElementById("board-win-output").innerHTML = "REVEAL THE SLOTS!";
        document.getElementById("total-slot-output").style.display = "flex";
        document.getElementById("total-slot-output-wrapper").style.display = "block";
        for (let sb = 0; board_square_slot.length; sb++) {
            board_square_slot[sb].style.background = "blue";
            board_square_slot[sb].style.color = "yellow";
            board_square_slot[sb].innerHTML = "<img src='Images/Unknown.png' width='95%' height='35px' />";
            board_square_slot[sb].style.opacity = "1";
            board_square_slot[sb].style.cursor = "pointer";
            board_square_slot[sb].disabled = false;
        }
    }, 5000)

    document.getElementById("total-slot-output-wrapper").style.display = "none";
    document.getElementById("board-win-output").style.display = "block";
    document.getElementById("stats-tab-wrapper").style.display = "block";
    document.getElementById("board-wrapper").style.display = "flex";
    document.getElementById("paytable-btn").style.display = "block";
    document.getElementById("rng_value_output").style.display = "block";

    for (let y = 0; y < board_square_slot.length; y++) {
        board_square_slot[y].style.display = "flex";
        board_square_slot[y].style.backgroundColor = "navy";
        board_square_slot[y].disabled = false;
        board_square_slot[y].innerHTML = "<img src='Images/Unknown.png' width='95%' height='40px' />";
    }

    let slot_reset_int = setInterval(function () {
        for (let c = 0; c < board_square_slot.length; c++) {
            board_square_slot[c].style.display = "flex";
            board_square_slot[c].innerHTML = "<img src='Images/Unknown.png' width='85%' height='30px' />";
        }
    }, 10)
    setTimeout(function () { clearInterval(slot_reset_int) }, 500);
}

let reset_board = (reset_game_btn.onclick = function () { // BOARD RESET SEQUENCE
    clearInterval(auto_reveal_int);
    clearInterval(auto_reveal_rng_cycle);

    let board_reset_warning = confirm("[WARNING]: This action will reset all slots, and your progress towards completing the board! You have revelead [" + slots_revealed_total + "/" + "36]. " + "Click (OK) to proceed or (CANCEL)");

    if (board_reset_warning == true) {
        reset_game_btn.disabled = true;
        controls_tab.style.display = "none";
        resetBoardAudio();
        if (document.getElementById("auto-create-board-state").checked == true) {
            start_game_btn.disabled = true; start_game_btn.style.opacity = "0.5"; start_game_btn.style.cursor = "not-allowed";
            setTimeout(function () { create_board(); }, 3500);
            oscClickAudio();
        }
        for (let bs = 0; bs < board_square_slot.length; bs++) {
            let slot_reset_int = setInterval(function () {
                board_square_slot[bs].disabled = true;
                board_square_slot[bs].style.border = "3px solid snow";
                board_square_slot[bs].style.backgroundColor = "darkblue";
                board_square_slot[bs].innerHTML = "<img src='Images/X.png' width='95%' height='30px' />";
            }, 500)

            setTimeout(function () { clearInterval(slot_reset_int); }, 2000)
        }

        setTimeout(function () {
            for (let b = 0; b < board_square_slot.length; b++) { board_square_slot[b].style.display = "flex"; }
            for (let y = 0; y < board_square_slot.length; y++) {
                board_square_slot[y].style.display = "none";
                board_square_slot[y].style.color = "yellow";
                board_square_slot[y].innerText = "";
            }

            document.getElementById("start-btn").style.display = "block";
            reset_game_btn.style.display = "none";
            start_game_btn.disabled = true; start_game_btn.style.opacity = "0.5"; start_game_btn.style.cursor = "not-allowed";
            //controls_tab.style.display = "flex";
            stats_tab.style.display = "flex";
            match_boards_title.style.display = "block";
            match_boards_info_list.style.display = "block";

            setTimeout(function () { start_game_btn.disabled = false; start_game_btn.style.opacity = "1"; start_game_btn.style.cursor = "pointer"; enableCreationOpts(); }, 1500)
            setTimeout(() => { document.getElementById("stats-tab-wrapper").style.display = "none"; }, 500);

            document.getElementById("match-boards-info-list").style.display = "block";
            document.getElementById("match-boards-title").style.display = "flex";
            document.getElementById("board-tools-panel").style.display = "none";
            document.getElementById("board-wrapper").style.display = "none";
            document.getElementById("paytable-btn").style.display = "none";
            document.getElementById("collapse-btn").style.display = "none";
            document.getElementById("pay-table").style.display = "none";
            document.getElementById("board-tools-panel").style.display = "none";
            document.getElementById("rng_value_output").style.display = "none";
            document.getElementById("total-slot-output").style.display = "none";
            document.getElementById("board-win-output").innerHTML = "<span style='color: yellow'>[NOTE]</span> >> <span style='color: aqua'>CREATE A BOARD!</span>";

            slots_revealed_total = 0;
            slot_inc_req = 0;
            winning_rng_value = Math.floor(Math.random() * slot_int_max);
            winning_rng_value_2 = Math.floor(Math.random() * slot_int_max);
            winning_rng_value_3 = Math.floor(Math.random() * slot_int_max);
        }, 2000)
    } else {
        document.getElementById("board-win-output").style.display = "block";
    }
})

for (let x = 0; x < board_square_slot.length; x++) {
    slot_func = board_square_slot[x].onclick = function () {
        oscClickAudio();
        if (player_cash_balance < price) {
            notificationDialog("INSUFFICIENT FUNDS!", 3000);
            insufficientFundsAudio();
            document.getElementById("board-win-output").style.display = "block";
            document.getElementById("board-win-output").innerHTML = "<span style='color: snow'>[INFO]: </span>" + '<span style="color: red">' + "INSUFFICIENT FUNDS!" + "</span>";

            for (let b = 0; b < board_square_slot.length; b++) { board_square_slot[b].disabled = true; }

            setTimeout(function () {
                for (let b = 0; b < board_square_slot.length; b++) { board_square_slot[b].disabled = false; }
                document.getElementById("board-win-output").style.display = "none";
            }, 2000);
            return;
        }

        slot_rng_value = Math.floor(Math.random() * slot_int_max);
        slots_revealed_total += 1;
        total_slots_revealed += 1;
        player_cash_balance -= price;

        console.log(slot_rng_value);
        slot_inc_req++;

        board_square_slot[x].innerText = slot_rng_value;
        board_square_slot[x].style.border = "3px solid whitesmoke";
        board_square_slot[x].style.backgroundImage = "linear-gradient(black, darkblue)";
        board_square_slot[x].style.cursor = "not-allowed";
        board_square_slot[x].disabled = true;

        let jackpot_rng = Math.floor(Math.random() * jackpot_win_odds);
        let pts_win_rng = Math.floor(Math.random() * pts_win_odds);
        let pts_cluster_win_rng = Math.floor(Math.random() * pts_cluster_win_odds);
        let diamond_win_rng = Math.floor(Math.random() * diamond_win_odds);
        let free_slot_win_rng = Math.floor(Math.random() * free_slots_win_odds);
        let troll_rng = Math.floor(Math.random() * troll_win_odds);
        let cash_win_rng = Math.floor(Math.random() * cash_win_odds);

        let xp_booster_rng = Math.floor(Math.random() * xp_booster_win_odds);
        let mystery_token_rng = Math.floor(Math.random() * mystery_token_win_odds);
        let x2_farm_income_rng = Math.floor(Math.random() * x2_farm_income_win_odds);
        let x3_farm_income_rng = Math.floor(Math.random() * x3_farm_income_win_odds);
        let x5_farm_speed_rng = Math.floor(Math.random() * x5_farm_speed_win_odds);
        let last_life_rng = Math.floor(Math.random() * last_life_win_odds);

        if (slot_rng_value == 0) {
            player_cash_balance += price;

            document.getElementById("board-win-output").style.display = "block";
            document.getElementById("board-win-output").innerHTML = "<span style='color: snow'>" + 0 + " </span>" + "<span style='color: yellow'>REFUNDED : </span>" + '<span style="color: lime">$' + 100 + ".00 </span>";

            setTimeout(function () { document.getElementById("board-win-output").innerHTML = "LAST WIN - [REFUNDED] - " + "<span style='color: lime'> $" + 100 + "</span>" }, 1500)
        }

        if (slot_rng_value == winning_rng_value) { // WINNING NUMBER (1) MATCH
            smallDingAudio();
            player_cash_balance += 20;
            board_square_slot[x].style.backgroundColor = "black";
            board_square_slot[x].style.border = "3px solid violet";
            board_square_slot[x].style.color = "violet";
            document.getElementById("board-win-output").style.display = "block";
            document.getElementById("board-win-output").innerHTML = "<span style='color: violet'>" + winning_rng_value + "</span>" + " - <span style='color: yellow'>WIN : </span>" + '<span style="color: lime">$' + formatMoneyValue(20) + "</span>";
            setTimeout(function () { document.getElementById("board-win-output").innerHTML = "LAST WIN - " + "<span style='color: aqua'>" + winning_rng_value + "</span>" + " : <span style='color: lime'>$" + formatMoneyValue(20) + "</span>"; }, 1500);
        } else if (slot_rng_value == winning_rng_value_2) { // WINNING NUMBER (2) MATCH
            smallDingAudio();
            player_cash_balance += 25;
            board_square_slot[x].style.backgroundColor = "black";
            board_square_slot[x].style.border = "3px solid orange";
            board_square_slot[x].style.color = "orange";
            document.getElementById("board-win-output").style.display = "block";
            document.getElementById("board-win-output").innerHTML = "<span style='color: orange'>" + winning_rng_value_2 + "</span>" + " - <span style='color: yellow'>WIN : </span>" + '<span style="color: lime">$' + formatMoneyValue(25) + "</span>";
            setTimeout(function () { document.getElementById("board-win-output").innerHTML = "LAST WIN - " + "<span style='color: orange'>" + winning_rng_value_2 + "</span>" + " : <span style='color: lime'>$" + formatMoneyValue(25) + "</span>"; }, 1500)
        } else if (slot_rng_value == winning_rng_value_3) {  // WINNING NUMBER (3) MATCH
            smallDingAudio();
            board_square_slot[x].style.backgroundColor = "black";
            board_square_slot[x].style.border = "3px solid aqua";
            board_square_slot[x].style.color = "aqua";
            player_cash_balance += 30;
            document.getElementById("board-win-output").style.display = "block";
            document.getElementById("board-win-output").innerHTML = "<span style='color: aqua'>" + winning_rng_value_3 + "</span>" + " - <span style='color: yellow'>WIN : </span>" + '<span style="color: lime">$' + formatMoneyValue(30) + "</span>";
            setTimeout(function () { document.getElementById("board-win-output").innerHTML = "LAST WIN - " + "<span style='color: aqua'>" + winning_rng_value_3 + "</span>" + " : <span style='color: lime'>$" + formatMoneyValue(30) + "</span>"; }, 1500);
        } else if (jackpot_rng === 1) { // jackpot win
            notificationDialog("YOU HAVE WON A JACKPOT OF $" + jackpot_reward_amount, 4000);
            console.log(jackpot_rng);
            player_cash_balance += jackpot_reward_amount;
            board_square_slot[x].innerHTML = "<img src='Images/777.png' width='95%' height='25px' />";
        } else if (pts_win_rng === 1) { // Coins win
            player_coins_balance += Math.round(Math.random() * 20);
            board_square_slot[x].innerHTML = "<img src='Images/Tycoon-score-balance-icon.png' width='98%' height='35px' />";
        } else if (pts_cluster_win_rng === 1) { // Coin cluster win
            player_coins_balance += 60;
            board_square_slot[x].innerHTML = "<img src='Images/Points-cluster.png' width='50px' height='50px' />";
        } else if (diamond_win_rng === 1) { // Diamond win
            player_diamond_balance += 1;
            board_square_slot[x].innerHTML = "<img src='Images/Diamond-icon.png' width='88%' height='25px' />";
        } else if (free_slot_win_rng === 1) { // Free slot picks win (30s)
            price = 0;
            inventory_slot_13_use_booster_opt.disabled = true; inventory_slot_13_use_booster_opt.style.opacity = "0.5"; inventory_slot_13_use_booster_opt.style.cursor = "not-allowed";
            setTimeout(function () { 
                price = 5;
                inventory_slot_13_use_booster_opt.disabled = false; inventory_slot_13_use_booster_opt.style.opacity = "1"; inventory_slot_13_use_booster_opt.style.cursor = "pointer";
            }, 30000);
            board_square_slot[x].innerHTML = "<img src='Images/Free.png' width='100%' height='35px' />";
        } else if (troll_rng === 1) { // Troll face win
            for (let tbh = 0; tbh < board_square_slot.length; tbh++) {
                board_square_slot[tbh].innerHTML = "<img src='Images/Troll-face.png' width='100%' height='35px' />";
                board_square_slot[tbh].style.backgroundColor = "navy";
                board_square_slot[tbh].style.border = "3px solid snow";
                board_square_slot[tbh].style.color = "yellow";
                board_square_slot[tbh].disabled = true;
                setTimeout(function () { 
                    board_square_slot[tbh].innerHTML = "<img src='Images/Troll-face.png' width='100%' height='35px' />";
                    setTimeout(function () { 
                        board_square_slot[tbh].innerHTML = "<img src='Images/Troll-face.png' width='100%' height='35px' />"; 
                    }, 500); 
                }, 1500);
            }
            reset_game_btn.disabled = true; reset_game_btn.style.opacity = "0.5"; reset_game_btn.style.cursor = "not-allowed";
            setTimeout(function () { create_board(); }, 5000);
        } else if (cash_win_rng === 1) { // Cash win
            const double_cost_win = price * 2;
            player_cash_balance += double_cost_win;
            board_square_slot[x].innerHTML = "<img src='Images/Cash-balance-icon.png' width='95%' height='40px' />";
        } else if (xp_booster_rng === 1) {
            notificationDialog("[WIN] > X1 XP BOOSTER ADDED TO INVENTORY!", 3500);
            board_square_slot[x].innerHTML = "<img src='Images/instant-level-up-booster.svg' width='100%' height='100%' />";
            inventory_slot_6_player_owned_amount++;
        } else if (mystery_token_rng === 1) {
            notificationDialog("[WIN] > X1 MYSTERY TOKEN ADDED TO INVENTORY!", 3500);
            board_square_slot[x].innerHTML = "<img src='Images/mystery-booster.svg' width='100%' height='100%' />";
            inventory_slot_9_player_owned_amount++;
        } else if (x2_farm_income_rng === 1) {
            notificationDialog("[WIN] > X1 DOUBLE FARM INCOME BOOSTER ADDED TO INVENTORY!", 3500);
            board_square_slot[x].innerHTML = "<img src='Images/x2-income.svg' width='100%' height='100%' />";
            inventory_slot_1_player_owned_amount++;
        } else if (x3_farm_income_rng === 1) {
            notificationDialog("[WIN] > X1 TRIPLE FARM INCOME BOOSTER ADDED TO INVENTORY!", 3500);
            board_square_slot[x].innerHTML = "<img src='Images/x3-income.svg' width='100%' height='100%' />";
            inventory_slot_2_player_owned_amount++;
        } else {
            console.log("[MATCH BOARDS] > ---");
        }
    }
}
