let player_cash_balance = 0;
let player_savings_balance = 0;
let player_coins_balance = 0;
let player_diamond_balance = 0;
let player_tycoon_score = 100;
let player_booster_tokens = 0;