let trivia_hub_ui = document.getElementById("trivia-panel");
let close_trivia_hub_ui_btn = document.getElementById("close-trivia-panel-btn");
let trivia_menu_opt = document.getElementById("trivia-menu-opt");
let trivia_answer_reveal_tool = document.getElementById("reveal-answer");
let timed_dif_timer_mod_dialog_overlay = document.getElementById("timed-dif-timer-mod-dialog-overlay");
let trivia_match_end_confirmation_dialog_overlay = document.getElementById("trivia-match-end-confirmation-dialog-overlay");
let close_timed_dif_timer_mod_dialog_overlay_btn = document.getElementById("close-timed-dif-timer-mod-dialog-overlay-btn");
let whats_new_trivia_opt = document.getElementById("whats-new-trivia-opt");
let whats_new_trivia_dialog_overlay = document.getElementById("whats-new-trivia-dialog-overlay");
let close_whats_new_trivia_dialog_overlay_btn = document.getElementById("close-whats-new-trivia-dialog-overlay-btn");
let accept_timed_dif_timer_mod_btn = document.getElementById("accept-timed-dif-timer-mod-btn");
let timer_mod_inp = document.getElementById("timer-mod-inp");
let cancel_match_end_action_opt = document.getElementById("cancel-match-end-action-opt");
let confirm_match_end_action_opt = document.getElementById("confirm-match-end-action-opt")

let incTriviaAnswersStorage = document.getElementsByClassName('inc-ans-btn');
let corTriviaAnswersStorage = document.getElementsByClassName('cor-ans-btn');
let triviaToolsStorage = document.getElementsByClassName('trivia-tool');
let triviaDifBtnsStorage = [document.getElementById('easy-dif'), document.getElementById('medium-dif'), document.getElementById('hard-dif')];

let timer_mod_decrease_btn = document.getElementById("timer-mod-decrease-btn");
let timer_mod_increase_btn = document.getElementById("timer-mod-increase-btn");

let user_trivia_score = 0;
let user_trivia_high_score = 0;
let user_trivia_attempts = "---";
let user_trivia_match_cash_won_total = 0;
let max_attempts = 0;
let selection_attempts = 0;
let trivia_reward_multiplier = 0;
let user_set_max_attempts = 0;
let user_set_trivia_dif = 0;
let user_set_trivia_dif_txt = "";
let user_set_cash_award = 0;
let user_set_score_award = 0;
let item_price = 0;
let game_total = 0;
let def_cor_ans_xp_grant = 5;
let answer_reveal_opt = document.getElementById("reveal-answer");
let timed_dif_question_timer_value = 30000; // 30S
let timed_dif_question_timer;
let input_value = 30000 / 1000;
let match_active = false;

let easy_dif_active = false;
let medium_dif_active = false;
let hard_dif_active = false;
let timed_dif_active = false;

let modified_match = false;
let modifiers_active = false;

let def_easy_dif_multiplier = 1.2;
let def_medium_dif_multiplier = 1.3;
let def_hard_dif_multiplier = 1.5;
let def_timed_dif_multiplier = 1.5;

let total_trivia_matches = 0;
let total_correct_answers = 0;
let total_incorrect_answers = 0;
let total_answer_reveals_purchased = 0;
let total_easy_matches = 0;
let total_medium_matches = 0;
let total_hard_matches = 0;
let total_timed_matches = 0;

let triviaQuestionsStorage = [];
let totalQuestions = 200;

let trivia_end_confirmation = false;

for (let i = 1; i <= totalQuestions; i++) {
    const question = document.getElementById(`question-${i}`);
    if (question) triviaQuestionsStorage.push(question);
}

timer_mod_increase_btn.addEventListener("click", () => {
    timer_mod_inp.stepUp();
    timer_mod_inp.dispatchEvent(new Event("input"));
    oscClickAudio();
});

timer_mod_decrease_btn.addEventListener("click", () => {
    timer_mod_inp.stepDown();
    timer_mod_inp.dispatchEvent(new Event("input"));
    oscClickAudio();
});

whats_new_trivia_opt.addEventListener("click", () => { whats_new_trivia_dialog_overlay.style.display = "flex"; oscClickAudio(); })
close_whats_new_trivia_dialog_overlay_btn.addEventListener("click", () => { whats_new_trivia_dialog_overlay.style.display = "none"; oscClickAudio(); })

trivia_menu_opt.onclick = function() { setTimeout(() => { trivia_hub_ui.style.display = "flex"; }, 250); UiClosure(); }

cancel_match_end_action_opt.onclick = function() { trivia_match_end_confirmation_dialog_overlay.style.display = "none"; keyboardClickAudio(); }

confirm_match_end_action_opt.onclick = function() {
    let trivia_reset_measure = setInterval( function() { document.getElementById("next-question-btn").style.display = "none"; }, 10);
    for (let td = 0; td < triviaDifBtnsStorage.length; td++) { triviaDifBtnsStorage[td].disabled = true;}
    setTimeout( function() { for (let td = 0; td < triviaDifBtnsStorage.length; td++) { triviaDifBtnsStorage[td].disabled = false; } }, 1000);
    setTimeout(() => { trivia_match_end_confirmation_dialog_overlay.style.display = "none"; }, 200);
    setTimeout( function() { user_set_trivia_dif_txt = ""; }, 5000);
    setTimeout( function() { clearInterval(trivia_reset_measure); }, 2500);

    document.getElementById("clock-tick-sfx").muted = true;

    keyboardClickAudio();
    user_trivia_attempts = 0;
}

document.getElementById('end-match').onclick = function() { trivia_match_end_confirmation_dialog_overlay.style.display = "flex"; }

close_trivia_hub_ui_btn.addEventListener("click", () => {
    document.getElementById("start-trivia-btn").disabled = true;
    document.getElementById("start-trivia-btn").style.opacity = "0.5";
    document.getElementById("start-trivia-btn").style.cursor = "not-allowed";
    setTimeout(() => {
        document.getElementById("start-trivia-btn").style.opacity = "1";
        document.getElementById("start-trivia-btn").style.cursor = "pointer";
    }, 2000)
    if (match_active) {
        setTimeout(() => {
            notificationDialog("CANCELING MATCH...", 3000)
            user_trivia_attempts = 0;
            match_active = false;
            easy_dif_active = false;
            medium_dif_active = false;
            hard_dif_active = false;
            timed_dif_active = false;
            trivia_answer_reveal_tool.disabled = false;
            trivia_answer_reveal_tool.style.opacity = "1";
            trivia_answer_reveal_tool.style.cursor = "pointer";
            auto_next_question_trigger_preference.disabled = false;
            auto_next_question_trigger_preference.style.opacity = "1";
            auto_next_question_trigger_preference.style.cursor = "pointer";
            document.getElementById("hide-dif-info-btn-2").click();
            document.getElementById("start-trivia-btn").style.display = "none";
            setTimeout(() => { trivia_hub_ui.style.display = "none" }, 2000)
        }, 1000)
    } else {
        trivia_hub_ui.style.display = "none";
    }
})

document.getElementById("hide-dif-info-btn").onclick = function() {
    document.getElementById("dif-info-panel").style.display = "none";
    document.getElementById("start-trivia-btn").style.display = "block";
    document.getElementById("difficulty-tab").style.display = "none";
    document.getElementById("dif-label").style.display = "none";
    document.getElementById("dif-label-2").style.display = "none";
    notificationDialog("Click [START] to begin match!", 2000);
}

document.getElementById("close-dif-info-output-btn").onclick = function() {
    document.getElementById("dif-info-panel").style.display = "none";
    document.getElementById("dif-info-output-2").innerHTML = "";
    match_active = false;
    modified_match = false;
    timed_dif_question_timer_value = 30000;
    trivia_reward_multiplier = 1.5;
    timer_mod_inp.value = 30;
    user_set_cash_award = 0;
    user_set_max_attempts = 0;
    user_set_score_award = 0;
    user_set_trivia_dif = 0;
    user_set_trivia_dif_txt = "";
    user_trivia_attempts = 999;
}

document.getElementById("hide-dif-info-btn-2").onclick = function() {
    document.getElementById("match-results-panel").style.display = "none";
    document.getElementById("timed-dif-timer-output").style.display = "none";
    document.getElementById("timed-dif-timer-output").innerHTML = "";
    document.getElementById("difficulty-tab").style.display = "flex";
    document.getElementById("question-panel").innerHTML = "";
    document.getElementById("dif-label").style.display = "block";
    document.getElementById("dif-label-2").style.display = "block";
    document.getElementById("trivia-tools-panel").style.display = "none";
    max_attempts = 0;
    selection_attempts = 0;
    user_trivia_score = 0;
    user_set_trivia_attempts = 0;
    user_set_trivia_dif_txt = "";
    user_set_cash_award = 0;
    user_set_score_award = 0;
    user_trivia_match_cash_won_total = 0;
    user_trivia_attempts = 999;
    timed_dif_question_timer_value = 30000;
    timer_mod_inp.value = 30;
    clearInterval(timed_dif_question_timer);
}

// TRIVIA TOOL (ANSWER REVEAL)

document.getElementById('reveal-answer').onclick = function() {
    item_price = 45;
    
    if (player_coins_balance >= item_price) {
        player_coins_balance -= item_price;
        total_answer_reveals_purchased++;
        keyboardClickAudio();
        setTimeout( function() {
            notificationDialog("INCORRECT ANSWERS HIDDEN!", 3000);
            document.getElementById('reveal-answer').style.display = "none";
        }, 10)
        
        for (let ra = 0; ra < incTriviaAnswersStorage.length; ra++) {
            incTriviaAnswersStorage[ra].style.display = "none";
        }
    } else {
        notificationDialog("Insufficient Coins!", 3000);
        upgradePurchaseFailedAudio();
    }
}

// EASY DOFFICULTY

document.getElementById('easy-dif').onclick = function() {
    
    setTimeout( function() {
        user_trivia_attempts -= 999;
        user_set_max_attempts = 3;
        user_trivia_attempts += user_set_max_attempts;
        trivia_reward_multiplier = def_easy_dif_multiplier;
        user_set_cash_award = 1;
        user_set_score_award = 1;
        user_set_trivia_dif_txt = "EASY";
        easy_dif_active = true;
        medium_dif_active = false;
        hard_dif_active = false;
        timed_dif_active = false;
        match_active = true;
        enableAnswerRevelation();
        keyboardClickAudio();

        document.getElementById("timer-mod-btn").style.display = "none";
        document.getElementById("dif-info-output").innerHTML = "Attempts</h4> >> " + user_set_max_attempts + "<br> Award Multiplier >> " + trivia_reward_multiplier + " (" + trivia_reward_multiplier + " x cash total)" + "<br>Score >> " + user_set_score_award + " points";
        document.getElementById("dif-info-output-2").innerHTML = "";
        document.getElementById("selected-dif-output").innerHTML = "<span style='color: yellow'>SELECTED DIFFICULTY</span> : " + user_set_trivia_dif_txt;
        document.getElementById("dif-info-output").style.display = "flex";
        document.getElementById("dif-info-panel").style.display = "flex";
    }, 10)

    setTimeout( function() { // Changed alert to showNotification
        document.getElementById("start-trivia-btn").disabled = false;
    }, 1500)
}

// MEDIUM DOFFICULTY

document.getElementById('medium-dif').onclick = function() {
    setTimeout( function() {
        user_trivia_attempts -= 999;
        user_set_max_attempts = 2;
        user_trivia_attempts += user_set_max_attempts;
        trivia_reward_multiplier = def_medium_dif_multiplier;
        user_set_trivia_dif_txt = "MEDIUM";
        user_set_cash_award = 1.25;
        user_set_score_award = 2;
        easy_dif_active = false;
        medium_dif_active = true;
        hard_dif_active = false;
        timed_dif_active = false;
        match_active = true;
        enableAnswerRevelation();
        keyboardClickAudio();
        
        document.getElementById("timer-mod-btn").style.display = "none";
        document.getElementById("dif-info-output").innerHTML = "Attempts >> " + user_set_max_attempts + "<br>Award Multiplier >> " + trivia_reward_multiplier + " (" + trivia_reward_multiplier + " x cash total)" + "<br>Score >> " + user_set_score_award + " points";
        document.getElementById("dif-info-output-2").innerHTML = "";
        document.getElementById("selected-dif-output").innerHTML = "<span style='color: yellow'>SELECTED DIFFICULTY</span> : " + user_set_trivia_dif_txt;
        document.getElementById("dif-info-output").style.display = "flex";
        document.getElementById("dif-info-panel").style.display = "flex";
    }, 10)
    
    setTimeout( function() { // Changed alert to showNotification
        document.getElementById("start-trivia-btn").disabled = false;
    }, 1500)
}

// HARD DOFFICULTY

document.getElementById('hard-dif').onclick = function() {
    setTimeout( function() {
        user_trivia_attempts -= 999;
        user_set_max_attempts = 1;
        user_trivia_attempts += user_set_max_attempts;
        trivia_reward_multiplier = def_hard_dif_multiplier;
        user_set_trivia_dif_txt = "HARD";
        user_set_cash_award = 1.50;
        user_set_score_award = 2;
        user_set_trivia_dif = 1;
        easy_dif_active = false;
        medium_dif_active = false;
        hard_dif_active = true;
        timed_dif_active = false;
        match_active = true;
        disableAnswerRevelation();
        keyboardClickAudio();

        document.getElementById("timer-mod-btn").style.display = "none";
        document.getElementById("dif-info-output").innerHTML = "Attempts >> " + user_set_max_attempts + "<br>Award Multiplier >> " + trivia_reward_multiplier + " (" + trivia_reward_multiplier + " x cash total)" + "<br>Score >> " + user_set_score_award + " points";
        document.getElementById("dif-info-output-2").innerHTML = "";
        document.getElementById("selected-dif-output").innerHTML = "<span style='color: yellow'>SELECTED DIFFICULTY</span> : " + user_set_trivia_dif_txt;
        document.getElementById("dif-info-output").style.display = "flex";
        document.getElementById("dif-info-panel").style.display = "flex";
    }, 10)
    
    setTimeout( function() { // Changed alert to showNotification
        document.getElementById("start-trivia-btn").disabled = false;
    }, 1500)
}

// TIMED DIFFICULTY

document.getElementById('timed-dif').onclick = function() {
    setTimeout( function() {
        user_trivia_attempts -= 999;
        user_set_max_attempts = 1;
        user_trivia_attempts += user_set_max_attempts;
        trivia_reward_multiplier = def_timed_dif_multiplier;
        user_set_trivia_dif_txt = "TIMED";
        user_set_cash_award = 1.50;
        user_set_score_award = 2;
        user_set_trivia_dif = 4;
        easy_dif_active = false;
        medium_dif_active = false;
        hard_dif_active = false;
        timed_dif_active = true;
        match_active = true;
        disableAnswerRevelation();
        keyboardClickAudio();
        
        document.getElementById("timer-mod-btn").style.display = "block";
        document.getElementById("selected-dif-output").innerHTML = "<span style='color: yellow'>SELECTED DIFFICULTY</span> : " + user_set_trivia_dif_txt;
        document.getElementById("dif-info-output").innerHTML = "Attempts >> " + user_set_max_attempts + "<br>Award Multiplier >> " + trivia_reward_multiplier + " (" + trivia_reward_multiplier + " x cash total)" + "<br>Score >> " + user_set_score_award + " points";
        document.getElementById("dif-info-panel").style.display = "flex";
        document.getElementById("dif-info-output-2").innerHTML = "<h3 style='color: springgreen; font-size: 20px; font-weight: bold; font-family: monospace, Verdna, sans-serif;'># Time Per Question > " + timed_dif_question_timer_value / 1000 + " seconds to answer each question! <br style='margin-bottom: 5px;'># Each correct answer resets your timer!</h3>";
    }, 10)
    
    setTimeout( function() {
        document.getElementById("start-trivia-btn").disabled = false;
    }, 1500)
}

document.getElementById("timer-mod-btn").onclick = function() {
    if (timed_dif_active && player_lvl >= 5) {
        timed_dif_timer_mod_dialog_overlay.style.display = "flex";
        updateTimedStatsDisplay();
        keyboardClickAudio();
    } else {
        notificationDialog("LEVEL 5 REQUIRED FOR TIMER MODIFIERS!", 3000);
        upgradePurchaseFailedAudio();
    }
}

close_timed_dif_timer_mod_dialog_overlay_btn.onclick = function() {
    timed_dif_timer_mod_dialog_overlay.style.display = "none";
    timed_dif_question_timer_value = 30000;
    trivia_reward_multiplier = 1.5;
    timer_mod_inp.value = 30;
    keyboardClickAudio();
    updateTimedStatsDisplay();
}

accept_timed_dif_timer_mod_btn.onclick = function() {
    timed_dif_timer_mod_dialog_overlay.style.display = "none";
    modified_match = true;
    notificationDialog("Timer modified to " + input_value + " seconds!", 3000);
    keyboardClickAudio();
    upgradePurchasedAudio();
    updateTimedStatsDisplay();
}

function updateDifInfoDisplay() {
    document.getElementById("timer-mod-btn").style.display = "block";
    document.getElementById("dif-info-output").innerHTML = "# Attempts > " + user_set_max_attempts + "<br># Award Multiplier > " + trivia_reward_multiplier + " (" + trivia_reward_multiplier + " x your win). $" + formatMoneyValue(user_set_cash_award) + "<br># Score > " + user_set_score_award + " points";
    document.getElementById("selected-dif-output").innerHTML = "<span style='color: yellow'>SELECTED DIFFICULTY</span> : " + user_set_trivia_dif_txt;
}

function updateTimedStatsDisplay() {
    input_value = parseInt(document.getElementById("timer-mod-inp").value, 10);
    if (Number.isNaN(input_value)) {
        input_value = 20;
    }
    document.getElementById("dif-info-output-2").innerHTML = "<h3 style='color: springgreen; font-size: 20px; font-weight: bold;'># Time Per Question > " + timed_dif_question_timer_value / 1000 + " seconds to answer each question! <br style='margin-bottom: 5px;'># Each correct answer resets your timer!</h3>";document.getElementById("timed-cash-award-output").innerHTML = "<h3 style='color: springgreen;'>Cash Award (per correct answer) > $" + formatMoneyValue(user_set_cash_award) + "</h3>";
    document.getElementById("timed-multiplier-output").innerHTML = "<h3 style='color: yellow; font-size: 20px; font-weight: bold;'>Reward Multiplier > X" + trivia_reward_multiplier + "<span style='color: aquamarine;'> (+" + Math.round((trivia_reward_multiplier - 1) * 100) + "% Extra Cash)</span></h3>";
    document.getElementById("current-timer-value-output").innerHTML = "<h3 style='color: aquamarine; font-size: 20px; font-weight: bold;'>Current Timer > " + input_value + " seconds</h3>";
}

document.getElementById("timer-mod-inp").oninput = function() {
    input_value = parseInt(this.value, 10);

    accept_timed_dif_timer_mod_btn.disabled = false;
    accept_timed_dif_timer_mod_btn.style.opacity = "1";
    accept_timed_dif_timer_mod_btn.style.cursor = "pointer";

    switch (input_value) {
        case 40:
            timed_dif_question_timer_value = 40000;
            trivia_reward_multiplier = 1.1;
            user_set_cash_award = 1;
            user_set_score_award = 1;
            break;
        case 35:
            timed_dif_question_timer_value = 35000;
            trivia_reward_multiplier = 1.3;
            user_set_cash_award = 1.25;
            user_set_score_award = 1;
            break;
        case 30:
            timed_dif_question_timer_value = 30000;
            trivia_reward_multiplier = 1.5;
            user_set_cash_award = 1.50;
            user_set_score_award = 2;
            break;
        case 25:
            timed_dif_question_timer_value = 25000;
            trivia_reward_multiplier = 1.6;
            user_set_cash_award = 1.75;
            user_set_score_award = 2;
            break;
        case 20:
            timed_dif_question_timer_value = 20000;
            trivia_reward_multiplier = 1.8;
            user_set_cash_award = 2.00;
            user_set_score_award = 3;
            break;
        case 15:
            timed_dif_question_timer_value = 15000;
            trivia_reward_multiplier = 2;
            user_set_cash_award = 2.25;
            user_set_score_award = 3;
            break;
        case 10:
            timed_dif_question_timer_value = 10000;
            trivia_reward_multiplier = 2.5;
            user_set_cash_award = 2.50;
            user_set_score_award = 4;
            break;
        case 5:
            timed_dif_question_timer_value = 5000;
            trivia_reward_multiplier = 3.5;
            user_set_cash_award = 3.00;
            user_set_score_award = 3;
            break;
        default:
            timed_dif_question_timer_value = input_value * 1000;
            break;
    }
    updateDifInfoDisplay();
    updateTimedStatsDisplay();
}



updateTimedStatsDisplay();

document.getElementById('total-questions-output').innerHTML = "<h3 style='color: snow; font-family: Verdana, 'Courier New'>TOTAL AVAILABLE QUESTIONS : " + triviaQuestionsStorage.length + "</h3>";

function triviaTimed() {
    if (timed_dif_active) {
        timed_dif_question_timer = setInterval(() => {
            timed_dif_question_timer_value -= 1000;
            clockTickAudio();
            document.getElementById("timed-dif-timer-output").innerHTML = "TIME >> " + timed_dif_question_timer_value / 1000 + "<span style='text-transform: lowercase'>s</span>";
            if (timed_dif_question_timer_value === 0) {
                document.getElementById("timed-dif-timer-output").innerHTML = "TIME'S UP!";
                document.getElementById("clock-tick-sfx").muted = true;
                clearInterval(timed_dif_question_timer);
                timed_dif_question_timer_value = 30000;
                user_trivia_attempts = 0;
                timer_mod_inp.value = 30;
                setTimeout(() => { trivia_reward_multiplier = 0; }, 3000)
                modified_match = false;
                match_active = false;
                timed_dif_active = false;
                easy_dif_active = false;
                medium_dif_active = false;
                hard_dif_active = false;

                setTimeout( function() {
                    document.getElementById("next-question-btn").style.display = "block";
                    document.getElementById("question-panel").innerHTML = "";
                    document.getElementById("question-panel").style.display = "none";
                
                    for (let z = 0; z < incTriviaAnswersStorage.length; z++) {
                        incTriviaAnswersStorage[z].disabled = false;
                    }
                
                    for (let c = 0; c < corTriviaAnswersStorage.length; c++) {
                        corTriviaAnswersStorage[c].disabled = false;
                    }
                }, 1000)
            }
        }, 1000)
    }
}

function disableAnswerRevelation() {
    trivia_answer_reveal_tool.disabled = true;
    trivia_answer_reveal_tool.style.opacity = "0.5";
    trivia_answer_reveal_tool.style.cursor = "not-allowed";
    trivia_answer_reveal_tool.style.pointerEvents = "none";
}

function enableAnswerRevelation() {
    trivia_answer_reveal_tool.disabled = false;
    trivia_answer_reveal_tool.style.opacity = "1";
    trivia_answer_reveal_tool.style.cursor = "pointer";
    trivia_answer_reveal_tool.style.pointerEvents = "auto";
}

// TRVIA MATCH START

document.getElementById('start-trivia-btn').onclick = function() {
    if ((auto_next_question_trigger_preference.checked && hard_dif_active === true) || (auto_next_question_trigger_preference.checked && timed_dif_active === true)) {
        notificationDialog("Auto next question trigger is enabled. Please disable it to select this difficulty!", 4000);
        setTimeout(() => { 
            const confirmation = confirm("Click (Ok) to disable this setting or (Cancel).");

            if (confirmation) {
                auto_next_question_trigger_preference.click();
                auto_nect_question_trigger_preference_active = false;
            }
        }, 1500)
    } else {
        document.getElementById("start-trivia-btn").style.display = "none";
        document.getElementById("trivia-main-panel").style.display = "flex";
        document.getElementById("trivia-info-panel").style.display = "none";
        document.getElementById("trivia-stats").style.display = "flex";
        document.getElementById("trivia-score-output").style.display = "block";
        document.getElementById("trivia-tools-panel").style.display = "flex";
        document.getElementById("trivia-attempts-output").style.display = "block";
        document.getElementById("question-panel").style.display = "flex";
        document.getElementById("trivia-match-cash-total-output").style.display = "block";
        document.getElementById('reveal-answer').style.display = "block";
        document.getElementById("next-question-btn").style.display = "none";
        document.getElementById("trivia-title").style.display = "none";
        max_attempts = user_set_max_attempts;
        selection_attempts = 0;
        user_trivia_score = 0;
        user_trivia_match_cash_won_total = 0;
        match_active = true;
        triviaTimed();

        if (user_set_max_attempts > 0) {
            user_trivia_attempts = user_set_max_attempts;
        }

        if (hard_dif_active || timed_dif_active) {
            disableAnswerRevelation();
            setTimeout(() => {
                auto_next_question_trigger_preference.disabled = true;
                auto_next_question_trigger_preference.style.opacity = "0.5";
                auto_next_question_trigger_preference.style.cursor = "not-allowed";
            }, 1000)
            setTimeout(() => { notificationDialog("Answer revelation perk will be disabled for this difficulty. Good luck!", 6000); }, 1000);
        } else {
            enableAnswerRevelation();
        }

        if (timed_dif_active) {
            document.getElementById("clock-tick-sfx").muted = false;
            document.getElementById("timed-dif-timer-output").style.display = "block";
            document.getElementById("timed-dif-timer-output").innerHTML = "TIME >> " + timed_dif_question_timer_value / 1000 + "<span style='text-transform: lowercase'>s</span>";
        }
    
    setTimeout( function() {
        for (let ra = 0; ra < incTriviaAnswersStorage.length; ra++) {
            incTriviaAnswersStorage[ra].style.backgroundImage = "linear-gradient(black, black)";
            incTriviaAnswersStorage[ra].style.backgroundColor = "";
            incTriviaAnswersStorage[ra].style.display = "block";
            incTriviaAnswersStorage[ra].disabled = false;
        }
    }, 10)
    
    setTimeout( function() {
        for (let ca = 0; ca < corTriviaAnswersStorage.length; ca++) {
            corTriviaAnswersStorage[ca].style.backgroundImage = "linear-gradient(black, rgb(0, 0, 0))";
            corTriviaAnswersStorage[ca].style.backgroundColor = "";
            corTriviaAnswersStorage[ca].style.display = "block";
            corTriviaAnswersStorage[ca].disabled = false;
        }
    }, 10)
    
    const randomQuestion = triviaQuestionsStorage[Math.floor(Math.random() * triviaQuestionsStorage.length)];
    document.getElementById("question-panel").innerHTML = randomQuestion.innerHTML;

    function triviaAnsBtnReloader() {
        // INCORRECT ANSWER EVALUATIONS

        for (let x = 0; x < incTriviaAnswersStorage.length; x++) {
        incTriviaAnswersStorage[x].onclick = function() {
            incTriviaAnswersStorage[x].style.backgroundImage = "linear-gradient(black, darkred)";
            incTriviaAnswersStorage[x].disabled = true;
            selection_attempts += 1;
            user_trivia_attempts -= 1;
            max_attempts = user_set_max_attempts;
            total_incorrect_answers++;
            timed_dif_question_timer_value = 20000;
            document.getElementById("timed-dif-timer-output").innerHTML = "<span style='color: rgb(255, 106, 173);'>INCORRECT</span>";
            setTimeout(() => { document.getElementById("timed-dif-timer-output").innerHTML = "TIME >> " + timed_dif_question_timer_value / 1000 + "<span style='text-transform: lowercase'>s</span>"; }, 1500)
            clearInterval(timed_dif_question_timer);
            notificationDialog("INCORRECT ANSWER!", 3000);
            wrongAnswerAudio();
            
            if (selection_attempts == max_attempts) {
                document.getElementById("question-panel").innerHTML = "<h1>GAME OVER!</h1>";
                document.getElementById("next-question-btn").style.display = "none";
                document.getElementById("clock-tick-sfx").muted = true;
                
                setTimeout( function() {
                    document.getElementById("question-panel").innerHTML = "";
                    document.getElementById("difficulty-tab").style.display = "flex";
                    document.getElementById("dif-label").style.display = "block";
                    document.getElementById("dif-label-2").style.display = "block";
                    document.getElementById("question-panel").style.display = "none";
                    document.getElementById("trivia-tools-panel").style.display = "none";
                    document.getElementById("next-question-btn").style.display = "block";
                    //document.getElementById("trivia-stats").style.display = "none";
                    document.getElementById("trivia-match-cash-total-output").style.display = "none";
    
                    for (let z = 0; z < triviaDifBtnsStorage.length; z++) {
                        triviaDifBtnsStorage[z].disabled = true;
                        setTimeout( function() {
                            triviaDifBtnsStorage[z].disabled = false;
                        }, 2000)
                    }
                }, 1500)
            }
            
            setTimeout( function() {
                incTriviaAnswersStorage[x].style.backgroundImage = "linear-gradient(black, black)";
                incTriviaAnswersStorage[x].style.display = "none";
            }, 1000)
            
        }
    }

    // CORRECT ANSWER EVALUATIONS
    
    for (let x = 0; x < corTriviaAnswersStorage.length; x++) {
        corTriviaAnswersStorage[x].onclick = function() {
            corTriviaAnswersStorage[x].style.backgroundImage = "linear-gradient(black, darkgreen)";
            corTriviaAnswersStorage[x].disabled = true;
            user_trivia_score += user_set_score_award;
            user_trivia_match_cash_won_total += user_set_cash_award;
            total_correct_answers++;
            timed_dif_question_timer_value = input_value * 1000;
            document.getElementById("timed-dif-timer-output").innerHTML = "<span style='color: springgreen'>CORRECT</span>";
            setTimeout(() => { document.getElementById("timed-dif-timer-output").innerHTML = "TIME >> " + timed_dif_question_timer_value / 1000 + "<span style='text-transform: lowercase'>s</span>"; }, 1500)
            clearInterval(timed_dif_question_timer);
            document.getElementById("clock-tick-sfx").muted = true;
            addPlayerLvlXp(def_cor_ans_xp_grant * trivia_reward_multiplier);
            correctAnswerAudio();

            if (auto_next_question_trigger_preference_active) {
                setTimeout(() => { document.getElementById("next-question-btn").click(); }, 1100)
            }
            
            document.getElementById("trivia-match-cash-total-output").style.color = "lime";
            
            setTimeout( function() {
                document.getElementById("trivia-match-cash-total-output").style.color = "white";
            }, 1500)
            
            for (let z = 0; z < incTriviaAnswersStorage.length; z++) {
                incTriviaAnswersStorage[z].disabled = true;
            }
            
            setTimeout( function() {
                corTriviaAnswersStorage[x].style.backgroundColor = "";
                document.getElementById("next-question-btn").style.display = "block";
                document.getElementById("question-panel").innerHTML = "";
                document.getElementById("question-panel").style.display = "none";
                
                for (let z = 0; z < incTriviaAnswersStorage.length; z++) {
                    incTriviaAnswersStorage[z].disabled = false;
                }
                
                for (let c = 0; c < corTriviaAnswersStorage.length; c++) {
                    corTriviaAnswersStorage[c].disabled = false;
                }
            }, 1000)
        }
    }
        
    }
    setInterval( function() {
        triviaAnsBtnReloader();
    }, 500)
    }
}

document.getElementById('next-question-btn').onclick = function() {
    document.getElementById('next-question-btn').style.display = "none";
    document.getElementById('reveal-answer').style.display = "block";
    document.getElementById("question-panel").style.display = "flex";
    triviaTimed();

    if (timed_dif_active && !mute_trivia_clock_sfx_preference_active) { document.getElementById("clock-tick-sfx").muted = false; }
    
    setTimeout( function() {
        for (let b = 0; b < triviaToolsStorage.length; b++) {
            triviaToolsStorage[b].disabled = false;
        }
    }, 200)
    
    for (let ra = 0; ra < incTriviaAnswersStorage.length; ra++) {
        incTriviaAnswersStorage[ra].style.display = "block";
        incTriviaAnswersStorage[ra].disabled = false;
        incTriviaAnswersStorage[ra].style.opacity = "1";
        incTriviaAnswersStorage[ra].style.pointerEvents = "auto";
    }
    
    for (let ca = 0; ca < corTriviaAnswersStorage.length; ca++) {
        corTriviaAnswersStorage[ca].style.display = "block";
        corTriviaAnswersStorage[ca].disabled = false;
        corTriviaAnswersStorage[ca].style.opacity = "1";
        corTriviaAnswersStorage[ca].style.pointerEvents = "auto";
    }
    
    const randomQuestion = triviaQuestionsStorage[Math.floor(Math.random() * triviaQuestionsStorage.length)];
    document.getElementById("question-panel").innerHTML = randomQuestion.innerHTML;
    
    if (randomQuestion == null || 0) {
        const randomQuestion = triviaQuestionsStorage[Math.floor(Math.random() * triviaQuestionsStorage.length)];
        document.getElementById("question-panel").innerHTML = randomQuestion.innerHTML;
    }
}