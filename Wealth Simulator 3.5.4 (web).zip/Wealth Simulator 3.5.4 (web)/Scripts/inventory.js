let inventory_slot_1_player_owned_amount = 0; // X2 FARM INCOME
let inventory_slot_2_player_owned_amount = 0; // X3 FARM INCOME
let inventory_slot_3_player_owned_amount = 0; // X2 FARM SPEED
let inventory_slot_4_player_owned_amount = 0; // +50% more wilds
let inventory_slot_5_player_owned_amount = 0; // WILD BONUS
let inventory_slot_6_player_owned_amount = 0; // INSTANT XP
let inventory_slot_7_player_owned_amount = 0; // X2 LVL XP
let inventory_slot_8_player_owned_amount = 0; // X5 FARM SPEED
let inventory_slot_9_player_owned_amount = 0; // MYSTERY TOKENS
let inventory_slot_10_player_owned_amount = 0; // FREE SPINS BONUS
let inventory_slot_11_player_owned_amount = 0; // LAST LIFE
let inventory_slot_12_player_owned_amount = 0; // STREAK SAVER
let inventory_slot_13_player_owned_amount = 0; // FREE SPREE

let inventory_slot_1_booster_duration_int = 60000; // 1MIN
let inventory_slot_2_booster_duration_int = 60000; // 1MIN  
let inventory_slot_3_booster_duration_int = 60000; // 1MIN
let inventory_slot_4_booster_duration_int = 60000; // 1MIN
let inventory_slot_5_booster_duration_int = 0; // INSTANT
let inventory_slot_6_booster_duration_int = 0; // INSTANT
let inventory_slot_7_booster_duration_int = 300000; // 5MIN
let inventory_slot_8_booster_duration_int = 60000; // 1MIN
let inventory_slot_9_booster_duration_int = 0;
let inventory_slot_10_booster_duration_int = 0; // INSTANT
let inventory_slot_11_booster_duration_int = 0; // INSTANT
let inventory_slot_12_booster_duration_int = 0; // INSTANT
let inventory_slot_13_booster_duration_int = 30000; // 30s

let random_small_xp;

// INVENTORY SLOT USE OPTS

let inventory_slot_1_use_booster_opt = document.getElementById("inventory-slot-1-use-booster-btn");
let inventory_slot_2_use_booster_opt = document.getElementById("inventory-slot-2-use-booster-btn");
let inventory_slot_3_use_booster_opt = document.getElementById("inventory-slot-3-use-booster-btn");
let inventory_slot_4_use_booster_opt = document.getElementById("inventory-slot-4-use-booster-btn");
let inventory_slot_5_use_booster_opt = document.getElementById("inventory-slot-5-use-booster-btn");
let inventory_slot_6_use_booster_opt = document.getElementById("inventory-slot-6-use-booster-btn");
let inventory_slot_7_use_booster_opt = document.getElementById("inventory-slot-7-use-booster-btn");
let inventory_slot_8_use_booster_opt = document.getElementById("inventory-slot-8-use-booster-btn");
let inventory_slot_9_use_booster_opt = document.getElementById("inventory-slot-9-use-booster-btn");
let inventory_slot_10_use_booster_opt = document.getElementById("inventory-slot-10-use-booster-btn");
let inventory_slot_11_use_booster_opt = document.getElementById("inventory-slot-11-use-booster-btn");
let inventory_slot_12_use_booster_opt = document.getElementById("inventory-slot-12-use-booster-btn");
let inventory_slot_13_use_booster_opt = document.getElementById("inventory-slot-13-use-booster-btn");

// INVENTORY SLOT BOOSTER INFO OPTS

let inventory_slot_1_booster_info_opt = document.getElementById("inventory-slot-1-booster-info-btn");
let inventory_slot_2_booster_info_opt = document.getElementById("inventory-slot-2-booster-info-btn");
let inventory_slot_3_booster_info_opt = document.getElementById("inventory-slot-3-booster-info-btn");
let inventory_slot_4_booster_info_opt = document.getElementById("inventory-slot-4-booster-info-btn");
let inventory_slot_5_booster_info_opt = document.getElementById("inventory-slot-5-booster-info-btn");
let inventory_slot_6_booster_info_opt = document.getElementById("inventory-slot-6-booster-info-btn");
let inventory_slot_7_booster_info_opt = document.getElementById("inventory-slot-7-booster-info-btn");
let inventory_slot_8_booster_info_opt = document.getElementById("inventory-slot-8-booster-info-btn");
let inventory_slot_9_booster_info_opt = document.getElementById("inventory-slot-9-booster-info-btn");
let inventory_slot_10_booster_info_opt = document.getElementById("inventory-slot-10-booster-info-btn");
let inventory_slot_11_booster_info_opt = document.getElementById("inventory-slot-11-booster-info-btn");
let inventory_slot_12_booster_info_opt = document.getElementById("inventory-slot-12-booster-info-btn");
let inventory_slot_13_booster_info_opt = document.getElementById("inventory-slot-13-booster-info-btn");

let mystery_pick_opt_1 = document.getElementById("mystery-pick-1");
let mystery_pick_opt_2 = document.getElementById("mystery-pick-2");
let mystery_pick_opt_3 = document.getElementById("mystery-pick-3");

let mystery_picks = [mystery_pick_opt_1, mystery_pick_opt_2, mystery_pick_opt_3];

let mystery_pick_1_active = false;
let mystery_pick_2_active = false;
let mystery_pick_3_active = false;

let mystery_pick_1_revealed = false;
let mystery_pick_2_revealed = false;
let mystery_pick_3_revealed = false;

let random_common_cash_win_cap = 15;
let random_common_coin_win_cap = 10;

let random_uncommon_cash_win_cap = 30;
let random_uncommon_coin_win_cap = 25;

let random_rare_cash_win_cap = 60;
let random_rare_coin_win_cap = 50;

let random_epic_cash_win_cap = 100;
let random_epic_coin_win_cap = 100;

let random_legendary_cash_win_cap = 250;
let random_legendary_coin_win_cap = 200;

let random_ultra_cash_win_cap = 500;
let random_ultra_coin_win_cap = 300;

// WIN RNG CAPS

let common_rng_cap = 50; // 1 - 5
let uncommon_rng_cap = 20; // 1 - 20
let rare_rng_cap = 40; // 1 - 40
let epic_rng_cap = 70; // 1 - 70
let legendary_rng_cap = 120; // 1 - 120
let ultra_rng_cap = 200; // 1 - 200

let common_win_rng;
let uncommon_win_rng;
let rare_win_rng;
let epic_win_rng;
let legendary_win_rng;
let ultra_win_rng;

document.getElementById("close-mystery-booster-dialog-overlay-btn").onclick = function() {
    document.getElementById("mystery-booster-dialog-overlay").style.display = "none";
}

document.getElementById("use-mystery-booster-btn").onclick = function() {
    if (inventory_slot_9_player_owned_amount > 0) {
        document.getElementById("use-mystery-booster-btn").disabled = true; 
        document.getElementById("use-mystery-booster-btn").style.opacity = "0.5";
        document.getElementById("use-mystery-booster-btn").style.cursor = "not-allowed";
        notificationDialog("TOKEN USED!", 3000);
        inventory_slot_9_player_owned_amount--;
        resetMysteryPicks();
    } else {
        notificationDialog("TOKEN UNAVAILABLE!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { tokenUnavailableAudio(); }, 500);
        document.getElementById("use-mystery-booster-btn").disabled = false; 
        document.getElementById("use-mystery-booster-btn").style.opacity = "1";
        document.getElementById("use-mystery-booster-btn").style.cursor = "pointer";
    }
}

function mysteryWinPicker(mystery_pick, mystery_pick_2, mystery_pick_3) {
    common_win_rng = Math.floor(Math.random() * common_rng_cap) + 1; // 1 - 4
    uncommon_win_rng = Math.floor(Math.random() * uncommon_rng_cap) + 1; // 1 - 20
    rare_win_rng = Math.floor(Math.random() * rare_rng_cap) + 1; // 1 - 40
    epic_win_rng = Math.floor(Math.random() * epic_rng_cap) + 1; // 1 - 70
    legendary_win_rng = Math.floor(Math.random() * legendary_rng_cap) + 1; // 1 - 120
    ultra_win_rng = Math.floor(Math.random() * ultra_rng_cap) + 1; // 1 - 200

    let random_common_cash_win = Math.floor(Math.random() * random_common_cash_win_cap) + 1;
    let random_common_coin_win = Math.floor(Math.random() * random_common_coin_win_cap) + 1;

    let random_uncommon_cash_win = Math.floor(Math.random() * (random_uncommon_cash_win_cap - random_common_cash_win_cap)) + random_common_cash_win_cap + 1;
    let random_uncommon_coin_win = Math.floor(Math.random() * (random_uncommon_coin_win_cap - random_common_coin_win_cap)) + random_common_coin_win_cap + 1;

    let random_rare_cash_win = Math.floor(Math.random() * (random_rare_cash_win_cap - random_uncommon_cash_win_cap)) + random_uncommon_cash_win_cap + 1;
    let random_rare_coin_win = Math.floor(Math.random() * (random_rare_coin_win_cap - random_uncommon_coin_win_cap)) + random_uncommon_coin_win_cap + 1;

    let random_epic_cash_win = Math.floor(Math.random() * (random_epic_cash_win_cap - random_rare_cash_win_cap)) + random_rare_cash_win_cap + 1;
    let random_epic_coin_win = Math.floor(Math.random() * (random_epic_coin_win_cap - random_rare_coin_win_cap)) + random_rare_coin_win_cap + 1;

    let random_legendary_cash_win = Math.floor(Math.random() * (random_legendary_cash_win_cap - random_epic_cash_win_cap)) + random_epic_cash_win_cap + 1;
    let random_legendary_coin_win = Math.floor(Math.random() * (random_legendary_coin_win_cap - random_epic_coin_win_cap)) + random_epic_coin_win_cap + 1;

    let random_ultra_cash_win = Math.floor(Math.random() * (random_ultra_cash_win_cap - random_legendary_cash_win_cap)) + random_legendary_cash_win_cap + 1;
    let random_ultra_coin_win = Math.floor(Math.random() * (random_ultra_coin_win_cap - random_legendary_coin_win_cap)) + random_legendary_coin_win_cap + 1;

    setTimeout(() => {
        document.getElementById("use-mystery-booster-btn").disabled = false; 
        document.getElementById("use-mystery-booster-btn").style.opacity = "1";
        document.getElementById("use-mystery-booster-btn").style.cursor = "pointer";
    }, 3000)

    if (common_win_rng === 1) {  // CASH WIN (common)
        player_cash_balance += random_common_cash_win;
        notificationDialog("<span style='color: whitesmoke; margin-right: 5px;'>[COMMON WIN] " + "</span> $" + formatMoneyValue(random_common_cash_win) + " CREDITED TO YOUR BALANCE!", 4000);
        mysteryWinAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        mystery_pick.innerHTML = "<span style='color: snow'>COMMON<br>" + "$" + formatMoneyValue(random_common_cash_win) + "<img src='Images/Cash-balance-icon.png' width='100px;' height='100px' /><br></span>";
        mystery_pick.style.color = "whitesmoke";

    } else if (common_win_rng === 3) { // COIN WIN (common)
        player_coins_balance += random_common_coin_win;
        notificationDialog("<span style='color: whitesmoke; margin-right: 5px;'>[COMMON WIN] " + "</span>" + random_common_coin_win + " COINS CREDITED TO YOUR BALANCE!", 4000);
        mysteryWinAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        mystery_pick.innerHTML = "<span style='color: snow'>COMMON<br>" + random_common_coin_win + " Coins" + "<img src='Images/Tycoon-score-balance-icon.png' width='100px;' height='100px' /></span>";
        mystery_pick.style.color = "whitesmoke";

    } else if (uncommon_win_rng === 1) { // CASH WIN (uncommon)
        player_cash_balance += random_uncommon_cash_win;
        notificationDialog("<span style='color: lightgreen; margin-right: 5px;'>[UNCOMMON WIN] " + "</span> $" + formatMoneyValue(random_uncommon_cash_win) + " CREDITED TO YOUR BALANCE!", 4000);
        mysteryWinAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        mystery_pick.innerHTML = "<span style='color: lightgreen'>UNCOMMON<br>$" + formatMoneyValue(random_uncommon_cash_win) + "<img src='Images/Cash-balance-icon.png' width='100px;' height='100px' /></span>";
        mystery_pick.style.color = "lightgreen";

    } else if (uncommon_win_rng === 3) { // COIN WIN (uncommon)
        player_coins_balance += random_uncommon_coin_win;
        notificationDialog("<span style='color: lightgreen; margin-right: 5px;'>[UNCOMMON WIN] " + "</span>" + random_uncommon_coin_win + " COINS CREDITED TO YOUR BALANCE!", 4000);
        mysteryWinAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        mystery_pick.innerHTML = "<span style='color: lightgreen'>UNCOMMON<br>" + random_uncommon_coin_win + " Coins" + "<img src='Images/Tycoon-score-balance-icon.png' width='100px;' height='100px' /></span>";
        mystery_pick.style.color = "lightgreen";

    } else if (rare_win_rng === 1) { // DIAMOND WIN (rare)
        mystery_pick.innerHTML = "<span style='color: aquamarine'>RARE<br><img src='Images/Diamond-icon.png' width='200px;' height='190px' /></span>";
        notificationDialog("<span style='color: aquamarine; margin-right: 5px;'>[RARE WIN] " + "</span>" + "X1 DIAMOND CREDITED TO YOUR BALANCE!", 4000);
        mysteryWinAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        collectFarmAudio();
        player_diamond_balance++;

    } else if (rare_win_rng === 3) { // CASH WIN (rare)
        player_cash_balance += random_rare_cash_win;
        notificationDialog("<span style='color: aquamarine; margin-right: 5px;'>[RARE WIN] " + "</span> $" + formatMoneyValue(random_rare_cash_win) + " CREDITED TO YOUR BALANCE!", 4000);
        mysteryWinAudio();     
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        mystery_pick.innerHTML = "<span style='color: aquamarine'>RARE<br>$" + formatMoneyValue(random_rare_cash_win) + "<img src='Images/Cash-balance-icon.png' width='100px;' height='100px' /></span>";
        mystery_pick.style.color = "aquamarine";

    } else if (rare_win_rng === 5) { // COIN WIN (rare)
        player_coins_balance += random_rare_coin_win;
        notificationDialog("<span style='color: aquamarine; margin-right: 5px;'>[RARE WIN] " + "</span>" + random_rare_coin_win + " COINS CREDITED TO YOUR BALANCE!", 4000);
        mysteryWinAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        mystery_pick.innerHTML = "<span style='color: aquamarine'>RARE<br>" + random_rare_coin_win + " Coins" + "<img src='Images/Tycoon-score-balance-icon.png' width='100px;' height='100px' /></span>";
        mystery_pick.style.color = "aquamarine";

    } else if (rare_win_rng === 10) { // WILD FREE SPINS WIN (rare)
        mystery_pick.innerHTML = "<span style='color: aquamarine'>RARE<br>WILD FREE SPINS" + "<img src='Images/wild-bonus-symbol.svg' width='100px;' height='100px' style='margin-top: 6px' /></span>";
        mystery_pick.style.color = "aquamarine";
        mysteryWinAudio();
        setTimeout(() => { resetMysteryPicks(); }, 3000);
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        setTimeout(() => {
            let confirmation = confirm("You have [WILD FREE SPINS] available! Would you like to use it now? Click (Cancel) to add it to your inventory.");
            if (confirmation) {
                setTimeout(() => { inventory_slot_5_player_owned_amount++; inventory_slot_5_use_booster_opt.click(); }, 1000);

                enableMysteryPicks();
                resetMysteryPicks();
                setTimeout(() => { document.getElementById("mystery-booster-dialog-overlay").style.display = "none"; }, 1000)
                inventory_slot_5_player_owned_amount++;
                inventory_slot_5_player_owned_amount--;
            } else {
                inventory_slot_5_player_owned_amount++;
                notificationDialog("WILD SPINS BONUS ADDED TO YOUR INVENTORY!", 3000);
            }
        }, 3000);

    } else if (epic_win_rng === 1) { // RANDOM BOOSTER WIN (epic)
        let random_booster_win_rng = Math.floor(Math.random() * 15) + 1; // 1 - 30

        if (random_booster_win_rng === 5) { // X2 FARM INCOME BOOSTER WIN
            inventory_slot_1_player_owned_amount++;
            bonusWinAudio();
            notificationDialog("<span style='color: rgb(255, 40, 255); margin-right: 5px;'>[EPIC WIN] </span>" + "X1 DOUBLE FARM INCOME BOOSTER", 4000);
            mysteryWinAudio();
            setTimeout(() => { disableMysteryPicks(); }, 3000);
            mystery_pick.innerHTML = "<img src='Images/x2-income.svg' width='200px;' height='200px' />";
        } else if (random_booster_win_rng === 10) { // X3 FARM INCOME BOOSTER WIN
            inventory_slot_2_player_owned_amount++;
            bonusWinAudio();
            notificationDialog("<span style='color: rgb(255, 40, 255); margin-right: 5px;'>[EPIC WIN] </span>" + "X1 TRIPLE FARM INCOME BOOSTER", 4000);
            mysteryWinAudio();
            setTimeout(() => { disableMysteryPicks(); }, 3000);
            mystery_pick.innerHTML = "<span style='color: rgb(255, 40, 255)'>EPIC<br><img src='Images/x3-income.svg' width='200px;' height='200px' /></span>";
        } else if (random_booster_win_rng === 15) { // INSTANT XP BOOSTER WIN
            inventory_slot_6_player_owned_amount++;
            bonusWinAudio();
            notificationDialog("<span style='color: rgb(255, 40, 255); margin-right: 5px;'>[EPIC WIN] </span>" + "X1 INSTANT XP BOOSTER", 4000);
            setTimeout(() => { disableMysteryPicks(); }, 3000);
            mystery_pick.innerHTML = "<span style='color: rgb(255, 40, 255)'>EPIC<br><img src='Images/instant-level-up-booster.svg' width='200px;' height='200px' /></span>";
        }

    } else if (epic_win_rng === 3) { // CASH WIN (epic)
        player_cash_balance += random_epic_cash_win;
        notificationDialog("<span style='color: rgb(255, 40, 255); margin-right: 5px;'>[EPIC WIN] </span>" + "$" + formatMoneyValue(random_epic_cash_win) + " CREDITED TO YOUR BALANCE!", 4000);
        mysteryWinAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        mystery_pick.innerHTML = "<span style='color: rgb(255, 40, 255)'>EPIC<br>$" + formatMoneyValue(random_epic_cash_win) + "<img src='Images/Cash-balance-icon.png' width='100px;' height='100px' /></span>";
        mystery_pick.style.color = "rgb(255, 40, 255)";

    } else if (epic_win_rng === 5) { // COIN WIN (epic)
        player_coins_balance += random_epic_coin_win;
        notificationDialog("<span style='color: rgb(255, 40, 255); margin-right: 5px;'>[EPIC WIN] </span>" + random_epic_coin_win + " COINS CREDITED TO YOUR BALANCE!", 4000);
        mysteryWinAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        mystery_pick.innerHTML = "<span style='color: rgb(255, 40, 255)'>EPIC<br>" + random_epic_coin_win + " COINS<img src='Images/Tycoon-score-balance-icon.png' width='100px;' height='100px' /></span>";
        mystery_pick.style.color = "rgb(255, 40, 255)";

    } else if (epic_win_rng === 10) { // FREE SPINS WIN (epic)
        mystery_pick.innerHTML = "<span style='color: rgb(255, 40, 255)'>EPIC<br>FREE SPINS" + "<img src='Images/free-spins.svg' width='100px;' height='100px' style='margin-top: 6px' /></span>";
        mystery_pick.style.color = "rgb(255, 40, 255)";
        mysteryWinAudio();
        setTimeout(() => { resetMysteryPicks(); }, 3000);
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        setTimeout(() => {
            let confirmation = confirm("You have [FREE SPINS] available! Would you like to use it now? Click (Cancel) to add it to your inventory.");
            if (confirmation) {
                setTimeout(() => { inventory_slot_10_player_owned_amount++; inventory_slot_10_use_booster_opt.click(); }, 1000);

                enableMysteryPicks();
                resetMysteryPicks();
                setTimeout(() => { document.getElementById("mystery-booster-dialog-overlay").style.display = "none"; }, 1000)
                inventory_slot_10_player_owned_amount++;
                inventory_slot_10_player_owned_amount--;
            } else {
                inventory_slot_10_player_owned_amount++;
                notificationDialog("FREE SPINS BONUS ADDED TO YOUR INVENTORY!", 3000);
            }
        }, 3000);

    } else if (epic_win_rng === 15) { // MYSTERY TOKEN WIN (epic)
        notificationDialog("<span style='color: rgb(244, 0, 232); margin-right: 5px;'>[EPIC WIN] X5 MYSTERY TOKENS</span>" + " ADDED TO INVENTORY!", 4000);
        mysteryWinAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        mystery_pick.innerHTML = "<span style='color: rgb(244, 0, 232)'>EPIC<br>X5" + "<img src='Images/mystery-booster.svg' width='100px;' height='100px' /></span>";
        mystery_pick.style.color = "rgb(255, 183, 40)";
        inventory_slot_9_player_owned_amount += 5;
    } else if (legendary_win_rng === 3) { // CASH WIN (legendary)
        player_cash_balance += random_legendary_cash_win;
        notificationDialog("<span style='color: rgb(255, 183, 40); margin-right: 5px;'>[LEGENDARY WIN] </span>" + "$" + formatMoneyValue(random_legendary_cash_win) + " CREDITED TO YOUR BALANCE!", 4000);
        mysteryWinAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        mystery_pick.innerHTML = "<span style='color: rgb(255, 183, 40)'>LEGENDARY<br>$" + formatMoneyValue(random_legendary_cash_win) + "<img src='Images/Cash-balance-icon.png' width='100px;' height='100px' /></span>";
        mystery_pick.style.color = "rgb(255, 183, 40)";
    } else if (legendary_win_rng === 5) { // COIN WIN (legendary)
        player_coins_balance += random_legendary_coin_win;
        notificationDialog("<span style='color: rgb(255, 183, 40); margin-right: 5px;'>[LEGENDARY WIN] </span>" + random_legendary_coin_win + " COINS CREDITED TO YOUR BALANCE!", 4000);
        mysteryWinAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        mystery_pick.innerHTML = "<span style='color: rgb(255, 183, 40)'>LEGENDARY<br>" + random_legendary_coin_win + " COINS" + "<img src='Images/Tycoon-score-balance-icon.png' width='100px;' height='100px' /></span>";
        mystery_pick.style.color = "rgb(255, 183, 40)";
    } else if (legendary_win_rng === 10) { // MYSTERY TOKEN WIN (legendary)
        notificationDialog("<span style='color: rgb(255, 183, 40); margin-right: 5px;'>[LEGENDARY WIN]</span>" + " X10 MYSTERY TOKENS ADDED TO INVENTORY!", 4000);
        mysteryWinAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        mystery_pick.innerHTML = "<span style='color: rgb(255, 183, 40)'>LEGENDARY<br>X10" + "<img src='Images/mystery-booster.svg' width='100px;' height='100px' /></span>";
        mystery_pick.style.color = "rgb(255, 183, 40)";
        inventory_slot_9_player_owned_amount += 10;
    } else if (ultra_win_rng === 1) { // CASH WIN (ultra)
        player_cash_balance += random_ultra_cash_win;
        notificationDialog("<span style='color: rgb(200, 255, 61); margin-right: 5px;'>[ULTRA WIN] </span>" + "$" + formatMoneyValue(random_ultra_cash_win) + " CREDITED TO YOUR BALANCE!", 4000);
        mysteryWinAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        mystery_pick.innerHTML = "<span style='color: rgb(200, 255, 61)'>ULTRA<br>$" + formatMoneyValue(random_ultra_cash_win) + "<img src='Images/Cash-balance-icon.png' width='100px;' height='100px' /></span>";
        mystery_pick.style.color = "rgb(200, 255, 6)";
    } else if (ultra_win_rng === 3) { // COIN WIN (ultra)
        player_coins_balance += random_ultra_coin_win;
        notificationDialog("<span style='color: rgb(200, 255, 61); margin-right: 5px;'>[ULTRA WIN] </span>" + random_ultra_coin_win + " CREDITED TO YOUR BALANCE!", 4000);
        mysteryWinAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        mystery_pick.innerHTML = "<span style='color: rgb(200, 255, 61)'>ULTRA<br>" + random_legendary_coin_win + " COINS" + "<img src='Images/Tycoon-score-balance-icon.png' width='100px;' height='100px' /></span>";
        mystery_pick.style.color = "rgb(200, 255, 61)";
    } else { // NO WIN

        notificationDialog("You didn't win anything this time!", 4000);
        setTimeout(() => { mystery_pick.innerHTML = "<img src='Images/no-win.png' width='200px;' height='200px' />"; }, 500)
        upgradePurchaseFailedAudio();
        setTimeout(() => { disableMysteryPicks(); }, 3000);
        resetMysteryPicks();
    }
}

function disableMysteryPicks() {
    mystery_pick_opt_1.disabled = true;
    mystery_pick_opt_1.style.opacity = "0.5";
    mystery_pick_opt_1.style.cursor = "not-allowed";
    mystery_pick_opt_2.disabled = true;
    mystery_pick_opt_2.style.opacity = "0.5";
    mystery_pick_opt_2.style.cursor = "not-allowed";
    mystery_pick_opt_3.disabled = true;
    mystery_pick_opt_3.style.opacity = "0.5";
    mystery_pick_opt_3.style.cursor = "not-allowed";
}


function enableMysteryPicks() {
    mystery_pick_opt_1.disabled = false;
    mystery_pick_opt_1.style.opacity = "1";
    mystery_pick_opt_1.style.cursor = "pointer";
    mystery_pick_opt_2.disabled = false;
    mystery_pick_opt_2.style.opacity = "1";
    mystery_pick_opt_2.style.cursor = "pointer";
    mystery_pick_opt_3.disabled = false;
    mystery_pick_opt_3.style.opacity = "1";
    mystery_pick_opt_3.style.cursor = "pointer";
}

function resetMysteryPicks() {
    enableMysteryPicks();

    mystery_pick_opt_1.innerHTML = "<img src='Images/mystery-icons.svg' width='280px' height='280px' />";
    mystery_pick_opt_2.innerHTML = "<img src='Images/mystery-icons.svg' width='280px' height='280px' />";
    mystery_pick_opt_3.innerHTML = "<img src='Images/mystery-icons.svg' width='280px' height='280px' />";
}

mystery_pick_opt_1.onclick = function() { 
    mystery_pick_1_active = true;  
    mysteryWinPicker(mystery_pick_opt_1, mystery_pick_opt_2, mystery_pick_opt_3); 
    keyboardClickAudio();
    disableMysteryPicks();
    setTimeout(() => { mystery_pick_opt_1.style.opacity = "1"; mystery_pick_opt_1.style.cursor = "pointer";}, 500)
}

mystery_pick_opt_2.onclick = function() { 
    mystery_pick_2_active = true; 
    mysteryWinPicker(mystery_pick_opt_2);
    disableMysteryPicks();
    keyboardClickAudio();
    setTimeout(() => { mystery_pick_opt_2.style.opacity = "1"; mystery_pick_opt_2.style.cursor = "pointer"; }, 500)
}

mystery_pick_opt_3.onclick = function() { 
    mystery_pick_3_active = true;
    mysteryWinPicker(mystery_pick_opt_3); 
    keyboardClickAudio();
    disableMysteryPicks();
    setTimeout(() => { mystery_pick_opt_3.style.opacity = "1"; mystery_pick_opt_3.style.cursor = "pointer"; }, 500)
}

document.getElementById("close-booster-info-dialog-overlay-btn").onclick = function() {
    document.getElementById("booster-info-dialog-overlay").style.display = "none";
}

// X2 FARM INCOME BOOSTER

inventory_slot_1_use_booster_opt.onclick = function() {
    keyboardClickAudio();
    useInventoryBooster(1, inventory_slot_1_use_booster_opt, 2, inventory_slot_1_booster_duration_int, "X2 FARM INCOME APPLIED!", "X2 FARM INCOME EXPIRED!");
}

// X3 FARM INCOME BOOSTER

inventory_slot_2_use_booster_opt.onclick = function() {
    keyboardClickAudio();
    useInventoryBooster(2, inventory_slot_2_use_booster_opt, 3, inventory_slot_2_booster_duration_int, "X3 FARM INCOME APPLIED!", "X3 FARM INCOME EXPIRED!");
}

// X2 FARM SPEED BOOSTER

inventory_slot_3_use_booster_opt.onclick = function() {
    keyboardClickAudio();
    if (inventory_slot_3_player_owned_amount > 0) {
        inventory_slot_3_player_owned_amount--;
        inventory_slot_3_use_booster_opt.disabled = true;
        inventory_slot_3_use_booster_opt.style.opacity = "0.5";
        inventory_slot_3_use_booster_opt.style.cursor = "not-allowed";
        inventory_slot_8_use_booster_opt.disabled = true;
        inventory_slot_8_use_booster_opt.style.opacity = "0.5";
        inventory_slot_8_use_booster_opt.style.cursor = "not-allowed";
        let extra_farm_progress_int = setInterval(() => {
            increaseProgressBar(farm_1_progress_bar, 1);
            increaseProgressBar(farm_2_progress_bar, 1);
            increaseProgressBar(farm_3_progress_bar, 1);
            increaseProgressBar(farm_4_progress_bar, 1);
            increaseProgressBar(farm_5_progress_bar, 1);
            increaseProgressBar(farm_6_progress_bar, 1);
            
            if (tier_2_farm_unlocked) {
                increaseProgressBar(tier_2_farm_1_progress_bar, 1);
                increaseProgressBar(tier_2_farm_2_progress_bar, 1);
                increaseProgressBar(tier_2_farm_3_progress_bar, 1);
                increaseProgressBar(tier_2_farm_4_progress_bar, 1);
                increaseProgressBar(tier_2_farm_5_progress_bar, 1);
                increaseProgressBar(tier_2_farm_6_progress_bar, 1);
            }

            if (tier_3_farm_unlocked) {
                increaseProgressBar(tier_3_farm_1_progress_bar, 1);
                increaseProgressBar(tier_3_farm_2_progress_bar, 1);
                increaseProgressBar(tier_3_farm_3_progress_bar, 1);
                increaseProgressBar(tier_3_farm_4_progress_bar, 1);
                increaseProgressBar(tier_3_farm_5_progress_bar, 1);
                increaseProgressBar(tier_3_farm_6_progress_bar, 1);
            }

        }, 1000)
        let extra_farm_progress_expiry_int = setTimeout(() => {
            clearInterval(extra_farm_progress_int);
            inventory_slot_3_use_booster_opt.disabled = false;
            inventory_slot_3_use_booster_opt.style.opacity = "1";
            inventory_slot_3_use_booster_opt.style.cursor = "pointer";
            inventory_slot_8_use_booster_opt.disabled = false;
            inventory_slot_8_use_booster_opt.style.opacity = "1";
            inventory_slot_8_use_booster_opt.style.cursor = "pointer";
            notificationDialog("X2 FARM SPEED EXPIRED!", 3500);
        }, inventory_slot_3_booster_duration_int)
        notificationDialog("X2 FARM SPEED APPLIED!", 3500);
        upgradePurchasedAudio();
    } else {
        notificationDialog("NO BOOSTER AVAILABLE!", 3000);
        setTimeout(() => { notificationDialog("Purchaseable in the store!" , 3000); }, 3000);
        setTimeout(() => { boosterUnavailableAudio(); }, 500);
        upgradePurchaseFailedAudio();
    }
}

// 30% EXTRA WILDS BOOSTER

inventory_slot_4_use_booster_opt.onclick = function() {
    keyboardClickAudio();
    if (inventory_slot_4_player_owned_amount > 0) {
        inventory_slot_4_player_owned_amount--;
        wild_win_probability -= 10;
        inventory_slot_4_use_booster_opt.disabled = true;
        inventory_slot_4_use_booster_opt.style.cursor = "not-allowed";
        inventory_slot_4_use_booster_opt.style.opacity = "0.5";
        setTimeout(() => { gambling_hub_menu_opt_btn.click(); }, 1000)
        setTimeout(() => { 
            wild_win_probability += 10; 
            inventory_slot_4_use_booster_opt.disabled = false;
            inventory_slot_4_use_booster_opt.style.cursor = "pointer";
            inventory_slot_4_use_booster_opt.style.opacity = "1";
        }, inventory_slot_4_booster_duration_int);
        upgradePurchasedAudio();
        notificationDialog("[Applied] +50% more wilds!", 3500);
    } else {
        upgradePurchaseFailedAudio();
        notificationDialog("NO BOOSTER AVAILABLE!", 3000);
        setTimeout(() => { boosterUnavailableAudio(); }, 500);
    }
}

// WILD BONUS BOOSTER

inventory_slot_5_use_booster_opt.onclick = function() {
    keyboardClickAudio();
    bonusWinAudio();
    if (inventory_slot_5_player_owned_amount > 0) {
        inventory_slot_5_use_booster_opt.disabled = true;
        inventory_slot_5_use_booster_opt.style.opacity = "0.5";
        inventory_slot_5_use_booster_opt.style.cursor = "not-allowed";
        inventory_slot_5_player_owned_amount--;
        total_wild_bonus_won_counter++;
        wild_bonus_free_spins_granted = 10;
        bet = Math.round(Math.floor(Math.random() * 5) + 1);
        document.getElementById("3-reel-slot-opt").click();
        setTimeout(() => {
            document.getElementById("wild-bonus-start-dialog-overlay").style.display = "flex";
        }, 1500)
        security_control_disable_int = setInterval(() => { disableGamblingControls(); }, 100)
        stop_auto_spin_btn.click();
        document.getElementById("gambling-hub-ui").style.display = "flex";
        document.getElementById("gambling-hub-ui-2").style.display = "none";
        setTimeout(() => { document.getElementById("slot-selection-dialog-overlay").style.display = "none"; }, 1000)
    } else {
        notificationDialog("NO BOOSTER AVAILABLE!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { boosterUnavailableAudio(); }, 500);
    }
}

// FREE SPINS BOOSTER

inventory_slot_10_use_booster_opt.onclick = function() {
    keyboardClickAudio();
    if (inventory_slot_10_player_owned_amount > 0) {
        inventory_slot_10_use_booster_opt.disabled = true;
        inventory_slot_10_use_booster_opt.style.opacity = "0.5";
        inventory_slot_10_use_booster_opt.style.cursor = "not-allowed";
        inventory_slot_10_player_owned_amount--;
        document.getElementById("15-reel-slot-opt").click();
        disableGamblingControls2();
        setTimeout(() => {
            setTimeout(() => { document.getElementById("free-spins-bonus-start-dialog-overlay").style.display = "flex"; }, 2500)
            
            for (let i = 0; i < final_multi_slot_id_storage_center_reels.length; i++) { final_multi_slot_id_storage_center_reels[i].src = "Images/free-spins.svg"; }
            for (let i = 0; i < final_multi_slot_id_storage_surrounding_reels.length; i++) { final_multi_slot_id_storage_surrounding_reels[i].src = "Images/Placeholder-2.png"; }

            notificationDialog("FREE SPINS BONUS ACTIVATED!", 3000);
            terminateAutoSpin2();
            bonusWinAudio();
            free_spins_won_counter++;
            free_spins_bonus_spins = 0;
            free_spins_granted = 10;
            bet_2 = Math.round(Math.floor(Math.random() * 5) + 1);
        }, 1000)
    } else {
        notificationDialog("NO BOOSTER AVAILABLE!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { boosterUnavailableAudio(); }, 500);
    }
}

// INSTANT XP BOOSTER

function addIntantXp() { addPlayerLvlXp(random_small_xp); upgradePurchasedAudio(); notificationDialog(random_small_xp + "XP credited!", 3000); }

inventory_slot_6_use_booster_opt.onclick = function() {
    keyboardClickAudio();
    if (inventory_slot_6_player_owned_amount > 0) {
        inventory_slot_6_player_owned_amount--;
        random_small_xp = Math.floor(Math.random() * 200);
        if (random_small_xp < 50) {
            random_small_xp += 50;
            setTimeout(() => { addIntantXp(); }, 1000)
        } else if (random_small_xp < 75) {
            random_small_xp += 25;
            setTimeout(() => { addIntantXp(); }, 1000)
        } else if (random_small_xp >= 50) {
            setTimeout(() => { addIntantXp(); }, 1000)
        } else {
            setTimeout(() => { boosterUnavailableAudio(); }, 500);
        }
    }
}

inventory_slot_7_use_booster_opt.onclick = function() {
    keyboardClickAudio();
    if (inventory_slot_7_player_owned_amount > 0) {
        inventory_slot_7_player_owned_amount--;
        inventory_slot_7_use_booster_opt.disabled = true;
        inventory_slot_7_use_booster_opt.style.opacity = "0.5";
        inventory_slot_7_use_booster_opt.style.cursor = "not-allowed";
        notificationDialog("Double XP active!", 3000);
        setTimeout(() => { double_xp_active = true; }, 500)
        setTimeout(() => {
            double_xp_active = false;
            inventory_slot_7_use_booster_opt.disabled = false;
            inventory_slot_7_use_booster_opt.style.opacity = "1";
            inventory_slot_7_use_booster_opt.style.cursor = "pointer";
            notificationDialog("X2 LVL XP EXPIRED!", 3500);
        }, inventory_slot_7_booster_duration_int)
    } else {
        notificationDialog("NO BOOSTER AVAILABLE!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { boosterUnavailableAudio(); }, 500);
    }
}

// X5 FARM SPEED BOOSTER

inventory_slot_8_use_booster_opt.onclick = function() {
    keyboardClickAudio();
    if (inventory_slot_8_player_owned_amount > 0) {
        inventory_slot_8_player_owned_amount--;
        inventory_slot_8_use_booster_opt.disabled = true;
        inventory_slot_8_use_booster_opt.style.opacity = "0.5";
        inventory_slot_8_use_booster_opt.style.cursor = "not-allowed";
        inventory_slot_3_use_booster_opt.disabled = true;
        inventory_slot_3_use_booster_opt.style.opacity = "0.5";
        inventory_slot_3_use_booster_opt.style.cursor = "not-allowed";
        let extra_farm_progress_int = setInterval(() => {
            increaseProgressBar(farm_1_progress_bar, 4);
            increaseProgressBar(farm_2_progress_bar, 4);
            increaseProgressBar(farm_3_progress_bar, 4);
            increaseProgressBar(farm_4_progress_bar, 4);
            increaseProgressBar(farm_5_progress_bar, 4);
            increaseProgressBar(farm_6_progress_bar, 4);
            
            if (tier_2_farm_unlocked) {
                increaseProgressBar(tier_2_farm_1_progress_bar, 4);
                increaseProgressBar(tier_2_farm_2_progress_bar, 4);
                increaseProgressBar(tier_2_farm_3_progress_bar, 4);
                increaseProgressBar(tier_2_farm_4_progress_bar, 4);
                increaseProgressBar(tier_2_farm_5_progress_bar, 4);
                increaseProgressBar(tier_2_farm_6_progress_bar, 4);
            }

            if (tier_3_farm_unlocked) {
                increaseProgressBar(tier_3_farm_1_progress_bar, 4);
                increaseProgressBar(tier_3_farm_2_progress_bar, 4);
                increaseProgressBar(tier_3_farm_3_progress_bar, 4);
                increaseProgressBar(tier_3_farm_4_progress_bar, 4);
                increaseProgressBar(tier_3_farm_5_progress_bar, 4);
                increaseProgressBar(tier_3_farm_6_progress_bar, 4);
            }
        }, 1000)
        let extra_farm_progress_expiry_int = setTimeout(() => {
            clearInterval(extra_farm_progress_int);
            inventory_slot_8_use_booster_opt.disabled = false;
            inventory_slot_8_use_booster_opt.style.opacity = "1";
            inventory_slot_8_use_booster_opt.style.cursor = "pointer";
            inventory_slot_3_use_booster_opt.disabled = false;
            inventory_slot_3_use_booster_opt.style.opacity = "1";
            inventory_slot_3_use_booster_opt.style.cursor = "pointer";
            notificationDialog("X5 FARM SPEED EXPIRED!", 3500);
        }, inventory_slot_8_booster_duration_int)
        notificationDialog("X5 FARM SPEED APPLIED!", 3500);
        upgradePurchasedAudio();
    } else {
        notificationDialog("NO BOOSTER AVAILABLE!", 3000);
        setTimeout(() => { notificationDialog("Purchaseable in the store!" , 3000); }, 3000)
        upgradePurchaseFailedAudio();
        setTimeout(() => { boosterUnavailableAudio(); }, 500);
    }
}

// MYSTERY TOKENS

inventory_slot_9_use_booster_opt.onclick = function() {
    document.getElementById("mystery-booster-dialog-overlay").style.display = "flex";
}

inventory_slot_11_use_booster_opt.onclick = function() {
    keyboardClickAudio();
    if (inventory_slot_11_player_owned_amount > 0) {
        inventory_slot_11_player_owned_amount--;
        inventory_slot_11_use_booster_opt.disabled = true;
        inventory_slot_11_use_booster_opt.style.opacity = "0.5";
        inventory_slot_11_use_booster_opt.style.cursor = "not-allowed";
        user_trivia_attempts++;
        upgradePurchasedAudio();
        notificationDialog("X1 ATTEMPT CREDITED!", 3000);
    } else {
        notificationDialog("NO BOOSTER AVAILABLE!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { boosterUnavailableAudio(); }, 500);
    }
}

inventory_slot_12_use_booster_opt.onclick = function() {
    keyboardClickAudio();
    if (inventory_slot_12_player_owned_amount > 0) {
        inventory_slot_12_player_owned_amount--;
        keyboardClickAudio();
        matchWin();
    } else {
        notificationDialog("NO BOOSTER AVAILABLE!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { boosterUnavailableAudio(); }, 500);
    }    
}

inventory_slot_13_use_booster_opt.onclick = function() {
    keyboardClickAudio();
    if (inventory_slot_13_player_owned_amount > 0) {
        inventory_slot_13_player_owned_amount--;
        price = 0;
        setTimeout(() => { match_boards_opt.click(); }, 1000);
        setTimeout(function () { price = 5;}, 30000);
        keyboardClickAudio();
    } else {
        notificationDialog("NO BOOSTER AVAILABLE!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { boosterUnavailableAudio(); }, 500);
    }
}

// INVENTORY SLOT BOOSTER INFO DISPLAYS

inventory_slot_1_booster_info_opt.onclick = function() {
    keyboardClickAudio();
    document.getElementById("booster-info-dialog-overlay").style.display = "flex";
    document.getElementById("booster-info-output").innerHTML = "X2 FARM INCOME BOOSTER<br><br>Duration: 1MIN<br>Effect: Doubles the amount of farm income earned for 1 minute.";
}

inventory_slot_2_booster_info_opt.onclick = function() {
    keyboardClickAudio();
    document.getElementById("booster-info-dialog-overlay").style.display = "flex";
    document.getElementById("booster-info-output").innerHTML = "X3 FARM INCOME BOOSTER<br><br>Duration: 1MIN<br>Effect: Triples the amount of farm income earned for 1 minute.";
}

inventory_slot_3_booster_info_opt.onclick = function() {
    keyboardClickAudio();
    document.getElementById("booster-info-dialog-overlay").style.display = "flex";
    document.getElementById("booster-info-output").innerHTML = "X2 FARM SPEED BOOSTER<br><br>Duration: 1MIN<br>Effect: Doubles the speed of farm progress for 1 minute.";
}

inventory_slot_4_booster_info_opt.onclick = function() {
    keyboardClickAudio();
    document.getElementById("booster-info-dialog-overlay").style.display = "flex";
    document.getElementById("booster-info-output").innerHTML = "+50% MORE WILDS BOOSTER<br><br>Duration: 45SEC<br>Effect: Increases the chance of landing wilds by 50% for 45 seconds.";
}

inventory_slot_5_booster_info_opt.onclick = function() {
    keyboardClickAudio();
    document.getElementById("booster-info-dialog-overlay").style.display = "flex";
    document.getElementById("booster-info-output").innerHTML = "WILD BONUS BOOSTER<br><br>Duration: INSTANT<br>Effect: Grants a wild bonus on the next spin. <br><br>  <span style='color: #ff74f3;'><span style='color: springgreen;'>[NOTE]</span> > Bonus feature will grant a minimum of 7 free spins (up to 10) & a random bet between <span style='color: springgreen;'>$1.00</span> and <span style='color: springgreen;'>$5.00</span>";
}

inventory_slot_6_booster_info_opt.onclick = function() {
    keyboardClickAudio();
    document.getElementById("booster-info-dialog-overlay").style.display = "flex";
    document.getElementById("booster-info-output").innerHTML = "INSTANT XP BOOSTER<br><br>Duration: INSTANT<br>Effect: Grants a random amount of XP instantly.";
}

inventory_slot_7_booster_info_opt.onclick = function() {
    keyboardClickAudio();
    document.getElementById("booster-info-dialog-overlay").style.display = "flex";
    document.getElementById("booster-info-output").innerHTML = "X2 LVL XP BOOSTER<br><br>Duration: 5MIN<br>Effect: Doubles the amount of XP earned for 5 minutes.";
}

inventory_slot_8_booster_info_opt.onclick = function() {
    keyboardClickAudio();
    document.getElementById("booster-info-dialog-overlay").style.display = "flex";
    document.getElementById("booster-info-output").innerHTML = "X5 FARM SPEED BOOSTER<br><br>Duration: 1MIN<br>Effect: Increases the speed of farm progress by 5 times for 1 minute.";
}

inventory_slot_9_booster_info_opt.onclick = function() {
    keyboardClickAudio();
    document.getElementById("booster-info-dialog-overlay").style.display = "flex";
    document.getElementById("booster-info-output").innerHTML = "MYSTERY PRIZE BOOSTER<br><br>Duration: INSTANT<br>Effect: Select mystery picks for a chance of winning random prizes!";
}

inventory_slot_10_booster_info_opt.onclick = function() {
    keyboardClickAudio();
    document.getElementById("booster-info-dialog-overlay").style.display = "flex";
    document.getElementById("booster-info-output").innerHTML = "FREE SPINS BONUS BOOSTER<br><br>Duration: INSTANT<br>Effect: Grants free spins in the 15-reel slot. <br><br> <span style='color: #ffcc00;'><span style='color: springgreen;'>[NOTE]</span> > Bonus feature will grant 10 free spins & a random bet / stake between <span style='color: springgreen;'>$1.00</span> and <span style='color: springgreen;'>$5.00</span>";
}


inventory_slot_11_booster_info_opt.onclick = function() {
    keyboardClickAudio();
    document.getElementById("booster-info-dialog-overlay").style.display = "flex";
    document.getElementById("booster-info-output").innerHTML = "LAST LIFE BOOSTER<br><br>Duration: INSTANT<br>Effect: Grants X1 attempt during any trivia match / difficulty.";
}


inventory_slot_12_booster_info_opt.onclick = function() {
    keyboardClickAudio();
    document.getElementById("booster-info-dialog-overlay").style.display = "flex";
    document.getElementById("booster-info-output").innerHTML = "STREAK SAVER BOOSTER<br><br>Duration: INSTANT<br>Effect: Grants X1 streak point during any match in the number guessing game.";
}

inventory_slot_13_booster_info_opt.onclick = function() {
    keyboardClickAudio();
    document.getElementById("booster-info-dialog-overlay").style.display = "flex";
    document.getElementById("booster-info-output").innerHTML = "FREE SPREE BOOSTER<br><br>Duration: 30s<br>Effect: Sets the price of slots in match boards to $0 for 30 seconds!";
}