let store_slot_1_passive_income_cashout_int_reduction_price = 500; // PASSIVE INCOME POOL CASHOUT TIMER REDUCTION PRICE
let store_slot_2_upgrade_price = 30; // X2 FARM INCOME BOOSTER
let store_slot_3_tier_2_farm_price = 1000; // TIER 2 FUND FARMS
let store_slot_4_upgrade_price = 50; // X3 FARM INCOME BOOSTER
let store_slot_5_tier_3_farm_price = 10; // TIER 3 COIN FARMS
let store_slot_6_upgrade_price = 100; // X2 FARM SPEED BOOSTER
let store_slot_7_upgrade_price = 175; // X5 FARM SPEED BOOSTER
let store_slot_8_upgrade_price = 1; // EXTRA WILDS BOOSTER
let store_slot_9_upgrade_price = 5; // QUICK COLLECT PERK
let store_slot_11_upgrade_price = 3; // WILD FREE SPINS BONUS
let store_slot_13_upgrade_price = 2; // FREE SPINS BONUS
let store_slot_14_upgrade_price = 3; // WILD FREE SPINS BONUS
let store_slot_15_upgrade_price = 25; // STREAK SAVER BOOSTER
let store_slot_16_upgrade_price = 30; // LAST LIFE BOOSTER (TRIVIA)
let store_slot_17_upgrade_price = 1; // FREE SPREE BOOSTER (MATCH BOARDS)

let store_slot_1_upgrade_max_lvl = 15;
let store_slot_1_upgrade_lvl_checkpoint_1 = 5;
let store_slot_1_upgrade_lvl_checkpoint_2 = 10;
let store_slot_1_upgrade_max_lvl_state = false;
let store_slot_1_passive_income_cashout_int_reduction_percent = 0.05;
let store_slot_1_passive_income_cashout_int_reduction = 3000;
let store_slot_1_passive_income_cashout_int_reduction_lvl = 0;
let store_slot_1_passive_income_cashout_int_reduction_percent_output = document.getElementById("passive-income-cashout-int-reduction-percent-output");
let store_slot_1_passive_income_cashout_int_reduction_seconds_output = document.getElementById("passive-income-cashout-int-reduction-seconds-output");

let quick_collect_perk_owned = false;
let quick_collect_btn = document.getElementById("quick-collect-opt");

let cashout_timer_upgrade_dialog_overlay = document.getElementById("cashout-timer-upgrade-dialog-overlay");
let store_wealth_farms_showcase_dialog_overlay = document.getElementById("store-wealth-farms-showcase-dialog-overlay");
let close_store_wealth_farms_showcase_dialog_overlay_btn = document.getElementById("close-store-wealth-farms-showcase-dialog-overlay-btn");

let confirm_purchase_btn = document.getElementById("confirm-purchase-btn");
let abort_purchase_btn = document.getElementById("abort-purchase-btn");

document.getElementById("tier-2-farm-info-btn").onclick = function() {
    keyboardClickAudio();
    store_wealth_farms_showcase_dialog_overlay.style.display = "flex";
    document.getElementById("farm-type-output").innerHTML = "<span style='color: rgb(10, 111, 183);'>TIER 2 FUND FARMS</span>";
    document.getElementById("wealth-farm-showcase-type").src = "Images/tier-2-cash-farm.png";
}

document.getElementById("tier-3-farm-info-btn").onclick = function() {
    keyboardClickAudio();
    store_wealth_farms_showcase_dialog_overlay.style.display = "flex";
    document.getElementById("farm-type-output").innerHTML = "<span style='color: rgb(135, 89, 3);'>TIER 3 COIN FARMS</span>";
    document.getElementById("wealth-farm-showcase-type").src = "Images/tier-3-coin-farm.png";
}

close_store_wealth_farms_showcase_dialog_overlay_btn.onclick = function() {
    store_wealth_farms_showcase_dialog_overlay.style.display = "none";
    keyboardClickAudio();
}

document.getElementById("store-ui-info-btn").onclick = function() {
    document.getElementById("store-info-dialog-overlay").style.display = "flex";
}

document.getElementById("specials-section-opt").onclick = function() {
    document.getElementById("store-ui-slot-board").style.display = "none";
    document.getElementById("store-ui-slot-board-2").style.display = "none";
    document.getElementById("store-ui-slot-board-3").style.display = "none";
    document.getElementById("store-ui-slot-board-4").style.display = "flex";
}

document.getElementById("wealth-farms-section-opt").onclick = function() {
    document.getElementById("store-ui-slot-board").style.display = "none";
    document.getElementById("store-ui-slot-board-2").style.display = "flex";
    document.getElementById("store-ui-slot-board-3").style.display = "none";
    document.getElementById("store-ui-slot-board-4").style.display = "none";
}

document.getElementById("boosters-section-opt").onclick = function() {
    document.getElementById("store-ui-slot-board").style.display = "flex";
    document.getElementById("store-ui-slot-board-2").style.display = "none";
    document.getElementById("store-ui-slot-board-3").style.display = "none";
    document.getElementById("store-ui-slot-board-4").style.display = "none";
}

document.getElementById("upgrades-perks-section-opt").onclick = function() {
    document.getElementById("store-ui-slot-board").style.display = "none";
    document.getElementById("store-ui-slot-board-2").style.display = "none";
    document.getElementById("store-ui-slot-board-3").style.display = "flex";
    document.getElementById("store-ui-slot-board-4").style.display = "none";
}

document.getElementById("close-store-info-dialog-overlay-btn").onclick = function() {
    document.getElementById("store-info-dialog-overlay").style.display = "none";
}

confirm_purchase_btn.onclick = function() {
    // PREVENT MAX LEVEL BYPASS ON RAPID CLICKS
    if (store_slot_1_passive_income_cashout_int_reduction_lvl >= store_slot_1_upgrade_max_lvl) {
        notificationDialog("Max level reached!", 3000);
        return;
    }
    
    if (player_cash_balance >= store_slot_1_passive_income_cashout_int_reduction_price) {
        upgradePurchasedAudio();
        player_cash_balance -= store_slot_1_passive_income_cashout_int_reduction_price;
        passive_income_grant_int -= store_slot_1_passive_income_cashout_int_reduction;
        store_slot_1_passive_income_cashout_int_reduction_lvl++;
        store_slot_1_passive_income_cashout_int_reduction_price += store_slot_1_passive_income_cashout_int_reduction_price * 1.2;

        restartPassiveIncomeInterval();

        if (store_slot_1_passive_income_cashout_int_reduction_lvl === store_slot_1_upgrade_lvl_checkpoint_1) {
            player_diamond_balance += 5;
        }
    } else {
        upgradePurchaseFailedAudio();
        setTimeout(() => { insufficientFundsAudio(); }, 500);
        notificationDialog("Insufficient Cash!", 3000);
    }

    if (store_slot_1_passive_income_cashout_int_reduction_lvl === store_slot_1_upgrade_max_lvl) {
        store_slot_1_upgrade_max_lvl_state = true;
        document.getElementById("store-slot-1-upgrade-btn").disabled = true;
        document.getElementById("store-slot-1-upgrade-btn").style.opacity = "0.5";
        document.getElementById("store-slot-1-upgrade-btn").style.cursor = "not-allowed";
    }
}

abort_purchase_btn.onclick = function() {
    cashout_timer_upgrade_dialog_overlay.style.display = "none";
}

document.getElementById("store-slot-1-upgrade-btn").onclick = function() {
    cashout_timer_upgrade_dialog_overlay.style.display = "flex";
}

document.getElementById("store-slot-2-upgrade-btn").onclick = function() {
    if (player_coins_balance >= store_slot_2_upgrade_price) {
        
        inventory_slot_1_player_owned_amount++;
        player_coins_balance -= store_slot_2_upgrade_price;
        notificationDialog("[X1] DOUBLE FARM INCOME BOOSTER ADDED TO INVENTORY!", 3500);
        upgradePurchasedAudio();
    } else {
        notificationDialog("Insufficient Coins!", 3500);
        setTimeout(() => { insufficientCoinsAudio(); }, 500);
        upgradePurchaseFailedAudio();
    }
}

document.getElementById("store-slot-4-upgrade-btn").onclick = function() {
    if (player_coins_balance >= store_slot_4_upgrade_price) {
        
        inventory_slot_2_player_owned_amount++;
        player_coins_balance -= store_slot_4_upgrade_price;
        notificationDialog("[X1] TRIPLE FARM INCOME BOOSTER ADDED TO INVENTORY!", 3500);
        upgradePurchasedAudio();
    } else {
        upgradePurchaseFailedAudio();
        setTimeout(() => { insufficientCoinsAudio(); }, 500);
        notificationDialog("Insufficient Coins!", 3500);
    }
}

document.getElementById("store-slot-6-upgrade-btn").onclick = function() {
    if (player_coins_balance >= store_slot_6_upgrade_price) {
        inventory_slot_3_player_owned_amount++;
        player_coins_balance -= store_slot_6_upgrade_price;
        upgradePurchasedAudio();
        notificationDialog("X2FARM SPEED BOOSTER ADDED TO INVENTORY!", 3500);
    } else {
        upgradePurchaseFailedAudio();
        setTimeout(() => { insufficientCoinsAudio(); }, 500);
        notificationDialog("Insufficient Coins!", 3500);
    }
}

document.getElementById("store-slot-7-upgrade-btn").onclick = function() {
    if (player_coins_balance >= store_slot_7_upgrade_price) {
        inventory_slot_8_player_owned_amount++;
        player_coins_balance -= store_slot_7_upgrade_price;
        upgradePurchasedAudio();
        notificationDialog("X5 FARM SPEED BOOSTER ADDED TO INVENTORY!", 3500);
    } else {
        upgradePurchaseFailedAudio();
        setTimeout(() => { insufficientCoinsAudio(); }, 500);
        notificationDialog("Insufficient Coins!", 3500);
    }
}

document.getElementById("store-slot-8-upgrade-btn").onclick = function() {
    if (player_diamond_balance >= store_slot_8_upgrade_price) {
        inventory_slot_4_player_owned_amount++;
        player_diamond_balance -= store_slot_8_upgrade_price;
        upgradePurchasedAudio();
        notificationDialog("[X1] WILD BOOSTER ADDED TO INVENTORY!", 3500);
    } else {
        upgradePurchaseFailedAudio();
        setTimeout(() => { insufficientDiamondsAudio(); }, 500);
        notificationDialog("Insufficient Diamonds!", 3000);
    }
}

// TIER 2 FUND FARMS PURCHASE

document.getElementById("store-slot-3-upgrade-btn").onclick = function() {
    if (player_coins_balance >= store_slot_3_tier_2_farm_price) {
        player_coins_balance -= store_slot_3_tier_2_farm_price;
        notificationDialog("TIER 2 FARM ACQUIRED!", 4000);
        tier_2_farm_unlocked = true;
        document.getElementById("store-slot-3-upgrade-btn").innerHTML = "<span style='color: aquamarine;'>OWNED</span>|" + "<span style='color: lime;'>ACTIVE</span>";
        document.getElementById("tier-2-table").innerHTML = "<span style='display: inline-flex; align-items: center; white-space: nowrap; color: rgb(10, 111, 183);'><img src='Images/Cash-balance-icon.png' width='50px' height='50px' style='flex-shrink: 0; margin-right: 10px;' />Tier 2 Fund Farms ---</span><span style='color: aquamarine; margin-left: 10px;'>OWNED</span>|" + "<span style='color: lime;'>ACTIVE</span>";
        setTimeout(() => { document.getElementById("fund-farms-menu-opt").click(); }, 1000)
        setTimeout(() => { document.getElementById("fund-farm-tiers-opt").click(); }, 1100)
        setTimeout(() => { document.getElementById("tier-2-table").click(); }, 1200)
    } else {
        notificationDialog("Insufficient Coins!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { insufficientCoinsAudio(); }, 500);
    }
}

// TIER 3 FUND FARMS PURCHASE

document.getElementById("store-slot-5-upgrade-btn").onclick = function() {
    if (player_diamond_balance >= store_slot_5_tier_3_farm_price) {
        player_diamond_balance -= store_slot_5_tier_3_farm_price;
        notificationDialog("TIER 3 FUND FARMS ACQUIRED!", 4000);
        tier_3_farm_unlocked = true;
        document.getElementById("store-slot-5-upgrade-btn").innerHTML = "<span style='color: aquamarine;'>OWNED</span>|" + "<span style='color: lime;'>ACTIVE</span>";
        document.getElementById("tier-3-table").innerHTML = "<span style='display: inline-flex; align-items: center; white-space: nowrap; color: rgb(190, 126, 5);'><img src='Images/Tycoon-score-balance-icon.png' width='50px' height='50px' style='flex-shrink: 0; margin-right: 10px;' />Tier 3 Coin Farms ---</span><span style='color: aquamarine; margin-left: 10px;'>OWNED</span>|" + "<span style='color: lime;'>ACTIVE</span>";
        setTimeout(() => { document.getElementById("fund-farms-menu-opt").click(); }, 1000)
        setTimeout(() => { document.getElementById("fund-farm-tiers-opt").click(); }, 1100)
        setTimeout(() => { document.getElementById("tier-3-table").click(); }, 1200)
    } else {
        notificationDialog("Insufficient Diamonds!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { insufficientDiamondsAudio(); }, 500);
    }
}

document.getElementById("store-slot-9-upgrade-btn").onclick = function() {
    if (player_diamond_balance >= store_slot_9_upgrade_price) {
        quick_collect_perk_owned = true;
        player_diamond_balance -= store_slot_9_upgrade_price;
        keyboardClickAudio();
        upgradePurchasedAudio();
        notificationDialog("QUICK COLLECT PERMANENTLY UNLOCKED!", 3500);

        setTimeout(() => {
            if (!quick_collect_perk_owned) {
                upgradePurchaseFailedAudio();
                notificationDialog("QUICK COLLECT NOT OWNED!", 3500);
            } else {
                notificationDialog("QUICK COLLECT ACTIVATED!", 3500);
                quick_collect_btn.style.opacity = "1";
                quick_collect_btn.style.cursor = "pointer";
                quick_collect_btn.disabled = false;
                document.getElementById("store-slot-9-upgrade-btn").style.opacity = "0.5";
                document.getElementById("store-slot-9-upgrade-btn").style.cursor = "not-allowed";
                document.getElementById("store-slot-9-upgrade-btn").disabled = true;
                document.getElementById("buff-12-ownership-output").innerHTML = "<span style='color: lime'>ACTIVE</span>";
                document.getElementById("buff-12-ownership-output").style.borderRight = "5px solid lime";
                setTimeout(() => { fund_farms_opt_btn.click(); }, 500)
                bonusWinAudio();
            }
        }, 500)
    } else {
        notificationDialog("Insufficient Diamonds!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { insufficientDiamondsAudio(); }, 500);
    }
}

document.getElementById("store-slot-13-upgrade-btn").onclick = function() {
    keyboardClickAudio();
    if (player_diamond_balance >= store_slot_13_upgrade_price) {
        player_diamond_balance -= store_slot_13_upgrade_price;
        notificationDialog("[SUCCESS] > FREE SPINS INITIATING..", 3500);
        collectTaskAwardAudio();
        setTimeout(() => {
            inventory_slot_10_player_owned_amount++;
            setTimeout(() => { inventory_slot_10_use_booster_opt.click(); }, 500)
        }, 2000)
    } else {
        notificationDialog("Insufficient Diamonds!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { insufficientDiamondsAudio(); }, 500);
    }
}

document.getElementById("store-slot-14-upgrade-btn").onclick = function() {
    keyboardClickAudio();
    if (player_diamond_balance >= store_slot_14_upgrade_price) {
        player_diamond_balance -= store_slot_14_upgrade_price;
        notificationDialog("[SUCCESS] > WILD FREE SPINS INITIATING..", 3500);
        collectTaskAwardAudio();
        setTimeout(() => {
            inventory_slot_5_player_owned_amount++;
            setTimeout(() => { inventory_slot_5_use_booster_opt.click(); }, 500)
        }, 2000)
    } else {
        notificationDialog("Insufficient Diamonds!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { insufficientDiamondsAudio(); }, 500);
    }
}

quick_collect_btn.onclick = function() {
    if (!quick_collect_perk_owned) {
        notificationDialog("QUICK COLLECT NOT OWNED!", 3500);
        upgradePurchaseFailedAudio();
        return;
    }

    for (let i = 0; i < farm_collection_status_storage.length; i++) {
        if (farm_collection_status_storage[i] === true && farm_collect_opts_storage[i]) { farm_collect_opts_storage[i].click(); }
    }

    for (let i = 0; i < tier_2_farms_collection_status_storage.length; i++) {
        if (tier_2_farms_collection_status_storage[i] === true && tier_2_farm_unlocked === true && tier_2_farm_collect_opts_storage[i]) { tier_2_farm_collect_opts_storage[i].click(); }
    }

    for (let i = 0; i < tier_3_farms_collection_status_storage.length; i++) {
        if (tier_3_farms_collection_status_storage[i] === true && tier_3_farm_unlocked === true && tier_3_farm_collect_opts_storage[i]) { tier_3_farm_collect_opts_storage[i].click(); }
    }
}

document.getElementById("store-slot-10-upgrade-btn").onclick = function() {
    if (player_cash_balance >= store_slot_15_upgrade_price) {
        notificationDialog("[SUCCESS] > X1 STREAK SAVER BOOSTER ADDED TO INVENTORY!", 4000);
        collectTaskAwardAudio();
        player_cash_balance -= store_slot_15_upgrade_price;
        inventory_slot_12_player_owned_amount++;
    } else {
        notificationDialog("Insufficient Funds!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { insufficientFundsAudio(); }, 500);
    }
}

document.getElementById("store-slot-11-upgrade-btn").onclick = function() {
    if (player_cash_balance >= store_slot_16_upgrade_price) {
        notificationDialog("[SUCCESS] > X1 LAST LIFE BOOSTER ADDED TO INVENTORY!", 4000);
        collectTaskAwardAudio();
        player_cash_balance -= store_slot_16_upgrade_price;
        inventory_slot_11_player_owned_amount++;
    } else {
        notificationDialog("Insufficient Funds!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { insufficientFundsAudio(); }, 500);
    }
}

document.getElementById("store-slot-12-upgrade-btn").onclick = function() {
    if (player_diamond_balance >= store_slot_17_upgrade_price) {
        notificationDialog("[SUCCESS] > X1 FREE SPREE BOOSTER ADDED TO INVENTORY!", 4000);
        collectTaskAwardAudio();
        player_diamond_balance -= store_slot_17_upgrade_price;
        inventory_slot_13_player_owned_amount++;
    } else {
        notificationDialog("Insufficient Diamonds!", 3000);
        upgradePurchaseFailedAudio();
        setTimeout(() => { insufficientDiamondsAudio(); }, 500);
    }
}