let current_timestamp = Date.now();
let on_session_end = Date.now();
let total_playtime = 0;

let playtime_hours = 0;
let playtime_minutes = 0;
let playtime_seconds = 0;

setInterval(() => {
    const now = Date.now();
    total_playtime += now - current_timestamp;
    current_timestamp = now;

    playtime_hours = Math.floor(total_playtime / 3600000);
    playtime_minutes = Math.floor(total_playtime / 60000) % 60;
    playtime_seconds = Math.floor(total_playtime / 1000) % 60;
}, 1000);