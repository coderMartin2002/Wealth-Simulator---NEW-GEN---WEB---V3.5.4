// FARM COLLECTION BTNS

// TIER 1 FARMS

let farm_1_collect_opt = document.getElementById("farm-1-collect-opt");
let farm_2_collect_opt = document.getElementById("farm-2-collect-opt");
let farm_3_collect_opt = document.getElementById("farm-3-collect-opt");
let farm_4_collect_opt = document.getElementById("farm-4-collect-opt");
let farm_5_collect_opt = document.getElementById("farm-5-collect-opt");
let farm_6_collect_opt = document.getElementById("farm-6-collect-opt");

let farm_collect_opts_storage = [farm_1_collect_opt, farm_2_collect_opt, farm_3_collect_opt, farm_4_collect_opt, farm_5_collect_opt, farm_6_collect_opt];

// TIER 2 FARMS

let tier_2_farm_1_collect_opt = document.getElementById("tier-2-farm-1-collect-opt");
let tier_2_farm_2_collect_opt = document.getElementById("tier-2-farm-2-collect-opt");
let tier_2_farm_3_collect_opt = document.getElementById("tier-2-farm-3-collect-opt");
let tier_2_farm_4_collect_opt = document.getElementById("tier-2-farm-4-collect-opt");
let tier_2_farm_5_collect_opt = document.getElementById("tier-2-farm-5-collect-opt");
let tier_2_farm_6_collect_opt = document.getElementById("tier-2-farm-6-collect-opt");

let tier_2_farm_collect_opts_storage = [tier_2_farm_1_collect_opt, tier_2_farm_2_collect_opt, tier_2_farm_3_collect_opt, tier_2_farm_4_collect_opt, tier_2_farm_5_collect_opt, tier_2_farm_6_collect_opt];

// TIER 3 FARMS

let tier_3_farm_1_collect_opt = document.getElementById("tier-3-farm-1-collect-opt");
let tier_3_farm_2_collect_opt = document.getElementById("tier-3-farm-2-collect-opt");
let tier_3_farm_3_collect_opt = document.getElementById("tier-3-farm-3-collect-opt");
let tier_3_farm_4_collect_opt = document.getElementById("tier-3-farm-4-collect-opt");
let tier_3_farm_5_collect_opt = document.getElementById("tier-3-farm-5-collect-opt");
let tier_3_farm_6_collect_opt = document.getElementById("tier-3-farm-6-collect-opt");

let tier_3_farm_collect_opts_storage = [tier_3_farm_1_collect_opt, tier_3_farm_2_collect_opt, tier_3_farm_3_collect_opt, tier_3_farm_4_collect_opt, tier_3_farm_5_collect_opt, tier_3_farm_6_collect_opt];

// FARM CASH AMOUNTS

// TIER 1 FARMS

let farm_1_cash_amount = 0.05;
let farm_2_cash_amount = 0.10;
let farm_3_cash_amount = 0.20;
let farm_4_cash_amount = 0.40;
let farm_5_cash_amount = 0.60;
let farm_6_cash_amount = 1.20;

// TIER 2 FARMS (X3 TRIPLED CASH VALUES)

let tier_2_farm_1_cash_amount = 0.15;
let tier_2_farm_2_cash_amount = 0.30;
let tier_2_farm_3_cash_amount = 0.60;
let tier_2_farm_4_cash_amount = 1.20;
let tier_2_farm_5_cash_amount = 1.80;
let tier_2_farm_6_cash_amount = 2.40;

// TIER 3 FARMS

let tier_3_farm_1_cash_amount = 1;
let tier_3_farm_2_cash_amount = 2;
let tier_3_farm_3_cash_amount = 3;
let tier_3_farm_4_cash_amount = 4;
let tier_3_farm_5_cash_amount = 5;
let tier_3_farm_6_cash_amount = 6;


let farm_cash_amounts_arr = [farm_1_cash_amount, farm_2_cash_amount, farm_3_cash_amount, farm_4_cash_amount, farm_5_cash_amount, farm_6_cash_amount];
let tier_2_farm_cash_amounts_arr = [tier_2_farm_1_cash_amount, tier_2_farm_2_cash_amount, tier_2_farm_3_cash_amount, tier_2_farm_4_cash_amount, tier_2_farm_5_cash_amount, tier_2_farm_6_cash_amount];
let total_fund_farm_clicks = 0;
let total_fund_farm_cash_earned = 0;

// FARM INTERVAL REFS

// TIER 1 FARMS

let farm_1_int_ref = document.getElementById("farm-1-int");
let farm_2_int_ref = document.getElementById("farm-2-int"); 
let farm_3_int_ref = document.getElementById("farm-3-int");
let farm_4_int_ref = document.getElementById("farm-4-int");
let farm_5_int_ref = document.getElementById("farm-5-int");
let farm_6_int_ref = document.getElementById("farm-6-int");

// TIER 2 FARMS

let tier_2_farm_1_int_ref = document.getElementById("tier-2-farm-1-int");
let tier_2_farm_2_int_ref = document.getElementById("tier-2-farm-2-int"); 
let tier_2_farm_3_int_ref = document.getElementById("tier-2-farm-3-int");
let tier_2_farm_4_int_ref = document.getElementById("tier-2-farm-4-int");
let tier_2_farm_5_int_ref = document.getElementById("tier-2-farm-5-int");
let tier_2_farm_6_int_ref = document.getElementById("tier-2-farm-6-int");

// TIER 3 FARMS

let tier_3_farm_1_int_ref = document.getElementById("tier-3-farm-1-int");
let tier_3_farm_2_int_ref = document.getElementById("tier-3-farm-2-int");
let tier_3_farm_3_int_ref = document.getElementById("tier-3-farm-3-int");
let tier_3_farm_4_int_ref = document.getElementById("tier-3-farm-4-int");
let tier_3_farm_5_int_ref = document.getElementById("tier-3-farm-5-int");
let tier_3_farm_6_int_ref = document.getElementById("tier-3-farm-6-int");

// FARM STATUS PROGRESS BARS

// TIER 1 FARMS

let farm_1_progress_bar = document.getElementById("farm-1-progress-bar");
let farm_2_progress_bar = document.getElementById("farm-2-progress-bar");
let farm_3_progress_bar = document.getElementById("farm-3-progress-bar");
let farm_4_progress_bar = document.getElementById("farm-4-progress-bar");
let farm_5_progress_bar = document.getElementById("farm-5-progress-bar");
let farm_6_progress_bar = document.getElementById("farm-6-progress-bar");

// TIER 2 FARMS

let tier_2_farm_1_progress_bar = document.getElementById("tier-2-farm-1-progress-bar");
let tier_2_farm_2_progress_bar = document.getElementById("tier-2-farm-2-progress-bar");
let tier_2_farm_3_progress_bar = document.getElementById("tier-2-farm-3-progress-bar");
let tier_2_farm_4_progress_bar = document.getElementById("tier-2-farm-4-progress-bar");
let tier_2_farm_5_progress_bar = document.getElementById("tier-2-farm-5-progress-bar");
let tier_2_farm_6_progress_bar = document.getElementById("tier-2-farm-6-progress-bar");

// TIER 3 FARMS

let tier_3_farm_1_progress_bar = document.getElementById("tier-3-farm-1-progress-bar");
let tier_3_farm_2_progress_bar = document.getElementById("tier-3-farm-2-progress-bar");
let tier_3_farm_3_progress_bar = document.getElementById("tier-3-farm-3-progress-bar");
let tier_3_farm_4_progress_bar = document.getElementById("tier-3-farm-4-progress-bar");
let tier_3_farm_5_progress_bar = document.getElementById("tier-3-farm-5-progress-bar");
let tier_3_farm_6_progress_bar = document.getElementById("tier-3-farm-6-progress-bar");

// FARM RATE OUTPUTS 

let farm_1_rate_output = document.getElementById("farm-1-rate-output");
let farm_2_rate_output = document.getElementById("farm-2-rate-output");
let farm_3_rate_output = document.getElementById("farm-3-rate-output");
let farm_4_rate_output = document.getElementById("farm-4-rate-output");
let farm_5_rate_output = document.getElementById("farm-5-rate-output");
let farm_6_rate_output = document.getElementById("farm-6-rate-output");

// TIER 2 FARMS

let tier_2_farm_1_rate_output = document.getElementById("tier-2-farm-1-rate-output");
let tier_2_farm_2_rate_output = document.getElementById("tier-2-farm-2-rate-output");
let tier_2_farm_3_rate_output = document.getElementById("tier-2-farm-3-rate-output");
let tier_2_farm_4_rate_output = document.getElementById("tier-2-farm-4-rate-output");
let tier_2_farm_5_rate_output = document.getElementById("tier-2-farm-5-rate-output");
let tier_2_farm_6_rate_output = document.getElementById("tier-2-farm-6-rate-output");

// TIER 3 FARMS

let tier_3_farm_1_rate_output = document.getElementById("tier-3-farm-1-rate-output");
let tier_3_farm_2_rate_output = document.getElementById("tier-3-farm-2-rate-output");
let tier_3_farm_3_rate_output = document.getElementById("tier-3-farm-3-rate-output");
let tier_3_farm_4_rate_output = document.getElementById("tier-3-farm-4-rate-output");
let tier_3_farm_5_rate_output = document.getElementById("tier-3-farm-5-rate-output");
let tier_3_farm_6_rate_output = document.getElementById("tier-3-farm-6-rate-output");

// FARM COMPLETION STATUS BOOLS

// TIER 1 FARMS

let farm_1_collection_ready = true;
let farm_2_collection_ready = true;
let farm_3_collection_ready = true;
let farm_4_collection_ready = true;
let farm_5_collection_ready = true;
let farm_6_collection_ready = true;

let farm_collection_status_storage = [farm_1_collection_ready, farm_2_collection_ready, farm_3_collection_ready, farm_4_collection_ready, farm_5_collection_ready, farm_6_collection_ready];

// TIER 2 FARMS

let tier_2_farm_1_collection_ready = true;
let tier_2_farm_2_collection_ready = true;
let tier_2_farm_3_collection_ready = true;
let tier_2_farm_4_collection_ready = true;
let tier_2_farm_5_collection_ready = true;
let tier_2_farm_6_collection_ready = true;

let tier_2_farms_collection_status_storage = [tier_2_farm_1_collection_ready, tier_2_farm_2_collection_ready, tier_2_farm_3_collection_ready, tier_2_farm_4_collection_ready, tier_2_farm_5_collection_ready, tier_2_farm_6_collection_ready];

// TIER 3 FARMS

let tier_3_farm_1_collection_ready = true;
let tier_3_farm_2_collection_ready = true;
let tier_3_farm_3_collection_ready = true;
let tier_3_farm_4_collection_ready = true;
let tier_3_farm_5_collection_ready = true;
let tier_3_farm_6_collection_ready = true;

let tier_3_farms_collection_status_storage = [tier_3_farm_1_collection_ready, tier_3_farm_2_collection_ready, tier_3_farm_3_collection_ready, tier_3_farm_4_collection_ready, tier_3_farm_5_collection_ready, tier_3_farm_6_collection_ready];

let tier_2_farm_unlocked = false;
let tier_3_farm_unlocked = false;

// FARM LVL PROGRESS INC

// TIER 1 FARMS

let farm_1_lvl_progress_inc = 1;
let farm_2_lvl_progress_inc = 2;
let farm_3_lvl_progress_inc = 3;
let farm_4_lvl_progress_inc = 4;
let farm_5_lvl_progress_inc = 5;
let farm_6_lvl_progress_inc = 6;

// TIER 2 FARMS

let tier_2_farm_1_lvl_progress_inc = 3;
let tier_2_farm_2_lvl_progress_inc = 6;
let tier_2_farm_3_lvl_progress_inc = 9;
let tier_2_farm_4_lvl_progress_inc = 12;
let tier_2_farm_5_lvl_progress_inc = 15;
let tier_2_farm_6_lvl_progress_inc = 18;

// TIER 3 FARMS

let tier_3_farm_1_lvl_progress_inc = 5;
let tier_3_farm_2_lvl_progress_inc = 10;
let tier_3_farm_3_lvl_progress_inc = 15;
let tier_3_farm_4_lvl_progress_inc = 20;
let tier_3_farm_5_lvl_progress_inc = 25;
let tier_3_farm_6_lvl_progress_inc = 30;

let gen_farm_percent_progress_displays_storage = document.getElementsByClassName("farm-percent-progress");

setInterval(() => {
    farm_1_rate_output.innerHTML = "<h3 style='color: springgreen; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>$" + farm_1_cash_amount.toFixed(2) + "/" + farm_1_progress_bar.max + "s</h3>";
    farm_2_rate_output.innerHTML = "<h3 style='color: springgreen; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>$" + farm_2_cash_amount.toFixed(2) + "/" + farm_2_progress_bar.max + "s</h3>";
    farm_3_rate_output.innerHTML = "<h3 style='color: springgreen; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>$" + farm_3_cash_amount.toFixed(2) + "/" + farm_3_progress_bar.max + "s</h3>";
    farm_4_rate_output.innerHTML = "<h3 style='color: springgreen; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>$" + farm_4_cash_amount.toFixed(2) + "/" + farm_4_progress_bar.max + "s</h3>";
    farm_5_rate_output.innerHTML = "<h3 style='color: springgreen; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>$" + farm_5_cash_amount.toFixed(2) + "/" + farm_5_progress_bar.max + "s</h3>";
    farm_6_rate_output.innerHTML = "<h3 style='color: springgreen; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>$" + farm_6_cash_amount.toFixed(2) + "/" + farm_6_progress_bar.max + "s</h3>";

    tier_2_farm_1_rate_output.innerHTML = "<h3 style='color: springgreen; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>$" + tier_2_farm_1_cash_amount.toFixed(2) + "/" + tier_2_farm_1_progress_bar.max + "s</h3>";
    tier_2_farm_2_rate_output.innerHTML = "<h3 style='color: springgreen; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>$" + tier_2_farm_2_cash_amount.toFixed(2) + "/" + tier_2_farm_2_progress_bar.max + "s</h3>";
    tier_2_farm_3_rate_output.innerHTML = "<h3 style='color: springgreen; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>$" + tier_2_farm_3_cash_amount.toFixed(2) + "/" + tier_2_farm_3_progress_bar.max + "s</h3>";
    tier_2_farm_4_rate_output.innerHTML = "<h3 style='color: springgreen; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>$" + tier_2_farm_4_cash_amount.toFixed(2) + "/" + tier_2_farm_4_progress_bar.max + "s</h3>";
    tier_2_farm_5_rate_output.innerHTML = "<h3 style='color: springgreen; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>$" + tier_2_farm_5_cash_amount.toFixed(2) + "/" + tier_2_farm_5_progress_bar.max + "s</h3>";
    tier_2_farm_6_rate_output.innerHTML = "<h3 style='color: springgreen; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>$" + tier_2_farm_6_cash_amount.toFixed(2) + "/" + tier_2_farm_6_progress_bar.max + "s</h3>";

    tier_3_farm_1_rate_output.innerHTML = "<h3 style='color: yellow; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>" + tier_3_farm_1_cash_amount + " coin/" + tier_3_farm_1_progress_bar.max + "s</h3>";
    tier_3_farm_2_rate_output.innerHTML = "<h3 style='color: yellow; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>" + tier_3_farm_2_cash_amount + " coins/" + tier_3_farm_2_progress_bar.max + "s</h3>";
    tier_3_farm_3_rate_output.innerHTML = "<h3 style='color: yellow; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>" + tier_3_farm_3_cash_amount + " coins/" + tier_3_farm_3_progress_bar.max + "s</h3>";
    tier_3_farm_4_rate_output.innerHTML = "<h3 style='color: yellow; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>" + tier_3_farm_4_cash_amount + " coins/" + tier_3_farm_4_progress_bar.max + "s</h3>";
    tier_3_farm_5_rate_output.innerHTML = "<h3 style='color: yellow; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>" + tier_3_farm_5_cash_amount + " coins/" + tier_3_farm_5_progress_bar.max + "s</h3>";
    tier_3_farm_6_rate_output.innerHTML = "<h3 style='color: yellow; font-family: Verdana, sans-serif; font-size: 18px; font-weight: 500;'>" + tier_3_farm_6_cash_amount + " coins/" + tier_3_farm_6_progress_bar.max + "s</h3>";
}, 1000)

// TIER 1 FARM PROGRESS INTERVALS

let farm_1_progress_int = setInterval(function() {
    if (increaseProgressBar(farm_1_progress_bar, 1)) {
        clearInterval(farm_1_progress_int);
    }
}, 1000);

let farm_2_progress_int = setInterval(function() {
    if (increaseProgressBar(farm_2_progress_bar, 1)) {
        clearInterval(farm_2_progress_int);
    }
}, 1000);

let farm_3_progress_int = setInterval(function() {
    if (increaseProgressBar(farm_3_progress_bar, 1)) {
        clearInterval(farm_3_progress_int);
    }
}, 1000);

let farm_4_progress_int = setInterval(function() {
    if (increaseProgressBar(farm_4_progress_bar, 1)) {
        clearInterval(farm_4_progress_int);
    }
}, 1000);

let farm_5_progress_int = setInterval(function() {
    if (increaseProgressBar(farm_5_progress_bar, 1)) {
        clearInterval(farm_5_progress_int);
    }
}, 1000);

let farm_6_progress_int = setInterval(function() {
    if (increaseProgressBar(farm_6_progress_bar, 1)) {
        clearInterval(farm_6_progress_int);
    }
}, 1000);

// TIER 2 FARM PROGRESS INTERVALS

let tier_2_farm_1_progress_int = setInterval(function() {
    if (increaseProgressBar(tier_2_farm_1_progress_bar, 1)) {
        clearInterval(tier_2_farm_1_progress_int);
    }
}, 1000);

let tier_2_farm_2_progress_int = setInterval(function() {
    if (increaseProgressBar(tier_2_farm_2_progress_bar, 1)) {
        clearInterval(tier_2_farm_2_progress_int);
    }
}, 1000);

let tier_2_farm_3_progress_int = setInterval(function() {
    if (increaseProgressBar(tier_2_farm_3_progress_bar, 1)) {
        clearInterval(tier_2_farm_3_progress_int);
    }
}, 1000);

let tier_2_farm_4_progress_int = setInterval(function() {
    if (increaseProgressBar(tier_2_farm_4_progress_bar, 1)) {
        clearInterval(tier_2_farm_4_progress_int);
    }
}, 1000);

let tier_2_farm_5_progress_int = setInterval(function() {
    if (increaseProgressBar(tier_2_farm_5_progress_bar, 1)) {
        clearInterval(tier_2_farm_5_progress_int);
    }
}, 1000);

let tier_2_farm_6_progress_int = setInterval(function() {
    if (increaseProgressBar(tier_2_farm_6_progress_bar, 1)) {
        clearInterval(tier_2_farm_6_progress_int);
    }
}, 1000);

// TIER 3 FARM PROGRESS INTERVALS

let tier_3_farm_1_progress_int = setInterval(function() {
    if (increaseProgressBar(tier_3_farm_1_progress_bar, 1)) {
        clearInterval(tier_3_farm_1_progress_int);
    }
}, 1000);

let tier_3_farm_2_progress_int = setInterval(function() {
    if (increaseProgressBar(tier_3_farm_2_progress_bar, 1)) {
        clearInterval(tier_3_farm_2_progress_int);
    }
}, 1000);

let tier_3_farm_3_progress_int = setInterval(function() {
    if (increaseProgressBar(tier_3_farm_3_progress_bar, 1)) {
        clearInterval(tier_3_farm_3_progress_int);
    }
}, 1000);

let tier_3_farm_4_progress_int = setInterval(function() {
    if (increaseProgressBar(tier_3_farm_4_progress_bar, 1)) {
        clearInterval(tier_3_farm_4_progress_int);
    }
}, 1000);

let tier_3_farm_5_progress_int = setInterval(function() {
    if (increaseProgressBar(tier_3_farm_5_progress_bar, 1)) {
        clearInterval(tier_3_farm_5_progress_int);
    }
}, 1000);

let tier_3_farm_6_progress_int = setInterval(function() {
    if (increaseProgressBar(tier_3_farm_6_progress_bar, 1)) {
        clearInterval(tier_3_farm_6_progress_int);
    }
}, 1000);

// TIER 1 FARM COLLECTION OPERATIONS

farm_1_collect_opt.onclick = function() {
    if (wealthFarmsTutorialActive) { addPlayerLvlXp(0); } else { addPlayerLvlXp(farm_1_lvl_progress_inc); }
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, farm_1_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + farm_1_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    disableFarmCollectOpt(farm_1_collect_opt);
    farm_1_progress_int = collectFundFarm(farm_1_cash_amount, 1000, farm_1_collect_opt, farm_1_progress_bar, farm_1_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

farm_2_collect_opt.onclick = function() {
    if (wealthFarmsTutorialActive) { addPlayerLvlXp(0); } else { addPlayerLvlXp(farm_2_lvl_progress_inc); }
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, farm_2_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + farm_2_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    disableFarmCollectOpt(farm_2_collect_opt);
    farm_2_progress_int = collectFundFarm(farm_2_cash_amount, 1000, farm_2_collect_opt, farm_2_progress_bar, farm_2_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

farm_3_collect_opt.onclick = function() {
    if (wealthFarmsTutorialActive) { addPlayerLvlXp(0); } else { addPlayerLvlXp(farm_3_lvl_progress_inc); }
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, farm_3_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + farm_3_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    disableFarmCollectOpt(farm_3_collect_opt);
    farm_3_progress_int = collectFundFarm(farm_3_cash_amount, 1000, farm_3_collect_opt, farm_3_progress_bar, farm_3_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

farm_4_collect_opt.onclick = function() {
    if (wealthFarmsTutorialActive) { addPlayerLvlXp(0); } else { addPlayerLvlXp(farm_4_lvl_progress_inc); }
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, farm_4_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + farm_4_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    disableFarmCollectOpt(farm_4_collect_opt);
    farm_4_progress_int = collectFundFarm(farm_4_cash_amount, 1000, farm_4_collect_opt, farm_4_progress_bar, farm_4_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

farm_5_collect_opt.onclick = function() {
    if (wealthFarmsTutorialActive) { addPlayerLvlXp(0); } else { addPlayerLvlXp(farm_5_lvl_progress_inc); }
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, farm_5_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + farm_5_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    disableFarmCollectOpt(farm_5_collect_opt);
    farm_5_progress_int = collectFundFarm(farm_5_cash_amount, 1000, farm_5_collect_opt, farm_5_progress_bar, farm_5_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

farm_6_collect_opt.onclick = function() {
    if (wealthFarmsTutorialActive) { addPlayerLvlXp(0); } else { addPlayerLvlXp(farm_6_lvl_progress_inc); }
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, farm_6_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + farm_6_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    disableFarmCollectOpt(farm_6_collect_opt);
    farm_6_progress_int = collectFundFarm(farm_6_cash_amount, 1000, farm_6_collect_opt, farm_6_progress_bar, farm_6_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

// TIER 2 FARM COLLECTION OPERATIONS

tier_2_farm_1_collect_opt.onclick = function() {
    addPlayerLvlXp(tier_2_farm_1_lvl_progress_inc);
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, tier_2_farm_1_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + tier_2_farm_1_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    tier_2_farm_1_progress_int = collectFundFarm(tier_2_farm_1_cash_amount, 1000, tier_2_farm_1_collect_opt, tier_2_farm_1_progress_bar, tier_2_farm_1_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned, );
}

tier_2_farm_2_collect_opt.onclick = function() {
    addPlayerLvlXp(tier_2_farm_2_lvl_progress_inc);
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, tier_2_farm_2_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + tier_2_farm_2_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    tier_2_farm_2_progress_int = collectFundFarm(tier_2_farm_2_cash_amount, 1000, tier_2_farm_2_collect_opt, tier_2_farm_2_progress_bar, tier_2_farm_2_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

tier_2_farm_3_collect_opt.onclick = function() {
    addPlayerLvlXp(tier_2_farm_3_lvl_progress_inc);
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, tier_2_farm_3_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + tier_2_farm_3_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    tier_2_farm_3_progress_int = collectFundFarm(tier_2_farm_3_cash_amount, 1000, tier_2_farm_3_collect_opt, tier_2_farm_3_progress_bar, tier_2_farm_3_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

tier_2_farm_4_collect_opt.onclick = function() {
    addPlayerLvlXp(tier_2_farm_4_lvl_progress_inc);
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, tier_2_farm_4_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + tier_2_farm_4_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    tier_2_farm_4_progress_int = collectFundFarm(tier_2_farm_4_cash_amount, 1000, tier_2_farm_4_collect_opt, tier_2_farm_4_progress_bar, tier_2_farm_4_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

tier_2_farm_5_collect_opt.onclick = function() {
    addPlayerLvlXp(tier_2_farm_5_lvl_progress_inc);
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, tier_2_farm_5_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + tier_2_farm_5_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    tier_2_farm_5_progress_int = collectFundFarm(tier_2_farm_5_cash_amount, 1000, tier_2_farm_5_collect_opt, tier_2_farm_5_progress_bar, tier_2_farm_5_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

tier_2_farm_6_collect_opt.onclick = function() {
    addPlayerLvlXp(tier_2_farm_6_lvl_progress_inc);
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, tier_2_farm_6_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + tier_2_farm_6_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    tier_2_farm_6_progress_int = collectFundFarm(tier_2_farm_6_cash_amount, 1000, tier_2_farm_6_collect_opt, tier_2_farm_6_progress_bar, tier_2_farm_6_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

// TIER 3 FARM COLLECTION OPERATIONS

tier_3_farm_1_collect_opt.onclick = function() {
    addPlayerLvlXp(tier_3_farm_1_lvl_progress_inc);
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, tier_3_farm_1_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + tier_3_farm_1_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    tier_3_farm_1_progress_int = collectFundFarm2(tier_3_farm_1_cash_amount, 1000, tier_3_farm_1_collect_opt, tier_3_farm_1_progress_bar, tier_3_farm_1_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

tier_3_farm_2_collect_opt.onclick = function() {
    addPlayerLvlXp(tier_3_farm_2_lvl_progress_inc);
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, tier_3_farm_2_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + tier_3_farm_2_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    tier_3_farm_2_progress_int = collectFundFarm2(tier_3_farm_2_cash_amount, 1000, tier_3_farm_2_collect_opt, tier_3_farm_2_progress_bar, tier_3_farm_2_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

tier_3_farm_3_collect_opt.onclick = function() {
    addPlayerLvlXp(tier_3_farm_3_lvl_progress_inc);
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, tier_3_farm_3_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + tier_3_farm_3_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    tier_3_farm_3_progress_int = collectFundFarm2(tier_3_farm_3_cash_amount, 1000, tier_3_farm_3_collect_opt, tier_3_farm_3_progress_bar, tier_3_farm_3_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

tier_3_farm_4_collect_opt.onclick = function() {
    addPlayerLvlXp(tier_3_farm_4_lvl_progress_inc);
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, tier_3_farm_4_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + tier_3_farm_4_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    tier_3_farm_4_progress_int = collectFundFarm2(tier_3_farm_4_cash_amount, 1000, tier_3_farm_4_collect_opt, tier_3_farm_4_progress_bar, tier_3_farm_4_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

tier_3_farm_5_collect_opt.onclick = function() {
    addPlayerLvlXp(tier_3_farm_5_lvl_progress_inc);
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, tier_3_farm_5_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + tier_3_farm_5_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    tier_3_farm_5_progress_int = collectFundFarm2(tier_3_farm_5_cash_amount, 1000, tier_3_farm_5_collect_opt, tier_3_farm_5_progress_bar, tier_3_farm_5_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

tier_3_farm_6_collect_opt.onclick = function() {
    addPlayerLvlXp(tier_3_farm_6_lvl_progress_inc);
    if (task_1_active) {
        task_1_progress = increaseProgressValue(task_1_progress, task_1_progress_bar, tier_3_farm_6_cash_amount);
        task_1_progress_bar.value = Math.min(Number(task_1_progress_bar.value) + tier_3_farm_6_cash_amount, Number(task_1_progress_bar.max) || 100);
    }
    tier_3_farm_6_progress_int = collectFundFarm2(tier_3_farm_6_cash_amount, 1000, tier_3_farm_6_collect_opt, tier_3_farm_6_progress_bar, tier_3_farm_6_progress_int, total_fund_farm_clicks, total_fund_farm_cash_earned);
}

document.getElementById("fund-farm-tiers-opt").onclick = function() {
    document.getElementById("farm-tiers-ui").style.display = "flex";
}

document.getElementById("close-farm-tiers-ui-opt").onclick = function() {
    document.getElementById("farm-tiers-ui").style.display = "none";
}

document.getElementById("tier-2-table").onclick = function() {
    if (tier_2_farm_unlocked) {
        document.getElementById("fund-farms-table-ui-2").style.display = "flex";
        document.getElementById("fund-farms-table-ui-3").style.display = "none";
        document.getElementById("fund-farms-table-ui").style.display = "none";
        document.getElementById("farm-tiers-ui").style.display = "none";
    } else {
        upgradePurchaseFailedAudio();
        notificationDialog("You don't own this farm! Visit the store", 3000);
        setTimeout(() => {
            if (player_coins_balance >= store_slot_3_tier_2_farm_price) {
                const note = confirm("Your balance can cover the cost of this farm. Click (Ok) to purchase it or (Cancel) to abort.");
                if (note) {
                    setTimeout(() => {
                        document.getElementById("store-slot-3-upgrade-btn").click();
                    }, 1000)
                }
            }
        }, 1500)
    }
}

document.getElementById("tier-3-table").onclick = function() {
    if (tier_3_farm_unlocked) {
        document.getElementById("fund-farms-table-ui-3").style.display = "flex";
        document.getElementById("fund-farms-table-ui-2").style.display = "none";
        document.getElementById("fund-farms-table-ui").style.display = "none";
        document.getElementById("farm-tiers-ui").style.display = "none";
    } else {
        upgradePurchaseFailedAudio();
        notificationDialog("You don't own this farm! Visit the store", 3000);
        setTimeout(() => {
            if (player_diamond_balance >= store_slot_5_tier_3_farm_price) {
                const note = confirm("Your balance can cover the cost of this farm. Click (Ok) to purchase it or (Cancel) to abort.");
                if (note) {
                    setTimeout(() => {
                        document.getElementById("store-slot-5-upgrade-btn").click();
                    }, 1000)
                }
            }
        }, 1500)
    }
}

document.getElementById("tier-1-table").onclick = function() {
    document.getElementById("fund-farms-table-ui").style.display = "flex";
    document.getElementById("fund-farms-table-ui-2").style.display = "none";
    document.getElementById("fund-farms-table-ui-3").style.display = "none";
    document.getElementById("farm-tiers-ui").style.display = "none";
}