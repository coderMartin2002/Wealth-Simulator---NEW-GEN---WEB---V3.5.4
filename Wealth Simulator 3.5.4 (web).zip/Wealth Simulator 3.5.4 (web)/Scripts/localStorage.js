function autoSave() {
    if (sessionStorage.getItem("skip-next-auto-save") === "1") {
        sessionStorage.removeItem("skip-next-auto-save");
        return;
    }

    // LOANS

    localStorage.setItem("registered_loans", JSON.stringify(registered_loans_storage));
    localStorage.setItem("registered_loan_slots", JSON.stringify(registered_loan_slots_storage));

    // MOD INSTALLATION STATUSES

    localStorage.setItem("mod-1-installed", JSON.stringify(mod_1_installed));
    localStorage.setItem("mod-2-installed", JSON.stringify(mod_2_installed));
    localStorage.setItem("mod-3-installed", JSON.stringify(mod_3_installed));

    localStorage.setItem("quick-collect-perk-owned", JSON.stringify(quick_collect_perk_owned));
    localStorage.setItem("modifiers-unlocked-notified", JSON.stringify(modifiersUnlockedNotified));

    // TRIVIA

    localStorage.setItem("trivia-high-score", JSON.stringify(user_trivia_high_score));

    // TASKS

    localStorage.setItem("total-tasks-completed", JSON.stringify(total_tasks_completed));

    localStorage.setItem("task-1-progress-bar-value", JSON.stringify(task_1_progress_bar.value))
    localStorage.setItem("task-2-progress-bar-value", JSON.stringify(task_2_progress_bar.value))
    localStorage.setItem("task-3-progress-bar-value", JSON.stringify(task_3_progress_bar.value))
    localStorage.setItem("task-4-progress-bar-value", JSON.stringify(task_4_progress_bar.value))
    localStorage.setItem("task-5-progress-bar-value", JSON.stringify(task_5_progress_bar.value))
    localStorage.setItem("task-6-progress-bar-value", JSON.stringify(task_6_progress_bar.value))
    localStorage.setItem("task-7-progress-bar-value", JSON.stringify(task_7_progress_bar.value))

    localStorage.setItem("task-1-progress-value", JSON.stringify(task_1_progress));
    localStorage.setItem("task-2-progress-value", JSON.stringify(task_2_progress));
    localStorage.setItem("task-3-progress-value", JSON.stringify(task_3_progress));
    localStorage.setItem("task-4-progress-value", JSON.stringify(task_4_progress));
    localStorage.setItem("task-5-progress-value", JSON.stringify(task_5_progress));
    localStorage.setItem("task-6-progress-value", JSON.stringify(task_6_progress));
    localStorage.setItem("task-7-progress-value", JSON.stringify(task_7_progress));

    localStorage.setItem("task-1-active-status", JSON.stringify(task_1_active));
    localStorage.setItem("task-2-active-status", JSON.stringify(task_2_active));
    localStorage.setItem("task-3-active-status", JSON.stringify(task_3_active));
    localStorage.setItem("task-4-active-status", JSON.stringify(task_4_active));
    localStorage.setItem("task-5-active-status", JSON.stringify(task_5_active));
    localStorage.setItem("task-6-active-status", JSON.stringify(task_6_active));
    localStorage.setItem("task-7-active-status", JSON.stringify(task_7_active));

    localStorage.setItem("task-1-completion-status", JSON.stringify(task_1_completion_status));
    localStorage.setItem("task-2-completion-status", JSON.stringify(task_2_completion_status));
    localStorage.setItem("task-3-completion-status", JSON.stringify(task_3_completion_status));
    localStorage.setItem("task-4-completion-status", JSON.stringify(task_4_completion_status));
    localStorage.setItem("task-5-completion-status", JSON.stringify(task_5_completion_status));
    localStorage.setItem("task-6-completion-status", JSON.stringify(task_6_completion_status));
    localStorage.setItem("task-7-completion-status", JSON.stringify(task_7_completion_status));

    localStorage.setItem("task-1-claim-award-status", JSON.stringify(task_1_claim_status));
    localStorage.setItem("task-2-claim-award-status", JSON.stringify(task_2_claim_status));
    localStorage.setItem("task-3-claim-award-status", JSON.stringify(task_3_claim_status));
    localStorage.setItem("task-4-claim-award-status", JSON.stringify(task_4_claim_status));
    localStorage.setItem("task-5-claim-award-status", JSON.stringify(task_5_claim_status));
    localStorage.setItem("task-6-claim-award-status", JSON.stringify(task_6_claim_status));
    localStorage.setItem("task-7-claim-award-status", JSON.stringify(task_7_claim_status));

    // CONSOLE USED PIN STATUSES

    localStorage.setItem("c_p_1", JSON.stringify(c_p_1));
    localStorage.setItem("c_p_2", JSON.stringify(c_p_2));
    localStorage.setItem("c_p_3", JSON.stringify(c_p_3));

    localStorage.setItem("c_p_1_used", JSON.stringify(c_p_1_used));
    localStorage.setItem("c_p_2_used", JSON.stringify(c_p_2_used));
    localStorage.setItem("c_p_3_used", JSON.stringify(c_p_3_used));

    // PLAYER LVL STATS

    localStorage.setItem("player-lvl", JSON.stringify(player_lvl));
    localStorage.setItem("player-lvl-progress-max", JSON.stringify(player_lvl_progress_max));
    localStorage.setItem("player-lvl-progress-value", JSON.stringify(player_lvl_progress_value));
    localStorage.setItem("next-lvl-req", JSON.stringify(next_lvl_req));
    localStorage.setItem("def-lvl-up-cash-award", JSON.stringify(def_lvl_up_cash_award));
    localStorage.setItem("def-lvl-up-coin-award", JSON.stringify(def_lvl_up_coin_award));


    // PLAYTIME STATS

    localStorage.setItem("playtime-hours", JSON.stringify(playtime_hours));
    localStorage.setItem("playtime-minutes", JSON.stringify(playtime_minutes));
    localStorage.setItem("playtime-seconds", JSON.stringify(playtime_seconds));
    localStorage.setItem("playtime-total", JSON.stringify(total_playtime));

    // PROGRESS UI STATS

    localStorage.setItem("fund-farm-click-count", JSON.stringify(total_fund_farm_clicks));
    localStorage.setItem("fund-farm-cash-earned", JSON.stringify(total_fund_farm_cash_earned));
    localStorage.setItem("guessing-matches-won", JSON.stringify(total_guessing_matches_won));
    localStorage.setItem("guessing-matches-lost", JSON.stringify(total_guessing_matches_lost));
    localStorage.setItem("guessing-matches-cash-earned", JSON.stringify(total_guessing_matches_cash_earned));
    localStorage.setItem("total-spins", JSON.stringify(total_spins));
    localStorage.setItem("total-spins-cash-earned", JSON.stringify(total_spins_cash_earned));
    localStorage.setItem("total-spins-cash-lost", JSON.stringify(total_spins_cash_lost));
    localStorage.setItem("777's-jackpots-won", JSON.stringify(total_777_jackpots_won_counter));
    localStorage.setItem("wild-bonuses-won", JSON.stringify(total_wild_bonus_won_counter));
    localStorage.setItem("triple-wilds-won", JSON.stringify(total_triple_wilds_won_counter));
    localStorage.setItem("triple-stars-won", JSON.stringify(total_triple_stars_won_counter));
    localStorage.setItem("free-spins-won", JSON.stringify(free_spins_won_counter));

    // TRIVIA STATS

    localStorage.setItem("total-trivia-matches", JSON.stringify(total_trivia_matches));
    localStorage.setItem("total-correct-answers", JSON.stringify(total_correct_answers));
    localStorage.setItem("total-incorrect-answers", JSON.stringify(total_incorrect_answers));
    localStorage.setItem("total-answer-reveals-purchased", JSON.stringify(total_answer_reveals_purchased));
    localStorage.setItem("total-easy-matches", JSON.stringify(total_easy_matches));
    localStorage.setItem("total-medium-matches", JSON.stringify(total_medium_matches));
    localStorage.setItem("total-hard-matches", JSON.stringify(total_hard_matches));
    localStorage.setItem("total-timed-matches", JSON.stringify(total_timed_matches));

    // MAIN BALANCES

    localStorage.setItem("booster-tokens-balance", JSON.stringify(player_booster_tokens));
    localStorage.setItem("cash-balance", JSON.stringify(player_cash_balance));
    localStorage.setItem("passive-income-pool", JSON.stringify(total_passive_income_pool));
    localStorage.setItem("coins-balance", JSON.stringify(player_coins_balance));
    localStorage.setItem("diamonds-balance", JSON.stringify(player_diamond_balance));
    localStorage.setItem("tycoon-score", JSON.stringify(player_tycoon_score));
    localStorage.setItem("savings-balance", JSON.stringify(player_savings_balance));

    // BANK STATS

    localStorage.setItem("loan-debt", JSON.stringify(current_loan_debt));
    localStorage.setItem("loan-debt-limit", JSON.stringify(current_loan_debt_limit));
    

    // BOOSTERS

    localStorage.setItem("double-income-boosters", JSON.stringify(inventory_slot_1_player_owned_amount));
    localStorage.setItem("triple-income-boosters", JSON.stringify(inventory_slot_2_player_owned_amount));
    localStorage.setItem("double-farm-speed-boosters", JSON.stringify(inventory_slot_3_player_owned_amount));
    localStorage.setItem("poly-farm-speed-boosters", JSON.stringify(inventory_slot_8_player_owned_amount));
    localStorage.setItem("double-extra-wilds-boosters", JSON.stringify(inventory_slot_4_player_owned_amount));
    localStorage.setItem("wild-bonus-boosters", JSON.stringify(inventory_slot_5_player_owned_amount));
    localStorage.setItem("free-spins-bonus-boosters", JSON.stringify(inventory_slot_10_player_owned_amount));
    localStorage.setItem("instant-xp-boosters", JSON.stringify(inventory_slot_6_player_owned_amount));
    localStorage.setItem("double-lvl-xp-boosters", JSON.stringify(inventory_slot_7_player_owned_amount));
    localStorage.setItem("mystery-boosters", JSON.stringify(inventory_slot_9_player_owned_amount));
    localStorage.setItem("last-life-boosters", JSON.stringify(inventory_slot_11_player_owned_amount));
    localStorage.setItem("game-changer-boosters", JSON.stringify(inventory_slot_12_player_owned_amount));
    localStorage.setItem("free-spree-boosters", JSON.stringify(inventory_slot_13_player_owned_amount));

    // FARM COLLECTION PROGRESs

    localStorage.setItem("farm-1-progress", JSON.stringify(farm_1_progress_bar.value));
    localStorage.setItem("farm-2-progress", JSON.stringify(farm_2_progress_bar.value));
    localStorage.setItem("farm-3-progress", JSON.stringify(farm_3_progress_bar.value));
    localStorage.setItem("farm-4-progress", JSON.stringify(farm_4_progress_bar.value)); 
    localStorage.setItem("farm-5-progress", JSON.stringify(farm_5_progress_bar.value));
    localStorage.setItem("farm-6-progress", JSON.stringify(farm_6_progress_bar.value));

    localStorage.setItem("tier-2-farm-1-progress", JSON.stringify(tier_2_farm_1_progress_bar.value));
    localStorage.setItem("tier-2-farm-2-progress", JSON.stringify(tier_2_farm_2_progress_bar.value));
    localStorage.setItem("tier-2-farm-3-progress", JSON.stringify(tier_2_farm_3_progress_bar.value));
    localStorage.setItem("tier-2-farm-4-progress", JSON.stringify(tier_2_farm_4_progress_bar.value)); 
    localStorage.setItem("tier-2-farm-5-progress", JSON.stringify(tier_2_farm_5_progress_bar.value));
    localStorage.setItem("tier-2-farm-6-progress", JSON.stringify(tier_2_farm_6_progress_bar.value));

    localStorage.setItem("tier-3-farm-1-progress", JSON.stringify(tier_3_farm_1_progress_bar.value));
    localStorage.setItem("tier-3-farm-2-progress", JSON.stringify(tier_3_farm_2_progress_bar.value));
    localStorage.setItem("tier-3-farm-3-progress", JSON.stringify(tier_3_farm_3_progress_bar.value));
    localStorage.setItem("tier-3-farm-4-progress", JSON.stringify(tier_3_farm_4_progress_bar.value)); 
    localStorage.setItem("tier-3-farm-5-progress", JSON.stringify(tier_3_farm_5_progress_bar.value));
    localStorage.setItem("tier-3-farm-6-progress", JSON.stringify(tier_3_farm_6_progress_bar.value));

    // FARM AUTO COLLECT STATS / STATES

    localStorage.setItem("farm-1-auto-collect-state", JSON.stringify(farm_1_auto_state));
    localStorage.setItem("farm-2-auto-collect-state", JSON.stringify(farm_2_auto_state));
    localStorage.setItem("farm-3-auto-collect-state", JSON.stringify(farm_3_auto_state));
    localStorage.setItem("farm-4-auto-collect-state", JSON.stringify(farm_4_auto_state));
    localStorage.setItem("farm-5-auto-collect-state", JSON.stringify(farm_5_auto_state));
    localStorage.setItem("farm-6-auto-collect-state", JSON.stringify(farm_6_auto_state));

    localStorage.setItem("tier-2-farm-1-auto-collect-state", JSON.stringify(tier_2_farm_1_auto_state));
    localStorage.setItem("tier-2-farm-2-auto-collect-state", JSON.stringify(tier_2_farm_2_auto_state));
    localStorage.setItem("tier-2-farm-3-auto-collect-state", JSON.stringify(tier_2_farm_3_auto_state));
    localStorage.setItem("tier-2-farm-4-auto-collect-state", JSON.stringify(tier_2_farm_4_auto_state));
    localStorage.setItem("tier-2-farm-5-auto-collect-state", JSON.stringify(tier_2_farm_5_auto_state));
    localStorage.setItem("tier-2-farm-6-auto-collect-state", JSON.stringify(tier_2_farm_6_auto_state));

    localStorage.setItem("tier-3-farm-1-auto-collect-state", JSON.stringify(tier_3_farm_1_auto_state));
    localStorage.setItem("tier-3-farm-2-auto-collect-state", JSON.stringify(tier_3_farm_2_auto_state));
    localStorage.setItem("tier-3-farm-3-auto-collect-state", JSON.stringify(tier_3_farm_3_auto_state));
    localStorage.setItem("tier-3-farm-4-auto-collect-state", JSON.stringify(tier_3_farm_4_auto_state));
    localStorage.setItem("tier-3-farm-5-auto-collect-state", JSON.stringify(tier_3_farm_5_auto_state));
    localStorage.setItem("tier-3-farm-6-auto-collect-state", JSON.stringify(tier_3_farm_6_auto_state));

    localStorage.setItem("tier-2-farm-unlocked", JSON.stringify(tier_2_farm_unlocked));
    localStorage.setItem("tier-3-farm-unlocked", JSON.stringify(tier_3_farm_unlocked));

    // STORE UPGRADES / PERKS / LEVELS / PASSIVE INCOME STATS

    localStorage.setItem("store-slot-1-passive-income-pool-grant-int", JSON.stringify(passive_income_grant_int));
    localStorage.setItem("store-slot-1-passive-income-upgrade-int-reduction-percent", JSON.stringify(store_slot_1_passive_income_cashout_int_reduction_percent));
    localStorage.setItem("store-slot-1-passive-income-upgrade-int-reduction-lvl", JSON.stringify(store_slot_1_passive_income_cashout_int_reduction_lvl));
    localStorage.setItem("store-slot-1-passive-income-upgrade-int-reduction-price", JSON.stringify(store_slot_1_passive_income_cashout_int_reduction_price));
    localStorage.setItem("store-slot-1-passive-income-upgrade-max-level-state", JSON.stringify(store_slot_1_upgrade_max_lvl_state));
    localStorage.setItem("store-slot-1-passive-income-cashout-int-reduction-percent-output", JSON.stringify(store_slot_1_passive_income_cashout_int_reduction_percent_output));
    localStorage.setItem("store-slot-1-passive-income-cashout-int-reduction-seconds-output", JSON.stringify(store_slot_1_passive_income_cashout_int_reduction_seconds_output));

}

function autoLoad() {
    // LOANS

    let savedRegisteredLoans = localStorage.getItem("registered_loans");
    let savedRegisteredLoanSlots = localStorage.getItem("registered_loan_slots");

    let savedMod1InstallationStatus = localStorage.getItem("mod-1-installed");
    let savedMod2InstallationStatus = localStorage.getItem("mod-2-installed");
    let savedMod3InstallationStatus = localStorage.getItem("mod-3-installed");

    let savedQuickCollectPerkOwned = localStorage.getItem("quick-collect-perk-owned");
    let savedModifiersUnlockedNotified = localStorage.getItem("modifiers-unlocked-notified");

    let savedTriviaHighScore = localStorage.getItem("trivia-high-score");

    let savedTotalTasksCompleted = localStorage.getItem("total-tasks-completed");

    // TASK PRGRESS + COMPLETE STATES
    
    let savedTask1ProgressBarValue = localStorage.getItem("task-1-progress-bar-value");
    let savedTask2ProgressBarValue = localStorage.getItem("task-2-progress-bar-value");
    let savedTask3ProgressBarValue = localStorage.getItem("task-3-progress-bar-value");
    let savedTask4ProgressBarValue = localStorage.getItem("task-4-progress-bar-value");
    let savedTask5ProgressBarValue = localStorage.getItem("task-5-progress-bar-value");
    let savedTask6ProgressBarValue = localStorage.getItem("task-6-progress-bar-value");
    let savedTask7ProgressBarValue = localStorage.getItem("task-7-progress-bar-value");

    let savedTask1ProgressValue = localStorage.getItem("task-1-progress-value");
    let savedTask2ProgressValue = localStorage.getItem("task-2-progress-value");
    let savedTask3ProgressValue = localStorage.getItem("task-3-progress-value");
    let savedTask4ProgressValue = localStorage.getItem("task-4-progress-value");
    let savedTask5ProgressValue = localStorage.getItem("task-5-progress-value");
    let savedTask6ProgressValue = localStorage.getItem("task-6-progress-value");
    let savedTask7ProgressValue = localStorage.getItem("task-7-progress-value");

    let savedTask1ActiveStatus = localStorage.getItem("task-1-active-status");
    let savedTask2ActiveStatus = localStorage.getItem("task-2-active-status");
    let savedTask3ActiveStatus = localStorage.getItem("task-3-active-status");
    let savedTask4ActiveStatus = localStorage.getItem("task-4-active-status");
    let savedTask5ActiveStatus = localStorage.getItem("task-5-active-status");
    let savedTask6ActiveStatus = localStorage.getItem("task-6-active-status");
    let savedTask7ActiveStatus = localStorage.getItem("task-7-active-status");

    let savedTask1CompletionStatus = localStorage.getItem("task-1-completion-status");
    let savedTask2CompletionStatus = localStorage.getItem("task-2-completion-status");
    let savedTask3CompletionStatus = localStorage.getItem("task-3-completion-status");
    let savedTask4CompletionStatus = localStorage.getItem("task-4-completion-status");
    let savedTask5CompletionStatus = localStorage.getItem("task-5-completion-status");
    let savedTask6CompletionStatus = localStorage.getItem("task-6-completion-status");
    let savedTask7CompletionStatus = localStorage.getItem("task-7-completion-status");

    let savedTask1ClaimAwardStatus = localStorage.getItem("task-1-claim-award-status");
    let savedTask2ClaimAwardStatus = localStorage.getItem("task-2-claim-award-status");
    let savedTask3ClaimAwardStatus = localStorage.getItem("task-3-claim-award-status");
    let savedTask4ClaimAwardStatus = localStorage.getItem("task-4-claim-award-status");
    let savedTask5ClaimAwardStatus = localStorage.getItem("task-5-claim-award-status");
    let savedTask6ClaimAwardStatus = localStorage.getItem("task-6-claim-award-status");
    let savedTask7ClaimAwardStatus = localStorage.getItem("task-7-claim-award-status");

    // USED CONSOLE PIN STATUSES

    let savedCP1Used = localStorage.getItem("c_p_1_used");
    let savedCP2Used = localStorage.getItem("c_p_2_used");
    let savedCP3Used = localStorage.getItem("c_p_3_used");
    let savedCP1 = localStorage.getItem("c_p_1");
    let savedCP2 = localStorage.getItem("c_p_2");
    let savedCP3 = localStorage.getItem("c_p_3")

    // LVL STATS

    let savedPlayerLvl = localStorage.getItem("player-lvl");
    let savedPlayerLvlProgressMax = localStorage.getItem("player-lvl-progress-max");
    let savedPlayerLvlProgressValue = localStorage.getItem("player-lvl-progress-value");
    let savedNextLvlReq = localStorage.getItem("next-lvl-req");
    let savedDefLvlUpCashAward = localStorage.getItem("def-lvl-up-cash-award");
    let savedDefLvlUpCoinAward = localStorage.getItem("def-lvl-up-coin-award");

    let savedPlaytimeHours = localStorage.getItem("playtime-hours");
    let savedPlaytimeMinutes = localStorage.getItem("playtime-minutes");
    let savedPlaytimeSeconds = localStorage.getItem("playtime-seconds");
    let savedPlaytimeTotal = localStorage.getItem("playtime-total");

    // WEALTH FARMS AUTO COLLECT STATES

    let savedFarm1AutoCollectState = localStorage.getItem("farm-1-auto-collect-state");
    let savedFarm2AutoCollectState = localStorage.getItem("farm-2-auto-collect-state");
    let savedFarm3AutoCollectState = localStorage.getItem("farm-3-auto-collect-state");
    let savedFarm4AutoCollectState = localStorage.getItem("farm-4-auto-collect-state");
    let savedFarm5AutoCollectState = localStorage.getItem("farm-5-auto-collect-state");
    let savedFarm6AutoCollectState = localStorage.getItem("farm-6-auto-collect-state");

    let savedTier2Farm1AutoCollectState = localStorage.getItem("tier-2-farm-1-auto-collect-state");
    let savedTier2Farm2AutoCollectState = localStorage.getItem("tier-2-farm-2-auto-collect-state");
    let savedTier2Farm3AutoCollectState = localStorage.getItem("tier-2-farm-3-auto-collect-state");
    let savedTier2Farm4AutoCollectState = localStorage.getItem("tier-2-farm-4-auto-collect-state");
    let savedTier2Farm5AutoCollectState = localStorage.getItem("tier-2-farm-5-auto-collect-state");
    let savedTier2Farm6AutoCollectState = localStorage.getItem("tier-2-farm-6-auto-collect-state");

    let savedTier3Farm1AutoCollectState = localStorage.getItem("tier-3-farm-1-auto-collect-state");
    let savedTier3Farm2AutoCollectState = localStorage.getItem("tier-3-farm-2-auto-collect-state");
    let savedTier3Farm3AutoCollectState = localStorage.getItem("tier-3-farm-3-auto-collect-state");
    let savedTier3Farm4AutoCollectState = localStorage.getItem("tier-3-farm-4-auto-collect-state");
    let savedTier3Farm5AutoCollectState = localStorage.getItem("tier-3-farm-5-auto-collect-state");
    let savedTier3Farm6AutoCollectState = localStorage.getItem("tier-3-farm-6-auto-collect-state");

    let savedTier2FarmUnlocked = localStorage.getItem("tier-2-farm-unlocked");
    let savedTier3FarmUnlocked = localStorage.getItem("tier-3-farm-unlocked");

    // PROGRESS HUB STATS

    let savedFundFarmClicks = localStorage.getItem("fund-farm-click-count");
    let savedFundFarmCashEarned = localStorage.getItem("fund-farm-cash-earned");
    let savedGuessingMatchesWon = localStorage.getItem("guessing-matches-won");
    let savedGuessingMatchesLost = localStorage.getItem("guessing-matches-lost");
    let savedGuessingMatchesCashEarned = localStorage.getItem("guessing-matches-cash-earned");
    let savedTotalSpins = localStorage.getItem("total-spins");
    let savedTotalSpinsCashEarned = localStorage.getItem("total-spins-cash-earned");
    let savedTotalSpinsCashLost = localStorage.getItem("total-spins-cash-lost");
    let saved777JackpotsWon = localStorage.getItem("777's-jackpots-won");
    let savedWildBonusesWon = localStorage.getItem("wild-bonuses-won");
    let savedTripleWildsWon = localStorage.getItem("triple-wilds-won");
    let savedTripleStarsWon = localStorage.getItem("triple-stars-won");
    let savedFreeSpinsWon = localStorage.getItem("free-spins-won");

    let savedTotalTriviaMatches = localStorage.getItem("total-trivia-matches");
    let savedTotalCorrectAnswers = localStorage.getItem("total-correct-answers");
    let savedTotalIncorrectAnswers = localStorage.getItem("total-incorrect-answers");
    let savedTotalAnswerRevealsPurchased = localStorage.getItem("total-answer-reveals-purchased");
    let savedTotalEasyMatches = localStorage.getItem("total-easy-matches");
    let savedTotalMediumMatches = localStorage.getItem("total-medium-matches");
    let savedTotalHardMatches = localStorage.getItem("total-hard-matches");
    let savedTotalTimedMatches = localStorage.getItem("total-timed-matches");

    // MAIN BALANCES

    let savedSavingsBalance = localStorage.getItem("savings-balance");
    let savedCash = localStorage.getItem("cash-balance");
    let savedPassiveIncomePool = localStorage.getItem("passive-income-pool");
    let savedCoins = localStorage.getItem("coins-balance");
    let savedDiamonds = localStorage.getItem("diamonds-balance");
    let savedTycoonScore = localStorage.getItem("tycoon-score");
    let savedBoosterTokens = localStorage.getItem("booster-tokens-balance");

    // BANK STATS

    let savedLoanDebt = localStorage.getItem("loan-debt");
    let savedLoanDebtLimit = localStorage.getItem("loan-debt-limit");

    // BOOSTERS

    let savedDoubleIncomeBoosters = localStorage.getItem("double-income-boosters");
    let savedTripleIncomeBoosters = localStorage.getItem("triple-income-boosters");
    let savedDoubleFarmSpeedBoosters = localStorage.getItem("double-farm-speed-boosters");
    let savedPolyFarmSpeedBoosters = localStorage.getItem("poly-farm-speed-boosters");
    let savedDoubleExtraWildsBoosters = localStorage.getItem("double-extra-wilds-boosters");
    let savedWildBonusBoosters = localStorage.getItem("wild-bonus-boosters");
    let savedFreeSpinsBonusBoosters = localStorage.getItem("free-spins-bonus-boosters");
    let savedInstantXPBoosters = localStorage.getItem("instant-xp-boosters");
    let savedDoubleLvlXPBoosters = localStorage.getItem("double-lvl-xp-boosters");
    let savedMysteryBoosters = localStorage.getItem("mystery-boosters");
    let savedLastLifeBoosters = localStorage.getItem("last-life-boosters");
    let savedGameChangerBoosters = localStorage.getItem("game-changer-boosters");
    let savedFreeSpreeBoosters = localStorage.getItem("free-spree-boosters");

    // TIER 1 FARMS

    let savedFarm1Progress = localStorage.getItem("farm-1-progress");
    let savedFarm2Progress = localStorage.getItem("farm-2-progress");
    let savedFarm3Progress = localStorage.getItem("farm-3-progress");
    let savedFarm4Progress = localStorage.getItem("farm-4-progress");
    let savedFarm5Progress = localStorage.getItem("farm-5-progress");
    let savedFarm6Progress = localStorage.getItem("farm-6-progress");

    // TIER 2 FUND FARMS

    let savedTier2Farm1Progress = localStorage.getItem("tier-2-farm-1-progress");
    let savedTier2Farm2Progress = localStorage.getItem("tier-2-farm-2-progress");
    let savedTier2Farm3Progress = localStorage.getItem("tier-2-farm-3-progress");
    let savedTier2Farm4Progress = localStorage.getItem("tier-2-farm-4-progress");
    let savedTier2Farm5Progress = localStorage.getItem("tier-2-farm-5-progress");
    let savedTier2Farm6Progress = localStorage.getItem("tier-2-farm-6-progress");

    // TIER 3 COIN FARMS

    let savedTier3Farm1Progress = localStorage.getItem("tier-3-farm-1-progress");
    let savedTier3Farm2Progress = localStorage.getItem("tier-3-farm-2-progress");
    let savedTier3Farm3Progress = localStorage.getItem("tier-3-farm-3-progress");
    let savedTier3Farm4Progress = localStorage.getItem("tier-3-farm-4-progress");
    let savedTier3Farm5Progress = localStorage.getItem("tier-3-farm-5-progress");
    let savedTier3Farm6Progress = localStorage.getItem("tier-3-farm-6-progress");

    let savedPassiveIncomeGrantInt = localStorage.getItem("store-slot-1-passive-income-pool-grant-int");
    let savedPassiveIncomeUpgradeLvl = localStorage.getItem("store-slot-1-passive-income-upgrade-int-reduction-lvl");
    let savedPassiveIncomeUpgradePercent = localStorage.getItem("store-slot-1-passive-income-upgrade-int-reduction-percent");
    let savedPassiveIncomeUpgradePrice = localStorage.getItem("store-slot-1-passive-income-upgrade-int-reduction-price");
    let savedPassiveIncomeUpgradeMaxLevelState = localStorage.getItem("store-slot-1-passive-income-upgrade-max-level-state");
    let savedPassiveIncomeCashoutIntReductionPercentOutput = localStorage.getItem("store-slot-1-passive-income-cashout-int-reduction-percent-output");
    let savedPassiveIncomeCashoutIntReductionSecondsOutput = localStorage.getItem("store-slot-1-passive-income-cashout-int-reduction-seconds-output");

    // LOANS

    if (savedRegisteredLoans !== null) {
        registered_loans_storage = JSON.parse(savedRegisteredLoans);
    }
    if (savedRegisteredLoanSlots !== null) {
        registered_loan_slots_storage = JSON.parse(savedRegisteredLoanSlots);
    }

    if (savedMod1InstallationStatus !== null) {
        mod_1_installed = JSON.parse(savedMod1InstallationStatus);
    }

    if (savedMod2InstallationStatus !== null) {
        mod_2_installed = JSON.parse(savedMod2InstallationStatus);
    }

    if (savedMod3InstallationStatus !== null) {
        mod_3_installed = JSON.parse(savedMod3InstallationStatus);
    }

    if (savedQuickCollectPerkOwned !== null) {
        quick_collect_perk_owned = JSON.parse(savedQuickCollectPerkOwned);
    }

    if (savedModifiersUnlockedNotified !== null) {
        modifiersUnlockedNotified = JSON.parse(savedModifiersUnlockedNotified);
    }

    if (savedTotalCorrectAnswers !== null) {
        total_correct_answers = JSON.parse(savedTotalCorrectAnswers);
    }

    if (savedTotalIncorrectAnswers !== null) {
        total_incorrect_answers = JSON.parse(savedTotalIncorrectAnswers);
    }

    if (savedTriviaHighScore !== null) {
        user_trivia_high_score = JSON.parse(savedTriviaHighScore);
    }

    if (savedTier2FarmUnlocked !== null) {
        tier_2_farm_unlocked = JSON.parse(savedTier2FarmUnlocked);
    }

    if (savedTier3FarmUnlocked !== null) {
        tier_3_farm_unlocked = JSON.parse(savedTier3FarmUnlocked);
    }

    if (savedTotalTasksCompleted !== null) {
        total_tasks_completed = JSON.parse(savedTotalTasksCompleted);
    }

    if (savedTask1ProgressBarValue !== null) {
        task_1_progress_bar.value = JSON.parse(savedTask1ProgressBarValue);
    }
    if (savedTask2ProgressBarValue !== null) {
        task_2_progress_bar.value = JSON.parse(savedTask2ProgressBarValue);
    }
    if (savedTask3ProgressBarValue !== null) {
        task_3_progress_bar.value = JSON.parse(savedTask3ProgressBarValue);
    }
    if (savedTask4ProgressBarValue !== null) {
        task_4_progress_bar.value = JSON.parse(savedTask4ProgressBarValue);
    }
    if (savedTask5ProgressBarValue !== null) {
        task_5_progress_bar.value = JSON.parse(savedTask5ProgressBarValue);
    }
    if (savedTask6ProgressBarValue !== null) {
        task_6_progress_bar.value = JSON.parse(savedTask6ProgressBarValue);
    }
    if (savedTask7ProgressBarValue !== null) {
        task_7_progress_bar.value = JSON.parse(savedTask7ProgressBarValue);
    }

    if (savedTask1ProgressValue !== null) {
        task_1_progress = JSON.parse(savedTask1ProgressValue);
    }
    if (savedTask2ProgressValue !== null) {
        task_2_progress = JSON.parse(savedTask2ProgressValue);
    }
    if (savedTask3ProgressValue !== null) {
        task_3_progress = JSON.parse(savedTask3ProgressValue);
    }
    if (savedTask4ProgressValue !== null) {
        task_4_progress = JSON.parse(savedTask4ProgressValue);
    }
    if (savedTask5ProgressValue !== null) {
        task_5_progress = JSON.parse(savedTask5ProgressValue);
    }
    if (savedTask6ProgressValue !== null) {
        task_6_progress = JSON.parse(savedTask6ProgressValue);
    }
    if (savedTask7ProgressValue !== null) {
        task_7_progress = JSON.parse(savedTask7ProgressValue);
    }

    if (savedTask1ActiveStatus !== null) {
        task_1_active = JSON.parse(savedTask1ActiveStatus);
    }
    if (savedTask2ActiveStatus !== null) {
        task_2_active = JSON.parse(savedTask2ActiveStatus);
    }
    if (savedTask3ActiveStatus !== null) {
        task_3_active = JSON.parse(savedTask3ActiveStatus);
    }
    if (savedTask4ActiveStatus !== null) {
        task_4_active = JSON.parse(savedTask4ActiveStatus);
    }
    if (savedTask5ActiveStatus !== null) {
        task_5_active = JSON.parse(savedTask5ActiveStatus);
    }
    if (savedTask6ActiveStatus !== null) {
        task_6_active = JSON.parse(savedTask6ActiveStatus);
    }
    if (savedTask7ActiveStatus !== null) {
        task_7_active = JSON.parse(savedTask7ActiveStatus);
    }

    if (savedTask1CompletionStatus !== null) {
        task_1_completion_status = JSON.parse(savedTask1CompletionStatus);
    }
    if (savedTask2CompletionStatus !== null) {
        task_2_completion_status = JSON.parse(savedTask2CompletionStatus);
    }
    if (savedTask3CompletionStatus !== null) {
        task_3_completion_status = JSON.parse(savedTask3CompletionStatus);
    }
    if (savedTask4CompletionStatus !== null) {
        task_4_completion_status = JSON.parse(savedTask4CompletionStatus);
    }
    if (savedTask5CompletionStatus !== null) {
        task_5_completion_status = JSON.parse(savedTask5CompletionStatus);
    }
    if (savedTask6CompletionStatus !== null) {
        task_6_completion_status = JSON.parse(savedTask6CompletionStatus);
    }
    if (savedTask7CompletionStatus !== null) {
        task_7_completion_status = JSON.parse(savedTask7CompletionStatus);
    }

    if (savedTask1ClaimAwardStatus !== null) {
        task_1_claim_status = JSON.parse(savedTask1ClaimAwardStatus);
    }
    if (savedTask2ClaimAwardStatus !== null) {
        task_2_claim_status = JSON.parse(savedTask2ClaimAwardStatus);
    }
    if (savedTask3ClaimAwardStatus !== null) {
        task_3_claim_status = JSON.parse(savedTask3ClaimAwardStatus);
    }
    if (savedTask4ClaimAwardStatus !== null) {
        task_4_claim_status = JSON.parse(savedTask4ClaimAwardStatus);
    }
    if (savedTask5ClaimAwardStatus !== null) {
        task_5_claim_status = JSON.parse(savedTask5ClaimAwardStatus);
    }
    if (savedTask6ClaimAwardStatus !== null) {
        task_6_claim_status = JSON.parse(savedTask6ClaimAwardStatus);
    }
    if (savedTask7ClaimAwardStatus !== null) {
        task_7_claim_status = JSON.parse(savedTask7ClaimAwardStatus);
    }

    // OTP's (console)

    if (savedCP1Used !== null) {
        c_p_1_used = JSON.parse(savedCP1Used);
    }
    if (savedCP2Used !== null) {
        c_p_2_used = JSON.parse(savedCP2Used);
    }
    if (savedCP3Used !== null) {
        c_p_3_used = JSON.parse(savedCP3Used);
    }

    if (savedCP1 !== null) {
        c_p_1 = JSON.parse(savedCP1);
    }
    if (savedCP2 !== null) {
        c_p_2 = JSON.parse(savedCP2);
    }
    if (savedCP3 !== null) {
        c_p_3 = JSON.parse(savedCP3);
    }

    // PLAYER LVL STATS

    if (savedPlayerLvl !== null) {
        player_lvl = JSON.parse(savedPlayerLvl);
    }
    if (savedPlayerLvlProgressMax !== null) {
        player_lvl_progress_max = JSON.parse(savedPlayerLvlProgressMax);
        player_lvl_progress_bar_value.max = player_lvl_progress_max;
    }
    if (savedPlayerLvlProgressValue !== null) {
        player_lvl_progress_value = JSON.parse(savedPlayerLvlProgressValue);
        updatePlayerLvlProgressUI();
    }
    if (savedNextLvlReq !== null) {
        next_lvl_req = JSON.parse(savedNextLvlReq);
    }
    if (savedDefLvlUpCashAward !== null) {
        def_lvl_up_cash_award = JSON.parse(savedDefLvlUpCashAward);
    }
    if (savedDefLvlUpCoinAward !== null) {
        def_lvl_up_coin_award = JSON.parse(savedDefLvlUpCoinAward);
    }

    if (typeof processPlayerLvlOverflow === "function") {
        processPlayerLvlOverflow();
    }

    if (savedPlaytimeHours !== null) {
        playtime_hours = JSON.parse(savedPlaytimeHours);
    }
    if (savedPlaytimeMinutes !== null) {
        playtime_minutes = JSON.parse(savedPlaytimeMinutes);
    }
    if (savedPlaytimeSeconds !== null) {
        playtime_seconds = JSON.parse(savedPlaytimeSeconds);
    }
    if (savedPlaytimeTotal !== null) {
        total_playtime = JSON.parse(savedPlaytimeTotal);
        playtime_hours = Math.floor(total_playtime / 3600000);
        playtime_minutes = Math.floor(total_playtime / 60000) % 60;
        playtime_seconds = Math.floor(total_playtime / 1000) % 60;
    }

    if (savedFarm1AutoCollectState !== null) {
        farm_1_auto_state = JSON.parse(savedFarm1AutoCollectState);
    }
    if (savedFarm2AutoCollectState !== null) {
        farm_2_auto_state = JSON.parse(savedFarm2AutoCollectState);
    }
    if (savedFarm3AutoCollectState !== null) {
        farm_3_auto_state = JSON.parse(savedFarm3AutoCollectState);
    }
    if (savedFarm4AutoCollectState !== null) {
        farm_4_auto_state = JSON.parse(savedFarm4AutoCollectState);
    }
    if (savedFarm5AutoCollectState !== null) {
        farm_5_auto_state = JSON.parse(savedFarm5AutoCollectState);
    }
    if (savedFarm6AutoCollectState !== null) {
        farm_6_auto_state = JSON.parse(savedFarm6AutoCollectState);
    }

    if (savedTier2Farm1AutoCollectState !== null) {
        tier_2_farm_1_auto_state = JSON.parse(savedTier2Farm1AutoCollectState);
    }
    if (savedTier2Farm2AutoCollectState !== null) {
        tier_2_farm_2_auto_state = JSON.parse(savedTier2Farm2AutoCollectState);
    }
    if (savedTier2Farm3AutoCollectState !== null) {
        tier_2_farm_3_auto_state = JSON.parse(savedTier2Farm3AutoCollectState);
    }
    if (savedTier2Farm4AutoCollectState !== null) {
        tier_2_farm_4_auto_state = JSON.parse(savedTier2Farm4AutoCollectState);
    }
    if (savedTier2Farm5AutoCollectState !== null) {
        tier_2_farm_5_auto_state = JSON.parse(savedTier2Farm5AutoCollectState);
    }
    if (savedTier2Farm6AutoCollectState !== null) {
        tier_2_farm_6_auto_state = JSON.parse(savedTier2Farm6AutoCollectState);
    }

    if (savedTier3Farm1AutoCollectState !== null) {
        tier_3_farm_1_auto_state = JSON.parse(savedTier3Farm1AutoCollectState);
    }
    if (savedTier3Farm2AutoCollectState !== null) {
        tier_3_farm_2_auto_state = JSON.parse(savedTier3Farm2AutoCollectState);
    }
    if (savedTier3Farm3AutoCollectState !== null) {
        tier_3_farm_3_auto_state = JSON.parse(savedTier3Farm3AutoCollectState);
    }
    if (savedTier3Farm4AutoCollectState !== null) {
        tier_3_farm_4_auto_state = JSON.parse(savedTier3Farm4AutoCollectState);
    }
    if (savedTier3Farm5AutoCollectState !== null) {
        tier_3_farm_5_auto_state = JSON.parse(savedTier3Farm5AutoCollectState);
    }
    if (savedTier3Farm6AutoCollectState !== null) {
        tier_3_farm_6_auto_state = JSON.parse(savedTier3Farm6AutoCollectState);
    }

    if (savedFundFarmClicks !== null) {
        total_fund_farm_clicks = JSON.parse(savedFundFarmClicks);
    }
    if (savedFundFarmCashEarned !== null) {
        total_fund_farm_cash_earned = JSON.parse(savedFundFarmCashEarned);
    }
    if (savedGuessingMatchesWon !== null) {
        total_guessing_matches_won = JSON.parse(savedGuessingMatchesWon);
    }
    if (savedGuessingMatchesLost !== null) {
        total_guessing_matches_lost = JSON.parse(savedGuessingMatchesLost);
    }
    if (savedGuessingMatchesCashEarned !== null) {
        total_guessing_matches_cash_earned = JSON.parse(savedGuessingMatchesCashEarned);
    }
    if (savedTotalSpins !== null) {
        total_spins = JSON.parse(savedTotalSpins);
    }
    if (savedTotalSpinsCashEarned !== null) {
        total_spins_cash_earned = JSON.parse(savedTotalSpinsCashEarned);
    }
    if (savedTotalSpinsCashLost !== null) {
        total_spins_cash_lost = JSON.parse(savedTotalSpinsCashLost);
    }
    if (saved777JackpotsWon !== null) {
        total_777_jackpots_won_counter = JSON.parse(saved777JackpotsWon);
    }
    if (savedWildBonusesWon !== null) {
        total_wild_bonus_won_counter = JSON.parse(savedWildBonusesWon);
    }
    if (savedTripleWildsWon !== null) {
        triple_wilds_won_counter = JSON.parse(savedTripleWildsWon);
    }
    if (savedTripleStarsWon !== null) {
        triple_stars_won_counter = JSON.parse(savedTripleStarsWon);
    }
    if (savedFreeSpinsWon !== null) {
        free_spins_won_counter = JSON.parse(savedWildBonusesWon);
    }


    if (savedTotalTriviaMatches !== null) {
        total_trivia_matches = JSON.parse(savedTotalTriviaMatches);
    }
    if (savedTotalCorrectAnswers !== null) {
        total_correct_answers = JSON.parse(savedTotalCorrectAnswers);
    }
    if (savedTotalIncorrectAnswers !== null) {
        total_incorrect_answers = JSON.parse(savedTotalIncorrectAnswers);
    }
    if (savedTotalAnswerRevealsPurchased !== null) {
        total_answer_reveals_purchased = JSON.parse(savedTotalAnswerRevealsPurchased);
    }
    if (savedTotalEasyMatches !== null) {
        total_easy_matches = JSON.parse(savedTotalEasyMatches);
    }
    if (savedTotalMediumMatches !== null) {
        total_medium_matches = JSON.parse(savedTotalMediumMatches);
    }
    if (savedTotalHardMatches !== null) {
        total_hard_matches = JSON.parse(savedTotalHardMatches);
    }
    if (savedTotalTimedMatches !== null) {
        total_timed_matches = JSON.parse(savedTotalTimedMatches);
    }

    // INVENTORY BOOSTERS

    if (savedDoubleIncomeBoosters !== null) {
        inventory_slot_1_player_owned_amount = JSON.parse(savedDoubleIncomeBoosters);
    }

    if (savedTripleIncomeBoosters !== null) {
        inventory_slot_2_player_owned_amount = JSON.parse(savedTripleIncomeBoosters);
    }
    if (savedDoubleFarmSpeedBoosters !== null) {
        inventory_slot_3_player_owned_amount = JSON.parse(savedDoubleFarmSpeedBoosters);
    }
    if (savedPolyFarmSpeedBoosters !== null) {
        inventory_slot_8_player_owned_amount = JSON.parse(savedPolyFarmSpeedBoosters);
    }
    if (savedDoubleExtraWildsBoosters !== null) {
        inventory_slot_4_player_owned_amount = JSON.parse(savedDoubleExtraWildsBoosters);
    }
    if (savedWildBonusBoosters !== null) {
        inventory_slot_5_player_owned_amount = JSON.parse(savedWildBonusBoosters);
    }
    if (savedFreeSpinsBonusBoosters !== null) {
        inventory_slot_10_player_owned_amount = JSON.parse(savedFreeSpinsBonusBoosters);
    }
    if (savedInstantXPBoosters !== null) {
        inventory_slot_6_player_owned_amount = JSON.parse(savedInstantXPBoosters);
    }
    if (savedDoubleLvlXPBoosters !== null) {
        inventory_slot_7_player_owned_amount = JSON.parse(savedDoubleLvlXPBoosters);
    }
    if (savedMysteryBoosters !== null) {
        inventory_slot_9_player_owned_amount = JSON.parse(savedMysteryBoosters);
    }
    if (savedLastLifeBoosters !== null) {
        inventory_slot_11_player_owned_amount = JSON.parse(savedLastLifeBoosters);
    }
    if (savedGameChangerBoosters !== null) {
        inventory_slot_12_player_owned_amount = JSON.parse(savedGameChangerBoosters);
    }
    if (savedFreeSpreeBoosters !== null) {
        inventory_slot_13_player_owned_amount = JSON.parse(savedFreeSpreeBoosters);
    }

    if (savedPassiveIncomeGrantInt !== null) {
        passive_income_grant_int = JSON.parse(savedPassiveIncomeGrantInt);
    }
    if (savedPassiveIncomeUpgradeLvl !== null) {
        store_slot_1_passive_income_cashout_int_reduction_lvl = JSON.parse(savedPassiveIncomeUpgradeLvl);
    }
    if (savedPassiveIncomeUpgradePercent !== null) {
        store_slot_1_passive_income_cashout_int_reduction_percent = JSON.parse(savedPassiveIncomeUpgradePercent);
    }
    if (savedPassiveIncomeUpgradePrice !== null) {
        store_slot_1_passive_income_cashout_int_reduction_price = JSON.parse(savedPassiveIncomeUpgradePrice);
    }
    if (savedPassiveIncomeUpgradeMaxLevelState !== null) {
        store_slot_1_upgrade_max_lvl_state = JSON.parse(savedPassiveIncomeUpgradeMaxLevelState);
    }
    if (savedPassiveIncomeCashoutIntReductionPercentOutput !== null) {
        store_slot_1_passive_income_cashout_int_reduction_percent_output = JSON.parse(savedPassiveIncomeCashoutIntReductionPercentOutput);
    }
    if (savedPassiveIncomeCashoutIntReductionSecondsOutput !== null) {
        store_slot_1_passive_income_cashout_int_reduction_seconds_output = JSON.parse(savedPassiveIncomeCashoutIntReductionSecondsOutput);
    }

    // MAIN BALANCES

    if (savedSavingsBalance !== null) {
        player_savings_balance = JSON.parse(savedSavingsBalance);
    }

    if (saved777JackpotsWon !== null) {
        player_booster_tokens = JSON.parse(savedBoosterTokens);
    }

    if (savedCash !== null) {
        player_cash_balance = JSON.parse(savedCash);
    }
    if (savedPassiveIncomePool !== null) {
        total_passive_income_pool = JSON.parse(savedPassiveIncomePool);
    }
    if (savedCoins !== null) {
        player_coins_balance = JSON.parse(savedCoins);
    }
    if (savedDiamonds !== null) {
        player_diamond_balance = JSON.parse(savedDiamonds);
    }
    if (savedTycoonScore !== null) {
        player_tycoon_score = JSON.parse(savedTycoonScore);
    }

    // BANK STATS

    if (savedLoanDebt !== null) {
        current_loan_debt = JSON.parse(savedLoanDebt);
    }

    if (savedLoanDebtLimit !== null) {
        current_loan_debt_limit = JSON.parse(savedLoanDebtLimit);
    }

    if (savedFarm1Progress !== null) {
        farm_1_progress_bar.value = JSON.parse(savedFarm1Progress);
    }
    if (savedFarm2Progress !== null) {
        farm_2_progress_bar.value = JSON.parse(savedFarm2Progress);
    }
    if (savedFarm3Progress !== null) {
        farm_3_progress_bar.value = JSON.parse(savedFarm3Progress);
    }
    if (savedFarm4Progress !== null) {
        farm_4_progress_bar.value = JSON.parse(savedFarm4Progress);
    }
    if (savedFarm5Progress !== null) {
        farm_5_progress_bar.value = JSON.parse(savedFarm5Progress);
    }
    if (savedFarm6Progress !== null) {
        farm_6_progress_bar.value = JSON.parse(savedFarm6Progress);
    }

    if (savedTier2Farm1Progress !== null) {
        tier_2_farm_1_progress_bar.value = JSON.parse(savedTier2Farm1Progress);
    }
    if (savedTier2Farm2Progress !== null) {
        tier_2_farm_2_progress_bar.value = JSON.parse(savedTier2Farm2Progress);
    }
    if (savedTier2Farm3Progress !== null) {
        tier_2_farm_3_progress_bar.value = JSON.parse(savedTier2Farm3Progress);
    }
    if (savedTier2Farm4Progress !== null) {
        tier_2_farm_4_progress_bar.value = JSON.parse(savedTier2Farm4Progress);
    }
    if (savedTier2Farm5Progress !== null) {
        tier_2_farm_5_progress_bar.value = JSON.parse(savedTier2Farm5Progress);
    }
    if (savedTier2Farm6Progress !== null) {
        tier_2_farm_6_progress_bar.value = JSON.parse(savedTier2Farm6Progress);
    }

    
    if (savedTier3Farm1Progress !== null) {
        tier_3_farm_1_progress_bar.value = JSON.parse(savedTier3Farm1Progress);
    }
    if (savedTier3Farm2Progress !== null) {
        tier_3_farm_2_progress_bar.value = JSON.parse(savedTier3Farm2Progress);
    }
    if (savedTier3Farm3Progress !== null) {
        tier_3_farm_3_progress_bar.value = JSON.parse(savedTier3Farm3Progress);
    }
    if (savedTier3Farm4Progress !== null) {
        tier_3_farm_4_progress_bar.value = JSON.parse(savedTier3Farm4Progress);
    }
    if (savedTier3Farm5Progress !== null) {
        tier_3_farm_5_progress_bar.value = JSON.parse(savedTier3Farm5Progress);
    }
    if (savedTier3Farm6Progress !== null) {
        tier_3_farm_6_progress_bar.value = JSON.parse(savedTier3Farm6Progress);
    }
}