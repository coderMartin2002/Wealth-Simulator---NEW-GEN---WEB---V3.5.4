const peerConnectionToggle = document.getElementById("peer-connection-preference");
let peerRtc = null;
let peerMediaStream = null;
let peerConnectionAttempt = 0;

async function startPeerConnection() {
    const attempt = ++peerConnectionAttempt;
    const rtc = new RTCPeerConnection();
    let stream = null;

    try {
        stream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: true
        });

        if (attempt !== peerConnectionAttempt || !peerConnectionToggle.checked) {
            stream.getTracks().forEach((track) => track.stop());
            rtc.close();
            return;
        }

        peerRtc = rtc;
        peerMediaStream = stream;

        stream.getTracks().forEach((track) => {
            rtc.addTrack(track, stream);
        });

        rtc.createDataChannel("chat");

        rtc.addEventListener("icecandidate", (event) => {
            if (event.candidate) {
                console.log(JSON.stringify(event.candidate));
            }
        });

        const offer = await rtc.createOffer();
        await rtc.setLocalDescription(offer);
    } catch (error) {
        stream?.getTracks().forEach((track) => track.stop());
        rtc.close();

        if (attempt === peerConnectionAttempt) {
            peerRtc = null;
            peerMediaStream = null;
            peerConnectionToggle.checked = false;
            console.error("Peer connection failed:", error);
        }
    }
}

function stopPeerConnection() {
    peerConnectionAttempt += 1;
    peerMediaStream?.getTracks().forEach((track) => track.stop());
    peerMediaStream = null;
    peerRtc?.close();
    peerRtc = null;
}

peerConnectionToggle.addEventListener("change", () => {
    if (peerConnectionToggle.checked) {
        startPeerConnection();
    } else {
        stopPeerConnection();
    }
});

// NOT MY CODE