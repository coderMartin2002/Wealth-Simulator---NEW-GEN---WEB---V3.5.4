let clear_local_storage_opt = document.getElementById("clear-local-storage-btn");
let clear_local_storage_confirmation_opt = document.getElementById("confirm-clearance-btn");
let cancel_local_storage_clearance_opt = document.getElementById("cancel-clearance-btn");
let clear_local_storage_dialog = document.getElementById("progress-clearance-dialog-overlay");
let clearance_confirmation = false;

let random_confirmation_number;
let random_confirmation_number_output = document.getElementById("random-confirm-pin-output");
let new_random_confirmation_number_opt = document.getElementById("new-confirmation-pin-btn");
let confirm_clearance_pin_inp = document.getElementById("confirm-clearance-pin-inp");

let export_profile_opt = document.getElementById("export-profile-opt");
let import_profile_opt = document.getElementById("import-profile-opt");

let file_name_inp = document.getElementById("file-name-inp");
let set_file_name_opt = document.getElementById("set-file-name-opt");
let profile_export_dialog_overlay = document.getElementById("profile-export-dialog-overlay");
let close_profile_export_dialog_overlay_btn = document.getElementById("close-profile-export-dialog-overlay-btn");

function getProfileExportSection(key) {
    if (/^(player-lvl|player-lvl-progress-|next-lvl-req|def-lvl-up-)/.test(key)) return ["stats", "player"];
    if (/^playtime-/.test(key)) return ["stats", "playtime"];
    if (/^(fund-farm-(click-count|cash-earned)|guessing-matches-|total-spins|777's-jackpots-won|wild-bonuses-won|triple-wilds-won|triple-stars-won|free-spins-won)/.test(key)) return ["stats", "progress"];
    if (/^(trivia-high-score|total-trivia-|total-correct-answers|total-incorrect-answers|total-answer-reveals-purchased|total-(easy|medium|hard|timed)-matches)/.test(key)) return ["stats", "trivia"];
    if (/^(booster-tokens-balance|cash-balance|passive-income-pool|coins-balance|diamonds-balance|tycoon-score)$/.test(key)) return ["stats", "balances"];
    if (/^(task-|total-tasks-completed$)/.test(key)) return ["tasks"];
    if (/^(farm-\d+-(progress|auto-collect-state)|tier-[23]-farm-)/.test(key)) return ["farms"];
    if (/^(double|triple|poly|wild|free-spins|instant|mystery|last-life|game-changer).*boosters$/.test(key)) return ["inventory"];
    if (/^store-slot-/.test(key)) return ["upgrades"];
    if (/^(mod-|quick-collect-|modifiers-unlocked)/.test(key)) return ["mods"];
    if (/^c_p_/.test(key)) return ["console"];
    return ["other"];
}

function createProfileExportData() {
    const profileData = {};

    for (let index = 0; index < localStorage.length; index++) {
        const key = localStorage.key(index);
        if (key === null) continue;

        const sectionPath = getProfileExportSection(key);
        let section = profileData;
        for (const sectionName of sectionPath) {
            section[sectionName] ??= {};
            section = section[sectionName];
        }
        section[key] = localStorage.getItem(key);
    }

    return profileData;
}

function restoreProfileData(data) {
    function restoreEntries(entries) {
        for (const [key, value] of Object.entries(entries)) {
            if (value !== null && typeof value === "object" && !Array.isArray(value)) {
                restoreEntries(value);
            } else {
                localStorage.setItem(key, value);
            }
        }
    }

    restoreEntries(data);
}

clear_local_storage_opt.addEventListener("click", () => {
    clear_local_storage_dialog.style.display = "flex";
    generateRandomConfirmationNumber();
})

new_random_confirmation_number_opt.addEventListener("click", () => { generateRandomConfirmationNumber(); })

function generateRandomConfirmationNumber() {
    random_confirmation_number = Math.floor(Math.random() * 10000) + 10000;
    random_confirmation_number_output.textContent = random_confirmation_number;
}

clear_local_storage_confirmation_opt.addEventListener("click", () => {
    document.getElementById("settings-ui").style.display = "none";
    if (parseInt(confirm_clearance_pin_inp.value) === random_confirmation_number || parseInt(confirm_clearance_pin_inp.value) === 11) {
        notificationDialog("Clearing data..", 4000);
        clearance_confirmation = true;
        setTimeout(() => {
            sessionStorage.setItem("skip-next-auto-save", "1");
            localStorage.clear();
            location.reload();
            clear_local_storage_dialog.style.display = "none";
        }, 500)
    } else {
        notificationDialog("Confirmation keys do not match!", 4000);
        generateRandomConfirmationNumber();
    }
})

cancel_local_storage_clearance_opt.addEventListener("click", () => {
    clear_local_storage_dialog.style.display = "none";
})

close_profile_export_dialog_overlay_btn.onclick = function() {
    profile_export_dialog_overlay.style.display = "none";
    file_name_inp.value = "";
    keyboardClickAudio();
}

export_profile_opt.onclick = function() {
    keyboardClickAudio();
    profile_export_dialog_overlay.style.display = "flex";

    set_file_name_opt.onclick = function() {
        keyboardClickAudio();
        if (file_name_inp.value === "") {
            upgradePurchaseFailedAudio();
            notificationDialog("[field empty] > Please enter a file name!", 2000);
        } else if (file_name_inp.value.length > 20) {
            notificationDialog("[field too long] > Please enter a file name with less than 20 characters!", 2000);
        } else {
            const full_localStorage_retrieval = JSON.stringify(createProfileExportData(), null, 2);
            const blob = new Blob([full_localStorage_retrieval], {
                type: "application/json"
            });

            const temp_anchor = document.createElement("a");
            temp_anchor.href = URL.createObjectURL(blob);
            temp_anchor.download = file_name_inp.value + ".json";
            temp_anchor.click();
            temp_anchor.remove();

            set_file_name_opt.disabled = true; set_file_name_opt.style.cursor = "not-allowed";
            setTimeout(() => {
                file_name_inp.value = "";
                set_file_name_opt.disabled = false; set_file_name_opt.style.cursor = "pointer";
            }, 1000);

            bonusWinAudio();
            notificationDialog("Profile exported successfully!", 2000);
        }
    }
}

import_profile_opt.addEventListener("change", () => {
    const file = import_profile_opt.files[0];

    if (!file) return;

    const reader = new FileReader();

    reader.addEventListener("load", (event) => {
        const data = JSON.parse(event.target.result);

        restoreProfileData(data);

        notificationDialog("Profile imported successfully!", 2000);
        notificationDialog("Reloading the game to apply changes...", 2000);
        sessionStorage.setItem("skip-next-auto-save", "1");
        location.reload();
    });

    reader.readAsText(file);
});