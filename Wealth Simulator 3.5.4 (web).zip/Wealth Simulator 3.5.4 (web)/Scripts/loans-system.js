let cash_loan_opt_1 = document.getElementById("cash-loan-opt-1");
let cash_loan_opt_2 = document.getElementById("cash-loan-opt-2");
let cash_loan_opt_3 = document.getElementById("cash-loan-opt-3");
let cash_loan_opt_4 = document.getElementById("cash-loan-opt-4");
let cash_loan_opt_5 = document.getElementById("cash-loan-opt-5");
let cash_loan_opt_6 = document.getElementById("cash-loan-opt-6");
let custom_loan_opt = document.getElementById("custom-loan-opt");

let custom_loan_amount_inp = document.getElementById("custom-loan-amount-inp");
let custom_loan_interest = 0.50;
let custom_loan_min = 2500;
let custom_loan_max = 10000000; // def: 10 million
let set_custom_loan_amount_opt = document.getElementById("set-custom-loan-opt");

let cash_loan_opts_storage = [cash_loan_opt_1, cash_loan_opt_2, cash_loan_opt_3, cash_loan_opt_4, cash_loan_opt_5, cash_loan_opt_6];

let bank_loan_info_dialog_overlay = document.getElementById("cash-loan-info-dialog-overlay");
let close_bank_loan_info_dialog_overlay_opt = document.getElementById("close-cash-loan-info-dialog-overlay-btn");
let current_loan_debt_output = document.getElementById("current-loan-debt-output");
let tycoon_score_output = document.getElementById("tycoon-score-output");
let loan_repayment_eta_timer_output = document.getElementById("loan-repayment-eta-timer-output");
let loans_history_opt = document.getElementById("existing-loans-log-btn");
let loans_history_log_dialog_overlay = document.getElementById("loans-history-log-dialog-overlay");
let repayment_interval_output = document.getElementById("repayment-interval-output");
let bank_loan_status_dialog_overlay = document.getElementById("bank-loan-status-dialog-overlay");
let loans_repayment_interval_output_dialog_overlay = document.getElementById("loans-repayment-interval-output-dialog-overlay");
let close_loan_repayment_interval_dialog_overlay_btn = document.getElementById("close-loan-repayment-interval-dialog-overlay-btn");
let close_bank_loan_status_dialog_overlay_opt = document.getElementById("close-bank-loan-status-dialog-overlay-btn");
let close_loans_history_log_selection_overlay_btn = document.getElementById("close-loans-history-log-selection-overlay-btn");
let loan_manual_management_dialog_overlay = document.getElementById("loan-manual-management-dialog-overlay");
let close_loan_manual_management_dialog_overlay_btn = document.getElementById("close-loan-manual-management-dialog-overlay-btn");
let custom_loan_payment_dialog_overlay = document.getElementById("custom-loan-payment-dialog-overlay");
let custom_loan_dialog_overlay = document.getElementById("custom-loan-dialog-overlay");
let close_custom_loan_dialog_overlay_btn = document.getElementById("close-custom-loan-dialog-overlay-btn");

let active_loans_panel = document.getElementById("active-loans-panel");
let loans_payment_history_logs = document.getElementById("loans-history-logs");
let loan_log_options_dialog_overlay = document.getElementById("loan-log-options-dialog-overlay");
let close_loan_log_options_dialog_overlay_btn = document.getElementById("close-loan-log-options-dialog-overlay-btn");

let loan_logs_opt = document.getElementById("loan-logs-btn");
let manage_loans_opt = document.getElementById("manage-loans-opt");
let loan_custom_payment_opt = document.getElementById("loan-custom-payment-opt");
let pay_full_payment_opt = document.getElementById("pay-full-payment-opt");
let custom_loan_payment_amount_inp = document.getElementById("custom-loan-payment-amount-inp");
let installment_mod_inp = document.getElementById("installment-mod-inp");
let set_installment_opt = document.getElementById("set-installment-opt");
let pay_custom_amount_opt = document.getElementById("pay-custom-amount-opt");
let accept_loan_opt = document.getElementById("accept-loan-btn");

let loan_slots_storage = document.getElementsByClassName("loan-slot");
let loan_payment_slots_storage = document.getElementsByClassName("loan-payment-slot");

let clear_loans_history_log_btn = document.getElementById("clear-loans-history-log-btn");
let clear_loans_payment_log_btn = document.getElementById("clear-loans-payment-log-btn");

let modify_installments_opt = document.getElementById("modify-installments-opt");
let installment_modification_dialog_overlay = document.getElementById("installment-modification-dialog-overlay");
let close_installment_modification_dialog_overlay_btn = document.getElementById("close-installment-modification-dialog-overlay-btn");

let cash_loan_amount;
let current_loan_debt = 0;
let current_loan_debt_limit = 50;
let loan_repayment_amount;
let loan_repayment_count;
let loan_repayment_int = 300000; // DEF 300000 (5min)

let payment_counter = 0;

let total_repayment_pool = 0;

let cash_loan_1_amount = 50;
let cash_loan_2_amount = 100;
let cash_loan_3_amount = 250;
let cash_loan_4_amount = 500;
let cash_loan_5_amount = 2500;
let cash_loan_6_amount = 0; // CUSTOM LOAN AMOUNT

let cash_loan_1_interest = 0.05;
let cash_loan_2_interest = 0.10;
let cash_loan_3_interest = 0.20;
let cash_loan_4_interest = 0.30;
let cash_loan_5_interest = 0.40;
let cash_loan_6_interest = 0.50; // CUSTOM LOAN INTEREST

let cash_loan_1_req = 100;
let cash_loan_2_req = 200;
let cash_loan_3_req = 300;
let cash_loan_4_req = 400;
let cash_loan_5_req = 750;
let cash_loan_6_req = 1000; // CUSTOM LOAN CREDIT REQUIREMENT

let cash_loan_1_available = false;
let cash_loan_2_available = false;
let cash_loan_3_available = false;
let cash_loan_4_available = false;
let cash_loan_5_available = false;
let cash_loan_6_available = false; // CUSTOM LOAN AVAILABILITY

let cash_loan_1_active = false;
let cash_loan_2_active = false;
let cash_loan_3_active = false;
let cash_loan_4_active = false;
let cash_loan_5_active = false;
let cash_loan_6_active = false; // CUSTOM LOAN ACTIVE STATUS

let registered_loans_storage = [];
let registered_loan_slots_storage = [];
const active_repayment_intervals = new Map();

function stopRepaymentInterval(loan_id) {
    const interval = active_repayment_intervals.get(loan_id);
    if (interval !== undefined) {
        clearTimeout(interval);
        active_repayment_intervals.delete(loan_id);
    }
}

function updateRepaymentCountdown() {
    const next_repayment = registered_loans_storage.reduce((earliest, loan) => {
        if (!loan) return earliest;
        const due_at = Number(loan.next_repayment_at);
        if (Number(loan.remaining_balance) <= 0.01 || !Number.isFinite(due_at)) {
            return earliest;
        }
        return earliest === null || due_at < earliest.due_at ? { loan, due_at } : earliest;
    }, null);

    if (next_repayment === null) {
        repayment_interval_output.innerHTML = "<span style='color: aquamarine; margin-left: 20px; font-family: monospace, Verdana, Geneva, Tahoma, sans-serif; letter-spacing: 0.5px; line-height: 1.15;'>NEXT PAYMENT > NO ACTIVE LOANS</span>";
        return;
    }

    const seconds_remaining = Math.max(0, Math.ceil((next_repayment.due_at - Date.now()) / 1000));
    const minutes = Math.floor(seconds_remaining / 60);
    const seconds = String(seconds_remaining % 60).padStart(2, "0");
    repayment_interval_output.innerHTML = "<span style='color: aquamarine; margin-left: 20px; font-family: monospace, Verdana, Geneva, Tahoma, sans-serif; letter-spacing: 0.5px; line-height: 1.15;'>NEXT PAYMENT [LOAN ID > <span style='color: yellow;'>" +
        next_repayment.loan.loan_id + "</span>] IN > <span style='color: lime;'>" +
        minutes + ":" + seconds + "</span></span>";
}

setInterval(updateRepaymentCountdown, 1000);
updateRepaymentCountdown();

loan_custom_payment_opt.onclick = function() {
    const isVisible = getComputedStyle(custom_loan_payment_dialog_overlay).display !== "none";
    custom_loan_payment_dialog_overlay.style.display = isVisible ? "none" : "flex";
};

close_loan_manual_management_dialog_overlay_btn.onclick = function() {
    loan_manual_management_dialog_overlay.style.display = "none";
    custom_loan_payment_dialog_overlay.style.display = "none";
}

manage_loans_opt.onclick = function() { keyboardClickAudio(); loans_repayment_interval_output_dialog_overlay.style.display = "flex"; }

close_loan_repayment_interval_dialog_overlay_btn.onclick = function() { loans_repayment_interval_output_dialog_overlay.style.display = "none"; keyboardClickAudio(); }

modify_installments_opt.onclick = function() {
    installment_modification_dialog_overlay.style.display = "flex";
    keyboardClickAudio();
}

close_installment_modification_dialog_overlay_btn.onclick = function() {
    installment_modification_dialog_overlay.style.display = "none";
    keyboardClickAudio();
}

loan_logs_opt.onclick = function() { loan_log_options_dialog_overlay.style.display = "flex"; keyboardClickAudio(); }

close_loan_log_options_dialog_overlay_btn.onclick = function() { loan_log_options_dialog_overlay.style.display = "none"; keyboardClickAudio(); }

loans_history_opt.onclick = function () {
    loans_history_log_dialog_overlay.style.display = "flex";
    keyboardClickAudio();
}

close_loans_history_log_selection_overlay_btn.onclick = function() {
    loans_history_log_dialog_overlay.style.display = "none";
    loan_log_options_dialog_overlay.style.display = "none";
    keyboardClickAudio();
}

clear_loans_history_log_btn.onclick = function() {
    for (let i = 0; i < loan_slots_storage.length; i++) {
        loan_slots_storage[i].style.display = "none";
        loan_slots_storage[i].remove();
    }
    oscClickAudio();
}

clear_loans_payment_log_btn.onclick = function() {
    for (let i = 0; i < loan_payment_slots_storage.length; i++) {
        loan_payment_slots_storage[i].style.display = "none";
        loan_payment_slots_storage[i].remove();
    }
    oscClickAudio();
}

close_bank_loan_info_dialog_overlay_opt.onclick = function() {
    bank_loan_info_dialog_overlay.style.display = "none";
    keyboardClickAudio();
}

close_bank_loan_status_dialog_overlay_opt.onclick = function() {
    bank_loan_status_dialog_overlay.style.display = "none";
    keyboardClickAudio();
}

/*

function disableLoanOpt(loan_opt) {
    loan_opt.disabled = true;
    loan_opt.setAttribute("disabled", "true");
    loan_opt.style.opacity = "0.5";
    loan_opt.style.cursor = "not-allowed";
}

function enableLoanOpt(loan_opt) {
    loan_opt.disabled = false;
    loan_opt.removeAttribute("disabled");
    loan_opt.style.opacity = "1";
    loan_opt.style.cursor = "pointer";
}

*/

function manualLoanDisable() { for (let i = 0; i < cash_loan_opts_storage.length; i++) { cash_loan_opts_storage[i].disabled = true; cash_loan_opts_storage[i].style.opacity = "0.5"; cash_loan_opts_storage[i].style.cursor = "not-allowed"; } }
function manualLoanEnable() { for (let i = 0; i < cash_loan_opts_storage.length; i++) { cash_loan_opts_storage[i].disabled = false; cash_loan_opts_storage[i].style.opacity = "1"; cash_loan_opts_storage[i].style.cursor = "pointer"; } }

function initializeLoanOptions() {
    cash_loan_opt_1.innerHTML = "<span style='color: snow'>$" + formatMoneyValue(cash_loan_1_amount) + "</span>";
    cash_loan_opt_2.innerHTML = "<span style='color: snow'>$" + formatMoneyValue(cash_loan_2_amount) + "</span>";
    cash_loan_opt_3.innerHTML = "<span style='color: snow'>$" + formatMoneyValue(cash_loan_3_amount) + "</span>";
    cash_loan_opt_4.innerHTML = "<span style='color: snow'>$" + formatMoneyValue(cash_loan_4_amount) + "</span>";
    cash_loan_opt_5.innerHTML = "<span style='color: snow'>$" + formatMoneyValue(cash_loan_5_amount) + "</span>";
    /*
    if (typeof player_tycoon_score !== "undefined") {
        if (player_tycoon_score >= 100) enableLoanOpt(cash_loan_opt_1); else disableLoanOpt(cash_loan_opt_1);
        if (player_tycoon_score >= 200) enableLoanOpt(cash_loan_opt_2); else disableLoanOpt(cash_loan_opt_2);
        if (player_tycoon_score >= 300) enableLoanOpt(cash_loan_opt_3); else disableLoanOpt(cash_loan_opt_3);
        if (player_tycoon_score >= 400) enableLoanOpt(cash_loan_opt_4); else disableLoanOpt(cash_loan_opt_4);
        if (player_tycoon_score >= 500) enableLoanOpt(cash_loan_opt_5); else disableLoanOpt(cash_loan_opt_5);
    }
    */
}

initializeLoanOptions();
window.addEventListener("load", initializeLoanOptions);

cash_loan_opt_1.onclick = function() { loanProcess(cash_loan_1_amount, cash_loan_1_interest, 20, loan_repayment_int, cash_loan_1_req, cash_loan_opt_1); }

cash_loan_opt_2.onclick = function() { loanProcess(cash_loan_2_amount, cash_loan_2_interest, 20, loan_repayment_int, cash_loan_2_req, cash_loan_opt_2); }

cash_loan_opt_3.onclick = function() { loanProcess(cash_loan_3_amount, cash_loan_3_interest, 20, loan_repayment_int, cash_loan_3_req, cash_loan_opt_3); }

cash_loan_opt_4.onclick = function() { loanProcess(cash_loan_4_amount, cash_loan_4_interest, 20, loan_repayment_int, cash_loan_4_req, cash_loan_opt_4); }

cash_loan_opt_5.onclick = function() { loanProcess(cash_loan_5_amount, cash_loan_5_interest, 20, loan_repayment_int, cash_loan_5_req, cash_loan_opt_5); }

custom_loan_opt.onclick = function() { custom_loan_dialog_overlay.style.display = "flex"; keyboardClickAudio(); customLoanInpOverflowMeasure(); updateCustomLoanStats(); }

close_custom_loan_dialog_overlay_btn.onclick = function() { custom_loan_dialog_overlay.style.display = "none"; keyboardClickAudio(); }

function disableCustomLoanInp() { custom_loan_amount_inp.disabled = true; custom_loan_amount_inp.style.opacity = "0.5"; custom_loan_amount_inp.style.cursor = "not-allowed"; }
function enableCustomLoanInp() { custom_loan_amount_inp.disabled = false; custom_loan_amount_inp.style.opacity = "1"; custom_loan_amount_inp.style.cursor = "pointer"; }

function updateCustomLoanStats() {
    document.getElementById("custom-loan-amount-output").innerHTML = "$" + formatMoneyValue(Number(custom_loan_amount_inp.value));
    document.getElementById("custom-loan-interest-amount-output").innerHTML = Math.floor((custom_loan_interest * 100)) + "<span style='margin-right: 10px;'>%</span>" + "[<span style='color: yellow;'>FIXED RATE</span>]";
    document.getElementById("custom-loan-installment-output").innerHTML = "$" + formatMoneyValue(Number(custom_loan_amount_inp.value) * custom_loan_interest);
    document.getElementById("custom-loan-full-repayment-output").textContent = "$" + formatMoneyValue(Number(custom_loan_amount_inp.value) * (1 + custom_loan_interest));
}

function customLoanInpOverflowMeasure() {
    setTimeout(() => { custom_loan_amount_inp.value = 2500; document.getElementById("custom-loan-error-output").innerHTML = "<span style='color: greenyellow;'>[STATUS]</span> > <span style='color: springgreen;'>AVAILABLE</span>"; enableCustomLoanOpt(); enableCustomLoanInp(); updateCustomLoanStats(); }, 100)
}

custom_loan_amount_inp.oninput = function() {
    oscClickAudio();
    if (Number(custom_loan_amount_inp.value) < custom_loan_min) {
        disableCustomLoanOpt();
        updateCustomLoanStats();
        document.getElementById("custom-loan-error-output").innerHTML = "<span style='color: lime;'>[ERROR]</span> <span style='color: snow;'> > $2,500</span> minimum loan value!";
    } else if (Number(custom_loan_amount_inp.value) > custom_loan_max) {
        customLoanInpOverflowMeasure();
        disableCustomLoanInp();
        disableCustomLoanOpt();
        updateCustomLoanStats();
        document.getElementById("custom-loan-error-output").innerHTML = "<span style='color: lime;'>[ERROR]</span> <span style='color: snow;'> > $10 million</span> maximum loan value!";
    } else {
        updateCustomLoanStats();
        enableCustomLoanOpt();
        document.getElementById("custom-loan-error-output").innerHTML = "<span style='color: greenyellow;'>[STATUS]</span> > <span style='color: springgreen;'>AVAILABLE</span>";
    }
}

function disableCustomLoanOpt() { set_custom_loan_amount_opt.disabled = true; set_custom_loan_amount_opt.style.opacity = "0.5"; set_custom_loan_amount_opt.style.cursor = "not-allowed"; }
function enableCustomLoanOpt() { set_custom_loan_amount_opt.disabled = false; set_custom_loan_amount_opt.style.opacity = "1"; set_custom_loan_amount_opt.style.cursor = "pointer"; }


set_custom_loan_amount_opt.onclick = function() {
    collectTaskAwardAudio();
    if (Number(custom_loan_amount_inp.value) < custom_loan_min) {
        disableCustomLoanOpt();
        notificationDialog("$50 loan is the lowest option!", 3000);
        upgradePurchaseFailedAudio();
    } else if (Number(custom_loan_amount_inp.value) > custom_loan_max) {
        disableCustomLoanOpt();
        notificationDialog("$1 million loan is the lowest option!", 3000);
        upgradePurchaseFailedAudio();
    } else {
        enableCustomLoanOpt();
        notificationDialog("Processinng...", 3000);
        let custom_loan_amount = Number(custom_loan_amount_inp.value);
        let custom_loan_interest_rate = custom_loan_interest;
        setTimeout(() => { custom_loan_dialog_overlay.style.display = "none"; manualLoanEnable(); }, 1000);
        setTimeout(() => { loanProcess(custom_loan_amount, custom_loan_interest_rate, 20, loan_repayment_int, cash_loan_6_req, custom_loan_opt); }, 3000);
    }
}

function startRepaymentInterval(loan, updateLoanUi = function() {}) {
    const full_repayment = Number(loan.full_repayment);
    const installment_count = Number(loan.installments);
    const repayment_interval = Number(loan.repayment_interval_ms) || loan_repayment_int;
    if (!Number.isFinite(full_repayment) || full_repayment <= 0 ||
        !Number.isFinite(installment_count) || installment_count <= 0 ||
        !Number.isFinite(repayment_interval) || repayment_interval <= 0) {
        console.error("Cannot start repayment interval: invalid loan terms.", loan.loan_id);
        return;
    }

    let installment_amount = full_repayment / installment_count;
    loan.payments_made = Number(loan.payments_made) || Math.floor(
        (full_repayment - Number(loan.remaining_balance)) / installment_amount
    );

    if (!Number.isFinite(Number(loan.next_repayment_at)) || Number(loan.next_repayment_at) <= 0) {
        loan.next_repayment_at = Date.now() + repayment_interval;
        autoSave();
    }
    updateRepaymentCountdown();

    function scheduleRepayment() {
        const delay = Math.max(0, Number(loan.next_repayment_at) - Date.now());
        const repayment_timeout_id = setTimeout(function() {
            active_repayment_intervals.delete(loan.loan_id);

            const remaining_balance = Number(loan.remaining_balance);
            if (!Number.isFinite(remaining_balance)) {
                stopRepaymentInterval(loan.loan_id);
                console.error("Stopped repayment interval: invalid loan balance.", loan.loan_id);
                return;
            }
            if (remaining_balance <= 0.01) {
                loan.remaining_balance = 0;
                delete loan.next_repayment_at;
                stopRepaymentInterval(loan.loan_id);
                updateLoanUi();
                autoSave();
                return;
            }

            const payment_amount = Math.min(installment_amount, remaining_balance);
            player_cash_balance -= payment_amount;
            current_loan_debt = Math.max(0, Number((current_loan_debt - payment_amount).toFixed(2)));
            loan.remaining_balance = Math.max(0, Number((remaining_balance - payment_amount).toFixed(2)));
            loan.payments_made += 1;
            if (loan.remaining_balance <= 0.01) {
                loan.remaining_balance = 0;
                delete loan.next_repayment_at;
            } else {
                loan.next_repayment_at = Date.now() + repayment_interval;
            }
            loan.repayment_progress = "$" + formatMoneyValue(full_repayment - loan.remaining_balance) +
                " / <span style='color: lime'>$" + formatMoneyValue(full_repayment) + "</span>";
            if (loan.remaining_balance === 0) {
                loan.status = "<span style='color: yellow;'>REPAID</span>";
            } else {
                loan.status = "<span style='color: #E86D72;'>UNPAID</span>";
            }

            const loan_payment_slot = document.createElement("section");
            loan_payment_slot.setAttribute("class", "loan-payment-slot");
            loan_payment_slot.style.borderRight = "10px solid #" + (Math.floor(Math.random() * 16777216)).toString(16);

            const loan_payment_output = document.createElement("h4");
            loan_payment_output.innerHTML = "<span style='color: springgreen;'>[LOAN REPAYMENT] > <span style='color: springgreen;'>$" +
                formatMoneyValue(payment_amount) + "</span></span><br><span style='color: lime;'>Cash Balance</span> > $" +
                formatMoneyValue(player_cash_balance) + "<span style='color: #E86D72; margin-left: 7px;'>-$" +
                formatMoneyValue(payment_amount) + "</span><br><span style='color: aquamarine;'>Remaining > $" +
                formatMoneyValue(loan.remaining_balance) + "</span>";
            const loan_payment_count_output = document.createElement("h4");
            loan_payment_count_output.style.fontFamily = "monospace, Verdana, Geneva, Tahoma, sans-serif; text-transform: uppercase; font-weight: bold; font-size: 14px;";
            loan_payment_count_output.innerHTML = "<span style='color: snow; font-weight: bold; font-family: monospace, Verdana, Geneva, Tahoma, sans-serif;'>PAYMENT </span> > " + "<span style='color: #E86D72;'><span style='color: snow;'>[" + loan.payments_made + " || " + loan.installments + "]</span></span>" + "<br>" + "<span style='color: greenyellow; text-transform: uppercase;'>LOAN ID</span> > <span style='color: springgreen; font-weight: bold; font-family: monospace, Verdana, Geneva, Tahoma, sans-serif;'><span style='color: snow;'>[</span><span><span style='color: yellow;'>" + loan.loan_id + "</span><span style='color: snow;'>]</span></span>" + "<br>" + "<span style='color: snow;'>TIME > </span> > <span style='color: springgreen; font-weight: bold; font-family: monospace, Verdana, Geneva, Tahoma, sans-serif;'><span style='color: snow;'>[</span><span><span style='color: yellow;'>" + new Date().toLocaleString() + "</span><span style='color: snow;'>]</span></span>";
            loans_payment_history_logs.appendChild(loan_payment_slot);
            loan_payment_slot.appendChild(loan_payment_count_output);
            loan_payment_slot.appendChild(loan_payment_output);
            loan_payment_slot.scrollIntoView();

            updateLoanUi();
            updateStats();
            autoSave();

            if (loan.remaining_balance <= 0.01) {
                loan.remaining_balance = 0;
                loan.repayment_progress = "$" + formatMoneyValue(full_repayment) +
                    " / <span style='color: lime'>$" + formatMoneyValue(full_repayment) + "</span>";
                loan.status = "<span style='color: yellow;'>REPAID</span>";
                stopRepaymentInterval(loan.loan_id);
                updateLoanUi();
                autoSave();
                notificationDialog("[$" + formatMoneyValue(loan.loan_amount) + " LOAN] > Your loan has been fully repaid!", 4000);
                document.getElementById("loan-status-output").innerHTML = "<span style='color: yellow'>Loan Status > </span><span style='color: yellow'>REPAID</span>";
            }

            if (loan.remaining_balance > 0.01) {
                scheduleRepayment();
            }
        }, delay);

        active_repayment_intervals.set(loan.loan_id, repayment_timeout_id);
    }

    scheduleRepayment();
}

// LOAN INFO & ACCEPTANCE / VALIDATION PROCESS

function loanProcess(loan_amount, interest_rate, repayment_count, repayment_int, tycoon_score_requirement, loan_opt) {
    bank_loan_info_dialog_overlay.style.display = "flex";
    current_loan_debt_output.innerHTML = "Current Loan Debt: $" + current_loan_debt;
    cash_loan_amount = loan_amount;
    const loan_interest = interest_rate;
    loan_repayment_count = repayment_count;
    let currentLoanRepaymentAmount = (loan_amount * (1 + interest_rate));
    loan_repayment_amount = currentLoanRepaymentAmount;
    loan_repayment_int = repayment_int;
    keyboardClickAudio();

    document.getElementById("loan-amount-output").innerHTML = "<span style='color: aquamarine'>LOAN AMOUNT > </span><span style='color: springgreen'>$" + formatMoneyValue(loan_amount) + "</span>";
    document.getElementById("loan-interest-output").innerHTML = "<span style='color: aquamarine'>INTEREST RATE (%) > </span><span style='color: springgreen'>" + formatDisplayNumber(loan_interest * 100) + "%</span>";
    document.getElementById("loan-repayment-output").innerHTML = "<span style='color: aquamarine'>TOTAL REPAYMENT > </span><span style='color: springgreen'>$" + formatMoneyValue(currentLoanRepaymentAmount) + " <span style='color: aqua;'>{" + "+$" + formatMoneyValue(loan_interest * loan_amount) + " INTEREST)</span><br><span style='color: aquamarine'>Installment Amount > </span><span style='color: springgreen'>$" + formatMoneyValue(currentLoanRepaymentAmount / repayment_count) + "</span> <span style='color: aqua'>(" + formatDisplayNumber(repayment_count) + " payments)</span>";
    let repayment_time_display = repayment_int >= 60000
        ? formatDisplayNumber(repayment_int / 60000) + " minutes"
        : formatDisplayNumber(repayment_int / 1000) + "s";

    document.getElementById("loan-repayment-time-output").innerHTML = "<span style='color: aquamarine'>Repayment Time > </span><span style='color: springgreen'>" + repayment_time_display + "</span>";
    document.getElementById("tycoon-credit-req-output").innerHTML = "<span style='color: yellow'>Tycoon Credit Requirement > </span><span style='color: springgreen'>" + tycoon_score_requirement + "</span>";

    installment_mod_inp.oninput = function() {
        document.getElementById("installment-mod-output").innerHTML = "<span style='color: aquamarine;'>Installments > </span><span style='color: springgreen; margin-right: 10px;'>" + installment_mod_inp.value + "</span>" + "<span style='color: yellow;'> <span style='color: snow;'>||</span> $" + formatMoneyValue(Number((loan_amount * (1 + interest_rate)) / installment_mod_inp.value)) + "</span>";
    }

    set_installment_opt.onclick = function() {
        set_installment_opt.disabled = true; set_installment_opt.style.opacity = "0.5"; set_installment_opt.style.cursor = "not-allowed";
        setTimeout(() => {
            set_installment_opt.disabled = false; set_installment_opt.style.opacity = "1"; set_installment_opt.style.cursor = "pointer";
            notificationDialog("INSTALLMENT COUNT SET > " + formatDisplayNumber(installment_mod_inp.value) + " PAYMENTS", 2500); 
            installment_modification_dialog_overlay.style.display = "none";  
        }, 1000)

        repayment_count = Number(installment_mod_inp.value);
        loan_repayment_count = repayment_count;
        document.getElementById("loan-repayment-output").innerHTML = "<span style='color: aquamarine'>Full Repayment > </span><span style='color: springgreen'>$" + formatMoneyValue(currentLoanRepaymentAmount) + " <span style='color: aqua;'>{" + "+$" + formatMoneyValue(loan_interest * loan_amount) + " INTEREST)</span><br><span style='color: aquamarine'>Installment Amount > </span><span style='color: springgreen'>$" + formatMoneyValue(currentLoanRepaymentAmount / repayment_count) + "</span> <span style='color: aqua'>(" + formatDisplayNumber(repayment_count) + " payments)</span>";
        keyboardClickAudio();
    }

    accept_loan_opt.onclick = function() {
        keyboardClickAudio();
        createLoan(loan_amount, tycoon_score_requirement, interest_rate, repayment_count, repayment_int, currentLoanRepaymentAmount, loan_opt);
    }
}

// LOAN VALIDATION & CREATION

function createLoan(loan_amount, tycoon_score, interest_rate, repayment_count, repayment_int, repayment_amount, loan_opt, repaid_status) {
    if (player_tycoon_score >= tycoon_score && (current_loan_debt + repayment_amount - interest_rate * loan_amount) <= current_loan_debt_limit) {
        notificationDialog("REGISTERING YOUR LOAN..", 3000);
        repaid_status = "<span style='color: #E86D72;'>UNPAID</span>";
        accept_loan_opt.disabled = true; 
        accept_loan_opt.style.opacity = "0.5"; 
        accept_loan_opt.style.cursor = "not-allowed";
        setTimeout(() => { accept_loan_opt.disabled = false; accept_loan_opt.style.opacity = "1"; accept_loan_opt.style.cursor = "pointer"; bank_loan_info_dialog_overlay.style.display = "none"; }, 3000)
        setTimeout(() => {
            bonusWinAudio();
            setTimeout(() => { loanApprovedAudio(); }, 1000)
            notificationDialog("[LOAN APPROVED] > $" + formatMoneyValue(loan_amount) + " credited to your balance!", 3500);
            player_cash_balance += loan_amount;
            current_loan_debt += repayment_amount;
            total_repayment_pool += repayment_amount;

            let loan_remaining_balance = Number(repayment_amount);
            let installment_amount = Number((repayment_amount / repayment_count));
            let payments_made = 0;
            let loan_payment_counter = 0;

            let loan_slot = document.createElement("section");
            let loan_output_1 = document.createElement("h4");
            let loan_output_2 = document.createElement("h4");
            let loan_output_3 = document.createElement("h4");
            let loan_output_4 = document.createElement("h4");
            let loan_progress_value = document.createElement("span");
            let loan_output_5 = document.createElement("h4");
            let loan_output_6 = document.createElement("h4");
            let loan_output_7 = document.createElement("h4");
            let loan_output_8 = document.createElement("h4");
            let loan_output_9 = document.createElement("h4");

            loan_slot.setAttribute("class", "loan-slot");
            loan_slot.style.borderRight = "3px solid #" + (Math.floor(Math.random() * 16777216)).toString(16);

            loan_output_1.innerHTML = "<span style='color: whitesmoke; font-weight: bold;'>LOAN AMOUNT ($) </span> > <span style='color: lime;'>$" + formatMoneyValue(loan_amount) + "</span>";
            loan_output_2.innerHTML = "<span style='color: whitesmoke; font-weight: bold;'>INTEREST RATE (%) </span> > " + formatDisplayNumber(interest_rate * 100) + "%";
            loan_output_3.innerHTML = "<span style='color: whitesmoke; font-weight: bold;'>TOTAL REPAYMENT AMOUNT ($) </span> > <span style='color: lime;'> $" + formatMoneyValue(repayment_amount) + "</span>";
            loan_output_4.innerHTML = "<span style='color: whitesmoke; font-weight: bold;'>REPAYMENT PROGRESS </span> > ";
            loan_progress_value.innerHTML = "$" + formatMoneyValue(repayment_amount - loan_remaining_balance) + " / <span style='color: lime'>$" + formatMoneyValue(repayment_amount) + "</span>";
            loan_output_4.appendChild(loan_progress_value);
            loan_output_5.innerHTML = "<span style='color: whitesmoke; font-weight: bold;'>Installment </span> > $" + formatMoneyValue(installment_amount);
            loan_output_6.innerHTML = "<span style='color: whitesmoke; font-weight: bold;'>Total Installments </span> > " + formatDisplayNumber(repayment_count);
            loan_output_7.innerHTML = "<span style='color: whitesmoke; font-weight: bold;'>Installment interval </span> > " + formatDisplayNumber(repayment_int / 60000) + " Minutes";
            loan_output_8.innerHTML = "<span style='color: aquamarine; font-weight: bold;'>Status </span> > <span style='color: #E86D72;'>UNPAID</span>";

            active_loans_panel.appendChild(loan_slot);
            loan_slot.scrollIntoView();
            loan_slot.appendChild(loan_output_1);
            loan_slot.appendChild(loan_output_2);
            loan_slot.appendChild(loan_output_3);
            loan_slot.appendChild(loan_output_4);
            loan_slot.appendChild(loan_output_5);
            loan_slot.appendChild(loan_output_6);
            loan_slot.appendChild(loan_output_7);
            loan_slot.appendChild(loan_output_8);
            loan_slot.appendChild(loan_output_9);

            let token_chars = "abcdefghijklmnopqrstuvwxyz123456789";
            let uid = "";

            for (let i = 0; i < 16; i++) { uid += token_chars[Math.floor(Math.random() * token_chars.length)]; }
            const registered_loan_unique_id = uid;

            const registered_loan = {
                loan_id: registered_loan_unique_id,
                loan_amount: loan_amount,
                loan_interest_rate: interest_rate,
                full_repayment: repayment_amount,
                remaining_balance: loan_remaining_balance,
                repayment_progress: "$" + formatMoneyValue(repayment_amount - loan_remaining_balance) + " / <span style='color: lime'>$" + formatMoneyValue(repayment_amount) + "</span>",
                installments: repayment_count,
                status: repaid_status,
                repayment_interval_ms: repayment_int,
                next_repayment_at: Date.now() + repayment_int
            };
            registered_loans_storage.push(registered_loan);

            loan_output_9.innerHTML = "<span style='color: greenyellow; text-transform: uppercase;'>LOAN ID (#) </span> > " + "<span style='color: yellow;'>" + registered_loan.loan_id + "</span>";
            let registered_loan_slot = document.createElement("section"); // REGISTERED LOAN SLOTS
            registered_loan_slot.setAttribute("class", "registered-loan-slot");
            registered_loan_slot.style.cursor = "pointer";
            registered_loan_slot.id = registered_loan_unique_id;
            registered_loan_slots_storage.push(registered_loan_slot);

            function updateLoanStats() {
                if (loan_remaining_balance <= 0.01) {
                    loan_remaining_balance = 0;
                }

                repaid_status = loan_remaining_balance === 0
                    ? "<span style='color: yellow;'>REPAID</span>"
                    : "<span style='color: #E86D72;'>UNPAID</span>";
                registered_loan.remaining_balance = loan_remaining_balance;
                registered_loan.repayment_progress = "$" + formatMoneyValue(repayment_amount - loan_remaining_balance) + " / <span style='color: lime'>$" + formatMoneyValue(repayment_amount) + "</span>";
                registered_loan.status = repaid_status;
                current_loan_debt = Math.max(0, Number(current_loan_debt.toFixed(2)));
                current_loan_debt_output.innerHTML = "<span style='color: #E86D72'>Current Loan Debt > </span><span style='color: springgreen'>$" + formatMoneyValue(current_loan_debt) + "</span>";
                loan_progress_value.innerHTML = registered_loan.repayment_progress;
                loan_output_8.innerHTML = "<span style='color: aquamarine; font-weight: bold;'>Status </span> > " + repaid_status;
                registered_loan_slot.innerHTML = "LOAN ID > <span style='color: greenyellow; text-transform: uppercase;'>" + registered_loan_unique_id + "</span><br>LOAN AMOUNT > <span style='color: lime;'>$" + formatMoneyValue(loan_amount) + "</span><br>FULL REPAYMENT > <span style='color: lime;'>$" + formatMoneyValue(repayment_amount) + "</span><br>INSTALLMENTS > " + formatDisplayNumber(repayment_count) + "<br><span style='color: whitesmoke;'>DECISION</span> > <span style='color: aqua;'>APPROVED</span><br><span style='color: whitesmoke;'>STATUS</span> > " + repaid_status;
                autoSave();
            }

            registered_loan_slot.addEventListener("click", () => {
                oscClickAudio();
                registered_loan_slot.style.cursor = "pointer";
                //alert("Status > Approved <br> Loan ID > " + registered_loan_slot.id); // TESTING

                function manualPayment() {
                    pay_custom_amount_opt.onclick = function() { // PAY CUSTOM AMOUNT OPT
                    let custom_payment = Number(custom_loan_payment_amount_inp.value);

                    if (custom_payment && custom_payment > 0 && custom_payment <= player_cash_balance && custom_payment <= loan_remaining_balance) {
                        player_cash_balance -= custom_payment;
                        current_loan_debt -= custom_payment;
                        loan_remaining_balance = (loan_remaining_balance - custom_payment).toFixed(2);
                        updateLoanStats();

                        mysteryWinAudio();
                        document.getElementById("loan-id-manager-output").innerHTML = "LOAN ID > <span style='color: greenyellow; text-transform: uppercase;'>[" + "<span style='color: yellow;'>" + registered_loan_slot.id + "</span>]<br>" + "LOAN AMOUNT > <span style='color: lime;'>$" + formatMoneyValue(loan_amount) + "<br>" + "<span style='color: whitesmoke;'>REMAINING DEBT</span> > $" + formatMoneyValue(loan_remaining_balance);
                        notificationDialog("[PAYMENT SUCCESS] > $" + formatMoneyValue(custom_payment) + " PAYMENT MADE!", 3000);

                        if (loan_remaining_balance <= 0.01) {
                            loan_remaining_balance = 0;
                            stopRepaymentInterval(registered_loan.loan_id);
                            setTimeout(() => { loans_repayment_interval_output_dialog_overlay.style.display = "none"; }, 1000)
                            notificationDialog("[$" + formatMoneyValue(loan_amount) + " LOAN] > Your loan has been fully repaid!", 5000);
                        }
                    } else if (custom_payment > loan_remaining_balance) {
                        notificationDialog("Payment exceeds remaining debt!", 3000);
                    } else if (custom_payment <= 0) {
                        notificationDialog("Invalid payment amount / Empty Field!", 3000);
                    } else {
                        notificationDialog("Insufficient Funds!", 3000);
                        upgradePurchaseFailedAudio();
                    }
                }
                } manualPayment();

                function payFullPayment() {
                    pay_full_payment_opt.disabled = false; pay_full_payment_opt.style.opacity = "1"; pay_full_payment_opt.style.cursor = "pointer";
                    pay_full_payment_opt.onclick = function() {
                        if (Number(loan_remaining_balance) <= 0.01) {
                            notificationDialog("[ERROR] > LOAN ALREADY REPAID!", 3000);
                            upgradePurchaseFailedAudio();
                        } else if (player_cash_balance >= loan_remaining_balance) {
                            let full_payment = Number(loan_remaining_balance);
                            player_cash_balance -= full_payment;
                            current_loan_debt = Math.max(0, Number((current_loan_debt - full_payment).toFixed(2)));
                            loan_remaining_balance = 0;

                            stopRepaymentInterval(registered_loan.loan_id);
                            updateLoanStats();
                            updateStats();
                            setTimeout(() => { loan_manual_management_dialog_overlay.style.display = "none"; }, 1000);
                            document.getElementById("loan-id-manager-output").innerHTML = "LOAN ID > <span style='color: greenyellow; text-transform: uppercase;'>[" + "<span style='color: yellow;'>" + registered_loan_slot.id + "</span>]<br>" + "LOAN AMOUNT > <span style='color: lime;'>$" + formatMoneyValue(loan_amount) + "<br>" + "<span style='color: whitesmoke;'>REMAINING DEBT</span> > $" + formatMoneyValue(loan_remaining_balance);
                            upgradePurchasedAudio();
                            notificationDialog("[LOAN REPAID] > PAID IN FULL!", 3500);
                        } else {
                            notificationDialog("Insufficient Funds!", 3000);
                            upgradePurchaseFailedAudio();
                        }
                    }
                } payFullPayment();

                loan_manual_management_dialog_overlay.style.display = "flex";
                document.getElementById("loan-id-manager-output").innerHTML = "LOAN ID > <span style='color: greenyellow; text-transform: uppercase;'>[" + "<span style='color: yellow;'>" + registered_loan_slot.id + "</span>]<br>" + "LOAN AMOUNT > <span style='color: lime;'>$" + formatMoneyValue(loan_amount) + "<br>" + "<span style='color: whitesmoke;'>REMAINING DEBT</span> > $" + formatMoneyValue(loan_remaining_balance);
            });

            registered_loan_slot.innerHTML = "LOAN ID > <span style='color: whitesmoke;'>" + registered_loan_unique_id + "</span><br>LOAN AMOUNT > <span style='color: lime;'>$" + formatMoneyValue(loan_amount) + "</span><br>" + "FULL REPAYMENT > <span style='color: lime;'>$" + formatMoneyValue(repayment_amount) + "</span><br>" + "INSTALLMENTS > " + formatDisplayNumber(repayment_count) + "<br>" + "<span style='color: whitesmoke;'>DECISION</span> > " + "<span style='color: aqua;'>APPROVED</span>" + "<br>" + "<span style='color: whitesmoke;'>STATUS</span> > " + "<span style='color: #E86D72;'>UNPAID</span>";
            document.getElementById("registered-loans-list").appendChild(registered_loan_slot);
            startRepaymentInterval(registered_loan, () => {
                loan_remaining_balance = registered_loan.remaining_balance;
                updateLoanStats();
            });

            setTimeout(() => { 
                bank_loan_status_dialog_overlay.style.display = "flex"; 
                document.getElementById("loan-status-output").innerHTML = "LOAN ID > " + registered_loan_slot.id + "<br>" + "<span style='color: yellow'>DECISION > </span><span style='color: springgreen'>" + "$" + formatMoneyValue(loan_amount) + " LOAN APPROVED!";
                setTimeout(() => { bank_loan_status_dialog_overlay.style.display = "none"; }, 3000)
            }, 1000)
        }, 1500)
    } else {
        notificationDialog("[LOAN APPLICATION REJECTED] > ELIGIBILITY CRITERIA NOT MET!", 3500);
        accept_loan_opt.disabled = true; accept_loan_opt.style.opacity = "0.5"; accept_loan_opt.style.cursor = "not-allowed";
        setTimeout(() => { loanApplicationRejectedAudio(); }, 500);

        let registered_loan_slot = document.createElement("section");
        registered_loan_slot.setAttribute("class", "registered-loan-slot");
        registered_loan_slot.innerHTML = "LOAN AMOUNT > <span style='color: lime;'>$" + formatMoneyValue(loan_amount) + "</span><br>" + "FULL REPAYMENT > <span style='color: lime;'>$" + formatMoneyValue(repayment_amount) + "</span><br>" + "INSTALLMENTS > " + formatDisplayNumber(repayment_count) + "<br>" + "DECISION > " + "<span style='color: #E86D72;'>REJECTED</span>" + "<br>" + "<span style='color: whitesmoke;'>REASON</span> > <span style='color: #d2e86d;'>INSUFFICIENT TYCOON CREDIT / EXCEEDED DEBT LIMIT!</span>";
        document.getElementById("registered-loans-list").appendChild(registered_loan_slot);

        setTimeout(() => { accept_loan_opt.disabled = false; accept_loan_opt.style.opacity = "1"; accept_loan_opt.style.cursor = "not-allowed"; bank_loan_info_dialog_overlay.style.display = "none"; upgradePurchaseFailedAudio(); }, 3000)
        setTimeout(() => { 
            bank_loan_status_dialog_overlay.style.display = "flex"; 
            document.getElementById("loan-status-output").innerHTML = "<span style='color: yellow'>Loan Status > </span><span style='color: #E86D72'>NOT ELIGIBLE!</span>";
            setTimeout(() => { bank_loan_status_dialog_overlay.style.display = "none"; }, 3000)
        }, 3000)
    }
}